import json, uuid, random, hashlib, os, socket, secrets
from datetime import datetime, timedelta
from enum import Enum
from typing import Optional
import requests
from fastapi import Depends, FastAPI, HTTPException, Query, WebSocket,WebSocketDisconnect, Header, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from fastapi.security import OAuth2PasswordBearer
from pydantic import BaseModel
from sqlalchemy import (
    Column, DateTime, Float, ForeignKey, Integer, String, Text, Boolean,
    create_engine, func, and_
)
from sqlalchemy.orm import Session, relationship, sessionmaker
from sqlalchemy.orm import declarative_base
try:
    from config import CORS_ORIGINS, DATABASE_URL, LOCAL_THREAT_DB_PATH,SECRET_KEY, ABUSEIPDB_API_KEY, OTX_API_KEY, GREYNOISE_API_KEY, VT_API_KEY
except ImportError:
    try:
        from backend.config import CORS_ORIGINS, DATABASE_URL,LOCAL_THREAT_DB_PATH, SECRET_KEY, ABUSEIPDB_API_KEY, OTX_API_KEY,GREYNOISE_API_KEY, VT_API_KEY
    except ImportError:
        CORS_ORIGINS = ["http://localhost:3000", "http://localhost:5173", "http://127.0.0.1:3000"]
        DATABASE_URL = "sqlite:///./security_edr.db"
        LOCAL_THREAT_DB_PATH = "./threat_db.json"
        SECRET_KEY = "default-secret-key-change-in-production"
        ABUSEIPDB_API_KEY = ""
        OTX_API_KEY = ""
        GREYNOISE_API_KEY = ""
        VT_API_KEY = ""
from services.threat_intel import ThreatIntelService, configure as configure_intel
configure_intel(VT_API_KEY=VT_API_KEY, ABUSEIPDB_API_KEY=ABUSEIPDB_API_KEY,OTX_API_KEY=OTX_API_KEY, GREYNOISE_API_KEY=GREYNOISE_API_KEY)
threat_intel_service = ThreatIntelService()
# --- New Engine Imports ---
try:
    from config import (
        BEHAVIORAL_ANALYSIS_ENABLED, ML_ENABLED, AUTO_RESPONSE_ENABLED,
        RISK_SCORE_THRESHOLD_LOW, RISK_SCORE_THRESHOLD_MEDIUM,
        RISK_SCORE_THRESHOLD_HIGH, RISK_SCORE_THRESHOLD_CRITICAL,
        CORRELATION_TIME_WINDOW, LOG_LEVEL,
        GEMINI_API_KEY, AI_ANALYSIS_ENABLED, AI_ANALYSIS_MODEL,
    )
except ImportError:
    try:
        from backend.config import (
            BEHAVIORAL_ANALYSIS_ENABLED, ML_ENABLED, AUTO_RESPONSE_ENABLED,
            RISK_SCORE_THRESHOLD_LOW, RISK_SCORE_THRESHOLD_MEDIUM,
            RISK_SCORE_THRESHOLD_HIGH, RISK_SCORE_THRESHOLD_CRITICAL,
            CORRELATION_TIME_WINDOW, LOG_LEVEL,
            GEMINI_API_KEY, AI_ANALYSIS_ENABLED, AI_ANALYSIS_MODEL,
        )
    except ImportError:
        BEHAVIORAL_ANALYSIS_ENABLED = True
        ML_ENABLED = False
        AUTO_RESPONSE_ENABLED = True
        RISK_SCORE_THRESHOLD_LOW = 20
        RISK_SCORE_THRESHOLD_MEDIUM = 40
        RISK_SCORE_THRESHOLD_HIGH = 65
        RISK_SCORE_THRESHOLD_CRITICAL = 85
        CORRELATION_TIME_WINDOW = 3600
        LOG_LEVEL = "INFO"
        GEMINI_API_KEY = ""
        AI_ANALYSIS_ENABLED = True
        AI_ANALYSIS_MODEL = "gemini-2.5-flash"
from core.logging import logger, AgentLogger
AgentLogger.configure(log_level=LOG_LEVEL)
from core.exceptions import AgentSecurityError, ValidationError, DetectionError 
from services.behavioral_engine import BehavioralEngine
from services.risk_scoring import RiskScoringEngine
from services.correlation_engine import CorrelationEngine
from services.response_engine import ResponseEngine, ResponseAction
from services.ai_analysis import AIAnalysisService, extract_iocs
ai_analysis_service = AIAnalysisService(
    api_key=GEMINI_API_KEY, model=AI_ANALYSIS_MODEL, enabled=AI_ANALYSIS_ENABLED
)
behavioral_engine = BehavioralEngine(enabled=BEHAVIORAL_ANALYSIS_ENABLED)
risk_scoring_engine = RiskScoringEngine(thresholds={
    "low": RISK_SCORE_THRESHOLD_LOW,
    "medium": RISK_SCORE_THRESHOLD_MEDIUM,
    "high": RISK_SCORE_THRESHOLD_HIGH,
    "critical": RISK_SCORE_THRESHOLD_CRITICAL, })
correlation_engine = CorrelationEngine(time_window_minutes=CORRELATION_TIME_WINDOW // 60)
response_engine = ResponseEngine(enabled=AUTO_RESPONSE_ENABLED)
# Pending agent actions are now persisted in the `pending_actions` DB table
# (see PendingAction model) instead of this in-memory dict, so a backend
# restart no longer silently drops actions the agent hasn't picked up yet.
# ML Detectors (optional)
from services.ml.base import MLFallback
from services.ml.isolation_forest import create_if_available as create_iforest
from services.ml.one_class_svm import create_if_available as create_svm
from services.ml.baseliner import BehavioralBaseliner
iforest_detector = create_iforest() if ML_ENABLED else MLFallback()
svm_detector = create_svm() if ML_ENABLED else MLFallback()
behavioral_baseliner = BehavioralBaseliner() if ML_ENABLED else None
# Cross-platform abstraction
from services.platform.factory import get_platform
platform_abstraction = get_platform()
logger.info("All engines initialized",
    behavioral=BEHAVIORAL_ANALYSIS_ENABLED,
    ml=ML_ENABLED,
    auto_response=AUTO_RESPONSE_ENABLED, )
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()
class User(Base):
    __tablename__ = "users"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    email = Column(String, unique=True, nullable=False, index=True)
    password_hash = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)
    agents = relationship("Agent", back_populates="owner")
class Agent(Base):
    __tablename__ = "agents"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    hostname = Column(String, nullable=False)
    os_type = Column(String, nullable=False)
    os_version = Column(String, default="")
    os_patch_level = Column(String, default="")
    cpu_model = Column(String, default="")
    cpu_cores = Column(Integer, default=0)
    cpu_usage = Column(Float, default=0.0)
    ram_total_gb = Column(Integer, default=0)
    ram_used_gb = Column(Float, default=0.0)
    disk_total_gb = Column(Integer, default=0)
    disk_used_gb = Column(Float, default=0.0)
    mac_address = Column(String, default="")
    ip_address = Column(String, default="")
    status = Column(String, default="online")
    version = Column(String, default="3.5.1")
    last_heartbeat = Column(DateTime, default=datetime.utcnow)
    registered_at = Column(DateTime, default=datetime.utcnow)
    tamper_protection = Column(Boolean, default=True)
    self_defense_status = Column(String, default="active")
    low_footprint_mode = Column(Boolean, default=True)
    quarantine = Column(Boolean, default=False)
    bitlocker_enabled = Column(Boolean, default=False)
    firewall_enabled = Column(Boolean, default=True)
    agent_type = Column(String, default="silent_deploy")
    group_name = Column(String, default="")
    one_time_token = Column(String, default="")
    agent_token = Column(String, default="")  # persistent per-agent secret, sent as X-Agent-Token on every report call
    owner_id = Column(String, ForeignKey("users.id"), nullable=True, index=True)
    owner = relationship("User", back_populates="agents")
    alerts = relationship("Alert", back_populates="agent", cascade="all, delete-orphan")
    processes = relationship("Process", back_populates="agent", cascade="all,delete-orphan")
    network_connections = relationship("NetworkConnection", back_populates="agent", cascade="all, delete-orphan")
    applications = relationship("Application", back_populates="agent", cascade="all, delete-orphan")
    file_changes = relationship("FileChange", back_populates="agent", cascade="all, delete-orphan")
    registry_changes = relationship("RegistryChange", back_populates="agent", cascade="all, delete-orphan")
class Alert(Base):
    __tablename__ = "alerts"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    title = Column(String, nullable=False)
    description = Column(Text, default="")
    severity = Column(String, default="medium")
    type = Column(String, default="malware")
    status = Column(String, default="open")
    source = Column(String, default="agent")
    mitre_tactic_id = Column(String, default="")
    mitre_tactic_name = Column(String, default="")
    mitre_technique_id = Column(String, default="")
    mitre_technique_name = Column(String, default="")
    score = Column(Float, default=0.0)
    details = Column(Text, default="{}")
    fingerprint = Column(String, default="", index=True)  # identity key used to dedupe repeats of the same condition
    occurrence_count = Column(Integer, default=1)  # how many times this fingerprint has re-fired while open
    last_seen_at = Column(DateTime, default=datetime.utcnow)  # updated each time a duplicate is suppressed
    # NOTE: fingerprint-based dedup is currently wired into port_scan,
    # lateral_movement, and beaconing (the highest-volume repeat offenders).
    # The remaining alert-creation call sites still dedupe only on
    # (agent_id, type, status="open") with no fingerprint, which means two
    # genuinely different incidents of the same type can mask each other.
    # Apply the same fingerprint + occurrence_count/last_seen_at pattern to
    # the rest in a follow-up pass.
    created_at = Column(DateTime, default=datetime.utcnow)
    acknowledged_at = Column(DateTime, nullable=True)
    resolved_at = Column(DateTime, nullable=True)
    resolved_by = Column(String, default="")
    agent = relationship("Agent", back_populates="alerts")
    ai_summary = Column(Text, default="")
    ai_likely_intent = Column(String, default="")
    ai_recommended_action = Column(String, default="")
    ai_confidence = Column(String, default="")
    ai_mitre_explanation = Column(Text, default="")
    ai_analyzed_at = Column(DateTime, nullable=True)
class PendingAction(Base):
    """Persisted replacement for the old in-memory _pending_actions dict.
    A backend restart no longer drops actions an agent hasn't picked up yet."""
    __tablename__ = "pending_actions"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False, index=True)
    action = Column(String, nullable=False)
    target = Column(String, default="")
    source = Column(String, default="manual")  # "manual" (analyst) or "policy" (auto-response)
    status = Column(String, default="pending")  # pending -> delivered -> completed/failed
    created_at = Column(DateTime, default=datetime.utcnow)
    delivered_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    result = Column(Text, default="")
class Application(Base):
    __tablename__ = "applications"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    name = Column(String, nullable=False)
    version = Column(String, default="")
    vendor = Column(String, default="")
    install_date = Column(DateTime, default=datetime.utcnow)
    is_approved = Column(Boolean, default=True)
    is_running = Column(Boolean, default=False)
    risk_score = Column(Float, default=0.0)
    cve_list = Column(Text, default="[]")
    agent = relationship("Agent", back_populates="applications")
class NetworkConnection(Base):
    __tablename__ = "network_connections"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    local_ip = Column(String, default="")
    local_port = Column(Integer, default=0)
    remote_ip = Column(String, default="")
    remote_port = Column(Integer, default=0)
    protocol = Column(String, default="TCP")
    state = Column(String, default="established")
    pid = Column(Integer, default=0)
    process_name = Column(String, default="")
    bytes_sent = Column(Integer, default=0)
    bytes_received = Column(Integer, default=0)
    is_suspicious = Column(Boolean, default=False)
    threat_intel_match = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", back_populates="network_connections")
class Process(Base):
    __tablename__ = "processes"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    pid = Column(Integer, nullable=False)
    name = Column(String, nullable=False)
    path = Column(String, default="")
    parent_pid = Column(Integer, default=0)
    parent_name = Column(String, default="")
    cmdline = Column(String, default="")
    user = Column(String, default="")
    cpu_percent = Column(Float, default=0.0)
    memory_mb = Column(Float, default=0.0)
    is_suspicious = Column(Boolean, default=False)
    is_whitelisted = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", back_populates="processes")
class FileChange(Base):
    __tablename__ = "file_changes"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    file_path = Column(String, nullable=False)
    change_type = Column(String, default="modified")
    old_hash = Column(String, default="")
    new_hash = Column(String, default="")
    file_size = Column(Integer, default=0)
    is_critical = Column(Boolean, default=False)
    is_canary = Column(Boolean, default=False)
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", back_populates="file_changes")
class RegistryChange(Base):
    __tablename__ = "registry_changes"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    key_path = Column(String, nullable=False)
    value_name = Column(String, default="")
    old_value = Column(String, default="")
    new_value = Column(String, default="")
    change_type = Column(String, default="modified")
    is_auto_start = Column(Boolean, default=False)
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", back_populates="registry_changes")
class ThreatIntel(Base):
    __tablename__ = "threat_intel"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    indicator_type = Column(String, nullable=False)
    value = Column(String, nullable=False)
    confidence = Column(String, default="medium")
    severity = Column(String, default="medium")
    source = Column(String, default="external")
    description = Column(Text, default="")
    first_seen = Column(DateTime, default=datetime.utcnow)
    last_seen = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)
    mitre_mapping = Column(String, default="")
class CanaryFile(Base):
    __tablename__ = "canary_files"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=True)
    file_path = Column(String, nullable=False)
    file_name = Column(String, nullable=False)
    content_hash = Column(String, default="")
    is_triggered = Column(Boolean, default=False)
    triggered_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
class FirewallRule(Base):
    __tablename__ = "firewall_rules"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=True)
    name = Column(String, nullable=False)
    direction = Column(String, default="inbound")
    action = Column(String, default="allow")
    protocol = Column(String, default="TCP")
    local_port = Column(Integer, default=0)
    remote_ip = Column(String, default="any")
    enabled = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
class Policy(Base):
    __tablename__ = "policies"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    key = Column(String, unique=True, nullable=False)
    value = Column(Text, nullable=False)
    description = Column(String, default="")
    updated_at = Column(DateTime, default=datetime.utcnow)
class UserBehavior(Base):
    __tablename__ = "user_behavior"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    user_name = Column(String, default="")
    event_type = Column(String, default="login")
    details = Column(Text, default="{}")
    anomaly_score = Column(Float, default=0.0)
    is_anomalous = Column(Boolean, default=False)
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="user_behaviors")
class OSPatchInfo(Base):
    __tablename__ = "os_patch_info"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    missing_patches = Column(Text, default="[]")
    count = Column(Integer, default=0)
    oldest_missing_days = Column(Integer, default=0)
    severity = Column(String, default="info")
    checked_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="patch_info")
class BehavioralSnapshot(Base):
    __tablename__ = "behavioral_snapshots"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    cpu_usage = Column(Float, default=0.0)
    ram_usage = Column(Float, default=0.0)
    process_count = Column(Integer, default=0)
    net_connections = Column(Integer, default=0)
    is_anomaly = Column(Boolean, default=False)
    anomaly_score = Column(Float, default=0.0)
    ml_active = Column(Boolean, default=False)
    history_size = Column(Integer, default=0)
    details = Column(Text, default="{}")
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="behavioral_snapshots")
class FileIntegrityCheck(Base):
    __tablename__ = "file_integrity_checks"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    monitored_files = Column(Text, default="[]")
    changes_detected = Column(Boolean, default=False)
    changed_files = Column(Text, default="[]")
    severity = Column(String, default="info")
    checked_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="integrity_checks")
class MisconfigurationCheck(Base):
    __tablename__ = "misconfiguration_checks"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    rdp_open = Column(Boolean, default=False)
    firewall_off = Column(Boolean, default=False)
    guest_account = Column(Boolean, default=False)
    weak_password_policy = Column(Boolean, default=False)
    severity = Column(String, default="info")
    checked_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="misconfiguration_checks")
class WatchdogEvent(Base):
    __tablename__ = "watchdog_events"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    agent_running = Column(Boolean, default=True)
    tamper_detected = Column(Boolean, default=False)
    restart_count = Column(Integer, default=0)
    log_entry = Column(Text, default="")
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="watchdog_events")
class AgentMonitorLog(Base):
    __tablename__ = "agent_monitor_logs"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    cpu_percent = Column(Float, default=0.0)
    ram_percent = Column(Float, default=0.0)
    interval_seconds = Column(Integer, default=5)
    recorded_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="monitor_logs")
class ProcessExecutionEvent(Base):
    __tablename__ = "process_execution_events"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    process_name = Column(String, default="")
    process_path = Column(String, default="")
    file_hash = Column(String, default="")
    blocked = Column(Boolean, default=False)
    reason = Column(String, default="clean")
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="execution_events")
class ZeroDayFinding(Base):
    __tablename__ = "zero_day_findings"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    file_name = Column(String, default="")
    file_path = Column(String, default="")
    unknown_hash = Column(Boolean, default=False)
    risky_location = Column(Boolean, default=False)
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="zero_day_findings")
class FilelessDetectionEvent(Base):
    __tablename__ = "fileless_detection_events"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    pid = Column(Integer, default=0)
    process_name = Column(String, default="")
    reason = Column(String, default="")
    eventlog_alert = Column(Boolean, default=False)
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="fileless_events")
class MemoryScanEvent(Base):
    __tablename__ = "memory_scan_events"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    pid = Column(Integer, default=0)
    process_name = Column(String, default="")
    reason = Column(String, default="")
    shellcode_detected = Column(Boolean, default=False)
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="memory_scan_events")
class UsbDiskEvent(Base):
    __tablename__ = "usb_disk_events"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    usb_devices = Column(Text, default="[]")
    blocked_devices = Column(Text, default="[]")
    usb_control_ok = Column(Boolean, default=True)
    encrypted = Column(Boolean, default=False)
    protection_on = Column(Boolean, default=False)
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="usb_disk_events")
class C2BeaconingEvent(Base):
    __tablename__ = "c2_beaconing_events"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    src_ip = Column(String, default="")
    dst_ip = Column(String, default="")
    connections = Column(Integer, default=0)
    avg_interval = Column(Float, default=0.0)
    variance = Column(Float, default=0.0)
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="c2_beaconing_events")
class LiveThreatIntelResult(Base):
    __tablename__ = "live_threat_intel_results"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    indicator_type = Column(String, default="IPv4")
    indicator = Column(String, default="")
    pulse_count = Column(Integer, default=0)
    reputation = Column(String, default="")
    country = Column(String, default="")
    raw_json = Column(Text, default="{}")
    checked_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="threat_intel_results")
class OfflineScanEvent(Base):
    __tablename__ = "offline_scan_events"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    file_path = Column(String, default="")
    file_hash = Column(String, default="")
    threat_name = Column(String, default="")
    scan_directory = Column(String, default=".")
    threats_found = Column(Integer, default=0)
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="offline_scan_events")
class VulnerabilityFinding(Base):
    __tablename__ = "vulnerability_findings"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    finding_type = Column(String, default="")
    software = Column(String, default="")
    version = Column(String, default="")
    cve_id = Column(String, default="")
    severity = Column(String, default="")
    risk = Column(String, default="")
    description = Column(Text, default="")
    port = Column(Integer, default=0)
    service = Column(String, default="")
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="vulnerability_findings")
class ProcessTreeFinding(Base):
    __tablename__ = "process_tree_findings"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    finding_type = Column(String, default="")
    parent_name = Column(String, default="")
    parent_pid = Column(Integer, default=0)
    child_name = Column(String, default="")
    child_pid = Column(Integer, default=0)
    risk = Column(String, default="")
    description = Column(Text, default="")
    cmdline = Column(Text, default="")
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="process_tree_findings")
class ShadowITFinding(Base):
    __tablename__ = "shadow_it_findings"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    finding_type = Column(String, default="")
    service_name = Column(String, default="")
    domain = Column(String, default="")
    category = Column(String, default="")
    risk = Column(String, default="")
    description = Column(Text, default="")
    ip = Column(String, default="")
    mac = Column(String, default="")
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="shadow_it_findings")
class ExploitMitigationEvent(Base):
    __tablename__ = "exploit_mitigation_events"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    aslr_enabled = Column(Boolean, default=False)
    aslr_level = Column(String, default="unknown")
    dep_enabled = Column(Boolean, default=False)
    dep_policy = Column(String, default="unknown")
    acg_enabled = Column(Boolean, default=False)
    os = Column(String, default="")
    risk_summary = Column(String, default="")
    severity = Column(String, default="info")
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="exploit_mitigation_events")
class InstallationVisibilityEvent(Base):
    __tablename__ = "installation_visibility_events"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    boot_time = Column(String, default="")
    install_path = Column(String, default="")
    running_as_username = Column(String, default="")
    running_as_admin = Column(Boolean, default=False)
    os_name = Column(String, default="")
    os_release = Column(String, default="")
    os_machine = Column(String, default="")
    hostname = Column(String, default="")
    agent_version = Column(String, default="")
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="installation_visibility_events")
class NetworkDPIEvent(Base):
    __tablename__ = "network_dpi_events"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    src_ip = Column(String, default="")
    dst_ip = Column(String, default="")
    src_port = Column(Integer, default=0)
    dst_port = Column(Integer, default=0)
    protocol = Column(String, default="")
    reason = Column(Text, default="")
    payload_size = Column(Integer, default=0)
    threat_type = Column(String, default="")
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="network_dpi_events")
class PrivilegeEscalationEvent(Base):
    __tablename__ = "privilege_escalation_events"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    check_type = Column(String, default="")
    os = Column(String, default="")
    finding = Column(Text, default="")
    process_name = Column(String, default="")
    user = Column(String, default="")
    privilege = Column(String, default="")
    risk_reason = Column(Text, default="")
    severity = Column(String, default="medium")
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="privilege_escalation_events")
class SilentDeploymentEvent(Base):
    __tablename__ = "silent_deployment_events"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    no_window = Column(Boolean, default=False)
    hidden = Column(Boolean, default=False)
    startup_type = Column(String, default="user")
    process_name = Column(String, default="")
    parent_process = Column(String, default="")
    is_silent = Column(Boolean, default=False)
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="silent_deployment_events")
class LateralMovementEvent(Base):
    __tablename__ = "lateral_movement_events"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    movement_type = Column(String, default="")
    source_ip = Column(String, default="")
    destination_ip = Column(String, default="")
    port = Column(Integer, default=0)
    service = Column(String, default="")
    connection_count = Column(Integer, default=0)
    risk = Column(String, default="")
    description = Column(Text, default="")
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="lateral_movement_events")
class PortScanEvent(Base):
    __tablename__ = "port_scan_events"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    scan_type = Column(String, default="")
    scanner_ip = Column(String, default="")
    target_ip = Column(String, default="")
    unique_ports = Column(Integer, default=0)
    sensitive_ports_hit = Column(Boolean, default=False)
    syn_count = Column(Integer, default=0)
    risk = Column(String, default="")
    description = Column(Text, default="")
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="port_scan_events")
class HostFirewallEvent(Base):
    __tablename__ = "host_firewall_events"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    chain = Column(String, default="")
    rule = Column(String, default="")
    ip_blocked = Column(String, default="")
    action = Column(String, default="")
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="host_firewall_events")
class WebDNSFilterEvent(Base):
    __tablename__ = "web_dns_filter_events"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    domain = Column(String, default="")
    url = Column(String, default="")
    action = Column(String, default="")
    matched_pattern = Column(String, default="")
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="web_dns_filter_events")
class ScriptMonitorEvent(Base):
    __tablename__ = "script_monitor_events"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    command = Column(Text, default="")
    user = Column(String, default="")
    suspicious_patterns = Column(Text, default="[]")
    action = Column(String, default="")
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="script_monitor_events")
class RansomwareCanaryEvent(Base):
    __tablename__ = "ransomware_canary_events"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    file_path = Column(String, default="")
    reason = Column(String, default="")
    file_hash = Column(String, default="")
    directory = Column(String, default="")
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="ransomware_canary_events")
class CredentialDumpingEvent(Base):
    __tablename__ = "credential_dumping_events"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    process_name = Column(String, default="")
    pid = Column(Integer, default=0)
    detection_type = Column(String, default="")
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="credential_dumping_events")
class NextGenAVEvent(Base):
    __tablename__ = "next_gen_av_events"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    file_path = Column(String, default="")
    file_hash = Column(String, default="")
    detection_reason = Column(String, default="")
    action = Column(String, default="")
    scanner_type = Column(String, default="")
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="next_gen_av_events")
class UserBehaviourEvent(Base):
    __tablename__ = "user_behaviour_events"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    file_path = Column(String, default="")
    action = Column(String, default="")
    baseline_hash = Column(String, default="")
    current_hash = Column(String, default="")
    detected_at = Column(DateTime, default=datetime.utcnow)
    agent = relationship("Agent", backref="user_behaviour_events")
class Session(Base):
    __tablename__ = "sessions"
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    agent_id = Column(String, ForeignKey("agents.id"), nullable=False)
    hostname = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
Base.metadata.create_all(bind=engine)
# --- Lightweight migration: add ai_* columns to an existing `alerts` table
# from before this feature existed (SQLAlchemy create_all only creates
# missing tables, it never alters existing ones). Safe to run every startup.
def _migrate_alert_ai_columns():
    ai_columns = {
        "ai_summary": "TEXT DEFAULT ''",
        "ai_likely_intent": "VARCHAR DEFAULT ''",
        "ai_recommended_action": "VARCHAR DEFAULT ''",
        "ai_confidence": "VARCHAR DEFAULT ''",
        "ai_mitre_explanation": "TEXT DEFAULT ''",
        "ai_analyzed_at": "DATETIME",
    }
    try:
        with engine.connect() as conn:
            existing = {row[1] for row in conn.exec_driver_sql("PRAGMA table_info(alerts)").fetchall()}
            for col, coltype in ai_columns.items():
                if col not in existing:
                    conn.exec_driver_sql(f"ALTER TABLE alerts ADD COLUMN {col} {coltype}")
            conn.commit()
    except Exception as e:
        logger.warning(f"AI column migration skipped/failed: {e}")
_migrate_alert_ai_columns()
class AgentRegister(BaseModel):
    hostname: str
    os_type: str
    os_version: str = ""
    cpu_model: str = ""
    cpu_cores: int = 0
    ram_total_gb: int = 0
    disk_total_gb: int = 0
    mac_address: str = ""
    ip_address: str = ""
class AIChatRequest(BaseModel):
    question: str
    alert_id: Optional[str] = None
    incident_id: Optional[str] = None
class AlertAcknowledge(BaseModel):
    comment: str = ""
class AlertResolve(BaseModel):
    resolved_by: str = "admin"
    comment: str = ""
class PolicyUpdate(BaseModel):
    key: str
    value: str
class AppWhitelistAdd(BaseModel):
    name: str
    path: str = ""
    hash: str = ""
    vendor: str = ""
class BlockDevice(BaseModel):
    device_id: str
    device_name: str
    device_type: str = "usb"
    reason: str = ""
class ScanRequest(BaseModel):
    scan_type: str = "quick"
class DeployRequest(BaseModel):
    agent_type: str = "silent_deploy"
class QuarantineRequest(BaseModel):
    action: str = "quarantine"
class SyncIntelRequest(BaseModel):
    url: str = ""
class BehavioralReport(BaseModel):
    cpu_usage: float = 0.0
    ram_usage: float = 0.0
    process_count: int = 0
    net_connections: int = 0
    is_anomaly: bool = False
    anomaly_score: float = 0.0
    ml_active: bool = False
    history_size: int = 0
    details: str = "{}"
class PatchReport(BaseModel):
    missing_patches: list[str] = []
    count: int = 0
    oldest_missing_days: int = 0
    severity: str = "info"
class FileIntegrityReport(BaseModel):
    monitored_files: list[str] = []
    changes_detected: bool = False
    changed_files: list[str] = []
    severity: str = "info"
class MisconfigReport(BaseModel):
    rdp_open: bool = False
    firewall_off: bool = False
    guest_account: bool = False
    weak_password_policy: bool = False
    severity: str = "info"
class SoftwareItem(BaseModel):
    name: str
    version: str = ""
    vendor: str = ""
    install_date: str = ""
    is_approved: bool = True
    risk_score: float = 0.0
class SoftwareInventoryReport(BaseModel):
    software: list[SoftwareItem] = []
class AssetDiscoveryReport(BaseModel):
    hostname: str = ""
    os_type: str = ""
    os_version: str = ""
    architecture: str = ""
    processor: str = ""
    cpu_cores: int = 0
    logical_cpus: int = 0
    ram_gb: float = 0.0
    mac_address: str = ""
    ip_address: str = ""
class WatchdogStatusReport(BaseModel):
    agent_running: bool = True
    tamper_detected: bool = False
    restart_count: int = 0
    log_entry: str = ""
class AgentMonitorReport(BaseModel):
    cpu_percent: float = 0.0
    ram_percent: float = 0.0
    interval_seconds: int = 5
class TelemetryReport(BaseModel):
    schema_version: str = "1.0"
    os_type: str = ""
    hostname: str = ""
    platform: str = ""
    processor: str = ""
    cpu_cores: int = 0
    ram_gb: float = 0.0
    mac_address: str = ""
    format_valid: bool = True
    fields_present: int = 0
class PreExecEventReport(BaseModel):
    process_name: str = ""
    process_path: str = ""
    file_hash: str = ""
    blocked: bool = False
    reason: str = "clean"
class RegistryChangeReport(BaseModel):
    key_path: str = ""
    value_name: str = ""
    old_value: str = ""
    new_value: str = ""
    change_type: str = "added"
    is_auto_start: bool = False
class ZeroDayReport(BaseModel):
    file_name: str = ""
    file_path: str = ""
    unknown_hash: bool = False
    risky_location: bool = False
class BufferPolishReport(BaseModel):
    os: str = ""
    hostname: str = ""
    cpu_usage: float = 0.0
    ram_used_gb: float = 0.0
    ram_total_gb: float = 0.0
    mac: str = ""
    status: str = "healthy"
class FilelessDetectionEventReport(BaseModel):
    pid: int = 0
    process_name: str = ""
    reason: str = ""
    eventlog_alert: bool = False
class MemoryScanEventReport(BaseModel):
    pid: int = 0
    process_name: str = ""
    reason: str = ""
    shellcode_detected: bool = False
class UsbDiskEventReport(BaseModel):
    usb_devices: list[str] = []
    blocked_devices: list[str] = []
    usb_control_ok: bool = True
    encrypted: bool = False
    protection_on: bool = False
class C2BeaconingReport(BaseModel):
    src_ip: str = ""
    dst_ip: str = ""
    connections: int = 0
    avg_interval: float = 0.0
    variance: float = 0.0
class LiveThreatIntelReport(BaseModel):
    indicator_type: str = "IPv4"
    indicator: str = ""
    pulse_count: int = 0
    reputation: str = ""
    country: str = ""
    raw_json: str = "{}"
class OfflineScanReport(BaseModel):
    file_path: str = ""
    file_hash: str = ""
    threat_name: str = ""
    scan_directory: str = "."
    threats_found: int = 0
class VulnerabilityScanReport(BaseModel):
    finding_type: str = ""
    software: str = ""
    version: str = ""
    cve_id: str = ""
    severity: str = ""
    risk: str = ""
    description: str = ""
    port: int = 0
    service: str = ""
class ProcessTreeReport(BaseModel):
    finding_type: str = ""
    parent_name: str = ""
    parent_pid: int = 0
    child_name: str = ""
    child_pid: int = 0
    risk: str = ""
    description: str = ""
    cmdline: str = ""
class ShadowITReport(BaseModel):
    finding_type: str = ""
    service_name: str = ""
    domain: str = ""
    category: str = ""
    risk: str = ""
    description: str = ""
    ip: str = ""
    mac: str = ""
class ExploitMitigationReport(BaseModel):
    aslr_enabled: bool = False
    aslr_level: str = "unknown"
    dep_enabled: bool = False
    dep_policy: str = "unknown"
    acg_enabled: bool = False
    os: str = ""
    risk_summary: str = ""
    severity: str = "info"
class InstallationVisibilityReport(BaseModel):
    boot_time: str = ""
    install_path: str = ""
    running_as_username: str = ""
    running_as_admin: bool = False
    os_name: str = ""
    os_release: str = ""
    os_machine: str = ""
    hostname: str = ""
    agent_version: str = ""
class NetworkDPIReport(BaseModel):
    src_ip: str = ""
    dst_ip: str = ""
    src_port: int = 0
    dst_port: int = 0
    protocol: str = ""
    reason: str = ""
    payload_size: int = 0
    threat_type: str = ""
class PrivilegeEscalationReport(BaseModel):
    check_type: str = ""
    os: str = ""
    finding: str = ""
    process_name: str = ""
    user: str = ""
    privilege: str = ""
    risk_reason: str = ""
    severity: str = "medium"
class SilentDeploymentReport(BaseModel):
    no_window: bool = False
    hidden: bool = False
    startup_type: str = "user"
    process_name: str = ""
    parent_process: str = ""
    is_silent: bool = False
class LateralMovementReport(BaseModel):
    movement_type: str = ""
    source_ip: str = ""
    destination_ip: str = ""
    port: int = 0
    service: str = ""
    connection_count: int = 0
    risk: str = ""
    description: str = ""
class PortScanReport(BaseModel):
    scan_type: str = ""
    scanner_ip: str = ""
    target_ip: str = ""
    unique_ports: int = 0
    sensitive_ports_hit: bool = False
    syn_count: int = 0
    risk: str = ""
    description: str = ""
class HostFirewallReport(BaseModel):
    chain: str = ""
    rule: str = ""
    ip_blocked: str = ""
    action: str = ""
class WebDNSFilterReport(BaseModel):
    domain: str = ""
    url: str = ""
    action: str = ""
    matched_pattern: str = ""
class ScriptMonitorReport(BaseModel):
    command: str = ""
    user: str = ""
    suspicious_patterns: list[str] = []
    action: str = ""
class RansomwareCanaryReport(BaseModel):
    file_path: str = ""
    reason: str = ""
    file_hash: str = ""
    directory: str = ""
class CredentialDumpingReport(BaseModel):
    process_name: str = ""
    pid: int = 0
    detection_type: str = ""
class NextGenAVReport(BaseModel):
    file_path: str = ""
    file_hash: str = ""
    detection_reason: str = ""
    action: str = ""
    scanner_type: str = ""
class UserBehaviourReport(BaseModel):
    file_path: str = ""
    action: str = ""
    baseline_hash: str = ""
    current_hash: str = ""
MITRE_TACTICS = {
    "TA0001": {"name": "Initial Access", "order": 1},
    "TA0002": {"name": "Execution", "order": 2},
    "TA0003": {"name": "Persistence", "order": 3},
    "TA0004": {"name": "Privilege Escalation", "order": 4},
    "TA0005": {"name": "Defense Evasion", "order": 5},
    "TA0006": {"name": "Credential Access", "order": 6},
    "TA0007": {"name": "Discovery", "order": 7},
    "TA0008": {"name": "Lateral Movement", "order": 8},
    "TA0009": {"name": "Collection", "order": 9},
    "TA0011": {"name": "Command and Control", "order": 10},
    "TA0040": {"name": "Impact", "order": 11}, }
MITRE_TECHNIQUES = {
    "T1059": {"name": "Command and Scripting Interpreter", "tactic": "TA0002"},
    "T1055": {"name": "Process Injection", "tactic": "TA0005"},
    "T1003": {"name": "OS Credential Dumping", "tactic": "TA0006"},
    "T1078": {"name": "Valid Accounts", "tactic": "TA0003"},
    "T1087": {"name": "Account Discovery", "tactic": "TA0007"},
    "T1049": {"name": "System Network Connections Discovery", "tactic": "TA0007"},
    "T1021": {"name": "Remote Services", "tactic": "TA0008"},
    "T1574": {"name": "Hijack Execution Flow", "tactic": "TA0004"},
    "T1112": {"name": "Modify Registry", "tactic": "TA0005"},
    "T1547": {"name": "Boot or Logon Autostart Execution", "tactic": "TA0003"},
    "T1053": {"name": "Scheduled Task/Job", "tactic": "TA0003"},
    "T1485": {"name": "Data Destruction", "tactic": "TA0040"},
    "T1490": {"name": "Inhibit System Recovery", "tactic": "TA0040"},
    "T1562": {"name": "Impair Defenses", "tactic": "TA0005"},
    "T1566": {"name": "Phishing", "tactic": "TA0001"},
    "T1204": {"name": "User Execution", "tactic": "TA0002"},
    "T1105": {"name": "Ingress Tool Transfer", "tactic": "TA0011"},
    "T1071": {"name": "Application Layer Protocol", "tactic": "TA0011"},
    "T1090": {"name": "Proxy", "tactic": "TA0011"},
    "T1486": {"name": "Data Encrypted for Impact", "tactic": "TA0040"},
    "T1041": {"name": "Exfiltration Over C2 Channel", "tactic": "TA0011"},
    "T1007": {"name": "System Service Discovery", "tactic": "TA0007"},
    "T1035": {"name": "Service Execution", "tactic": "TA0002"},
    "T1018": {"name": "Remote System Discovery", "tactic": "TA0007"},
    "T1550": {"name": "Use Alternate Authentication Material", "tactic": "TA0008"},
    "T1555": {"name": "Credentials from Password Stores", "tactic": "TA0006"},
    "T1036": {"name": "Masquerading", "tactic": "TA0005"},
    "T1218": {"name": "Signed Binary Proxy Execution", "tactic": "TA0005"},
    "T1134": {"name": "Access Token Manipulation", "tactic": "TA0004"},
    "T1543": {"name": "Create or Modify System Process", "tactic": "TA0003"}, }
ALERT_TYPES = {
    "malware": {"severity": "critical", "mitre_technique": "T1204", "score_range": (80, 100)},
    "phishing": {"severity": "high", "mitre_technique": "T1566", "score_range": (60, 90)},
    "c2_beaconing": {"severity": "critical", "mitre_technique": "T1071", "score_range": (85, 100)},
    "privilege_escalation": {"severity": "high", "mitre_technique": "T1134", "score_range": (70, 95)},
    "fileless_malware": {"severity": "critical", "mitre_technique": "T1055", "score_range": (80, 100)},
    "ransomware": {"severity": "critical", "mitre_technique": "T1486", "score_range": (90, 100)},
    "port_scan": {"severity": "medium", "mitre_technique": "T1049", "score_range": (30, 60)},
    "misconfiguration": {"severity": "medium", "mitre_technique": "T1562", "score_range": (20, 50)},
    "shadow_it": {"severity": "low", "mitre_technique": "T1078", "score_range": (10, 30)},
    "credential_dumping": {"severity": "critical", "mitre_technique": "T1003", "score_range": (85, 100)},
    "lateral_movement": {"severity": "high", "mitre_technique": "T1021", "score_range": (75, 95)},
    "tamper": {"severity": "high", "mitre_technique": "T1562", "score_range": (70, 90)},
    "usb_violation": {"severity": "medium", "mitre_technique": "T1090", "score_range": (30, 55)},
    "policy_violation": {"severity": "low", "mitre_technique": "T1078", "score_range": (10, 25)},
    "zero_day": {"severity": "critical", "mitre_technique": "T1204", "score_range": (95, 100)},
    "lolbin": {"severity": "high", "mitre_technique": "T1218", "score_range": (60, 85)},
    "c2_dns": {"severity": "critical", "mitre_technique": "T1071", "score_range": (80, 100)},
    "beaconing": {"severity": "high", "mitre_technique": "T1071", "score_range": (65, 90)},
    "reconnaissance": {"severity": "medium", "mitre_technique": "T1087", "score_range": (25, 50)},
    "exploit": {"severity": "critical", "mitre_technique": "T1204", "score_range": (80, 100)}, }
MITRE_ATTACK_MAP = {
    "asset_discovery": {"technique_id": "T1082", "tactic_id": "TA0007", "technique_name": "System Information Discovery"},
    "os_patch_monitoring": {"technique_id": "T1190", "tactic_id": "TA0001", "technique_name": "Exploit Public-Facing Application"},
    "misconfiguration_detection": {"technique_id": "T1068", "tactic_id": "TA0004", "technique_name": "Exploitation for Privilege Escalation"},
    "file_integrity_monitoring": {"technique_id": "T1565", "tactic_id": "TA0040", "technique_name": "Data Manipulation"},
    "behavioral_heuristics": {"technique_id": "T1562", "tactic_id": "TA0005", "technique_name": "Impair Defenses"},
    "privilege_escalation_alert": {"technique_id": "T1068", "tactic_id": "TA0004", "technique_name": "Exploitation for Privilege Escalation"},
    "credential_dumping_protection": {"technique_id": "T1003", "tactic_id": "TA0006", "technique_name": "OS Credential Dumping"},
    "c2_beaconing_detection": {"technique_id": "T1071", "tactic_id": "TA0011", "technique_name": "Application Layer Protocol"},
    "lateral_movement_alert": {"technique_id": "T1021", "tactic_id": "TA0008", "technique_name": "Remote Services"},
    "usb_device_control": {"technique_id": "T1091", "tactic_id": "TA0005", "technique_name": "Replication Through Removable Media"},
    "watchdog_process": {"technique_id": "T1562", "tactic_id": "TA0005", "technique_name": "Impair Defenses"},
    "agent_monitoring": {"technique_id": "T1082", "tactic_id": "TA0007", "technique_name": "System Information Discovery"},
    "cross_platform_telemetry": {"technique_id": "T1082", "tactic_id": "TA0007", "technique_name": "System Information Discovery"},
    "pre_execution_prevention": {"technique_id": "T1055", "tactic_id": "TA0005", "technique_name": "Process Injection"},
    "registry_monitoring": {"technique_id": "T1112", "tactic_id": "TA0005", "technique_name": "Modify Registry"},
    "zero_day_detection": {"technique_id": "T1204", "tactic_id": "TA0002", "technique_name": "User Execution"},
    "buffer_polish": {"technique_id": "T1082", "tactic_id": "TA0007", "technique_name": "System Information Discovery"},
    "fileless_detection": {"technique_id": "T1055", "tactic_id": "TA0005", "technique_name": "Process Injection"},
    "memory_scan": {"technique_id": "T1007", "tactic_id": "TA0007", "technique_name": "System Service Discovery"},
    "usb_disk_control": {"technique_id": "T1091", "tactic_id": "TA0005", "technique_name": "Replication Through Removable Media"},
    "c2_beaconing": {"technique_id": "T1071", "tactic_id": "TA0011", "technique_name": "Application Layer Protocol"},
    "threat_intel": {"technique_id": "T1588", "tactic_id": "TA0042", "technique_name": "Obtain Capabilities"},
    "offline_protection": {"technique_id": "T1562", "tactic_id": "TA0005", "technique_name": "Impair Defenses"},
    "vulnerability_scan": {"technique_id": "T1588", "tactic_id": "TA0042", "technique_name": "Obtain Capabilities"},
    "process_tree": {"technique_id": "T1057", "tactic_id": "TA0007", "technique_name": "Process Discovery"},
    "shadow_it": {"technique_id": "T1040", "tactic_id": "TA0007", "technique_name": "Network Sniffing"},
    "exploit_mitigation": {"technique_id": "T1562", "tactic_id": "TA0005", "technique_name": "Impair Defenses"},
    "installation_visibility": {"technique_id": "T1082", "tactic_id": "TA0007", "technique_name": "System Information Discovery"},
    "network_dpi": {"technique_id": "T1040", "tactic_id": "TA0007", "technique_name": "Network Sniffing"},
    "privilege_escalation": {"technique_id": "T1068", "tactic_id": "TA0004", "technique_name": "Exploitation for Privilege Escalation"},
    "silent_deployment": {"technique_id": "T1562", "tactic_id": "TA0005", "technique_name": "Impair Defenses"},
    "lateral_movement": {"technique_id": "T1021", "tactic_id": "TA0008", "technique_name": "Remote Services"},
    "port_scan": {"technique_id": "T1046", "tactic_id": "TA0043", "technique_name": "Network Service Discovery"},
    "host_firewall": {"technique_id": "T1562", "tactic_id": "TA0005", "technique_name": "Impair Defenses"},
    "web_dns_filter": {"technique_id": "T1071", "tactic_id": "TA0011", "technique_name": "Application Layer Protocol"},
    "script_monitor": {"technique_id": "T1059", "tactic_id": "TA0002", "technique_name": "Command and Scripting Interpreter"},
    "ransomware_canary": {"technique_id": "T1486", "tactic_id": "TA0040", "technique_name": "Data Encrypted for Impact"},
    "credential_dumping": {"technique_id": "T1003", "tactic_id": "TA0006", "technique_name": "OS Credential Dumping"},
    "next_gen_av": {"technique_id": "T1562", "tactic_id": "TA0005", "technique_name": "Impair Defenses"},
    "user_behaviour": {"technique_id": "T1070", "tactic_id": "TA0005", "technique_name": "Indicator Removal on Host"}, }
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
# --- Auth ---
import jwt
JWT_ALGORITHM = "HS256"
JWT_EXPIRE_MINUTES = 60 * 24  # 24 hours
def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    pwd_hash = hashlib.sha256((salt + password).encode()).hexdigest()
    return f"{salt}:{pwd_hash}"
def verify_password(password: str, stored: str) -> bool:
    if not stored or ":" not in stored:
        return False
    salt, stored_hash = stored.split(":", 1)
    computed = hashlib.sha256((salt + password).encode()).hexdigest()
    return secrets.compare_digest(computed, stored_hash)
def create_access_token(user_id: str) -> str:
    payload = {
        "sub": user_id,
        "exp": datetime.utcnow() + timedelta(minutes=JWT_EXPIRE_MINUTES),
        "iat": datetime.utcnow(),
    }
    return jwt.encode(payload, SECRET_KEY, algorithm=JWT_ALGORITHM)
def decode_access_token(token: str) -> Optional[str]:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[JWT_ALGORITHM])
        return payload.get("sub")
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login", auto_error=False)
async def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    """Authenticates a human dashboard user via JWT."""
    if not token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    user_id = decode_access_token(token)
    if not user_id:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    user = db.query(User).filter(User.id == user_id, User.is_active == True).first()
    if not user:
        raise HTTPException(status_code=401, detail="User not found or inactive")
    return user
async def get_optional_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> Optional[User]:
    if not token:
        return None
    user_id = decode_access_token(token)
    if not user_id:
        return None
    return db.query(User).filter(User.id == user_id).first()
def get_owned_agent(agent_id: str, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)) -> Agent:
    """Use on /api/agents/{agent_id}/... dashboard routes. Confirms the
    logged-in user actually owns the agent referenced in the URL path."""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    if agent.owner_id is not None and agent.owner_id != current_user.id:
        raise HTTPException(status_code=403, detail="You do not have access to this agent")
    return agent
def verify_agent_self(agent_id: str, x_agent_token: str = Header(default=""),
                       db: Session = Depends(get_db)) -> Agent:
    """Use on /api/agents/{agent_id}/.../report routes — these are called
    by the AGENT itself reporting its own telemetry, not by a human user.
    No human JWT is required here, but the agent MUST present the secret
    agent_token it received at registration via the X-Agent-Token header.
    This prevents anyone who merely knows/guesses a valid agent_id from
    spoofing telemetry on that agent's behalf."""
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    if not agent.agent_token:
        # Agents registered before this fix was deployed have no token yet —
        # allow once, but this is a temporary migration shim, not a security model.
        return agent
    if not x_agent_token or not secrets.compare_digest(x_agent_token, agent.agent_token):
        raise HTTPException(status_code=401, detail="Invalid or missing X-Agent-Token header")
    return agent
def calculate_security_score(db: Session, agent: Agent = None, user: User = None):
    if agent:
        total_alerts = db.query(func.count(Alert.id)).filter(Alert.agent_id == agent.id).scalar() or 0
        open_alerts = db.query(func.count(Alert.id)).filter(Alert.agent_id == agent.id, Alert.status == "open").scalar() or 0
        critical_alerts = db.query(func.count(Alert.id)).filter(Alert.agent_id == agent.id, Alert.severity == "critical").scalar() or 0
        agents = [agent]
        unapproved = db.query(func.count(Application.id)).filter(Application.agent_id == agent.id, Application.is_approved == False).scalar() or 0
        suspicious_connections = db.query(func.count(NetworkConnection.id)).filter(NetworkConnection.agent_id == agent.id, NetworkConnection.is_suspicious == True).scalar() or 0
    elif user:
        agents = db.query(Agent).filter(Agent.owner_id == user.id).all()
        agent_ids = [a.id for a in agents]
        total_alerts = db.query(func.count(Alert.id)).filter(Alert.agent_id.in_(agent_ids)).scalar() or 0
        open_alerts = db.query(func.count(Alert.id)).filter(Alert.agent_id.in_(agent_ids), Alert.status == "open").scalar() or 0
        critical_alerts = db.query(func.count(Alert.id)).filter(Alert.agent_id.in_(agent_ids), Alert.severity == "critical").scalar() or 0
        unapproved = db.query(func.count(Application.id)).filter(Application.agent_id.in_(agent_ids), Application.is_approved == False).scalar() or 0
        suspicious_connections = db.query(func.count(NetworkConnection.id)).filter(NetworkConnection.agent_id.in_(agent_ids), NetworkConnection.is_suspicious == True).scalar() or 0
    else:
        total_alerts = db.query(func.count(Alert.id)).scalar() or 0
        open_alerts = db.query(func.count(Alert.id)).filter(Alert.status == "open").scalar() or 0
        critical_alerts = db.query(func.count(Alert.id)).filter(Alert.severity == "critical").scalar() or 0
        agents = db.query(Agent).all()
        unapproved = db.query(func.count(Application.id)).filter(Application.is_approved == False).scalar() or 0
        suspicious_connections = db.query(func.count(NetworkConnection.id)).filter(NetworkConnection.is_suspicious == True).scalar() or 0
    total_agents = len(agents)
    online_agents = sum(1 for a in agents if a.status == "online")
    tamper_protected = sum(1 for a in agents if a.tamper_protection)
    firewall_enabled_count = sum(1 for a in agents if a.firewall_enabled)
    bitlocker_count = sum(1 for a in agents if a.bitlocker_enabled)
    score = 100.0
    if total_agents > 0:
        online_ratio = online_agents / total_agents
        if online_ratio < 1.0:
            score -= (1.0 - online_ratio) * 15
    score -= open_alerts * 1.5
    score -= critical_alerts * 3.0
    if total_agents > 0:
        score -= (1.0 - (tamper_protected / total_agents)) * 10
        score -= (1.0 - (firewall_enabled_count / total_agents)) * 8
        score -= (1.0 - (bitlocker_count / total_agents)) * 5
    score -= unapproved * 1.0
    score -= suspicious_connections * 2.0
    score = max(0, min(100, score))
    return round(score, 1)

class ConnectionManager:
    def __init__(self):
        self.active_connections: list[WebSocket] = []
    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)
    async def broadcast(self, message: dict):
        dead = []
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception:
                dead.append(connection)  # client disconnected — stop tracking it instead of leaking it forever
        for connection in dead:
            self.active_connections.remove(connection)
ws_alerts = ConnectionManager()
ws_agents = ConnectionManager()
ws_monitoring: dict[str, ConnectionManager] = {}
def get_mitre_technique_name(technique_id: str) -> str:
    return MITRE_TECHNIQUES.get(technique_id, {}).get("name", "Unknown Technique")

def get_mitre_tactic_name(tactic_id: str) -> str:
    return MITRE_TACTICS.get(tactic_id, {}).get("name", "Unknown Tactic")

def generate_mac():
    return ":".join(f"{random.randint(0, 255):02X}" for _ in range(6))
def generate_memory_scan_findings():
    return [
        {"process": "svchost.exe", "pid": 1104, "region": "0x7ffa00000000", "size_kb": 4096, "protection": "RWX", "suspicious": True, "reason": "Executable memory in non-PE process"},
        {"process": "chrome.exe", "pid": 1560, "region": "0x7ffb00000000", "size_kb": 2048, "protection": "RW", "suspicious": False, "reason": ""},
    ]
def generate_misconfig_findings(db: Session, agent: Agent):
    findings = []
    if agent.os_type == "Windows" and not agent.bitlocker_enabled:
        findings.append({"type": "missing_encryption", "severity": "high", "detail": "BitLocker not enabled on system drive"})
    if not agent.firewall_enabled:
        findings.append({"type": "firewall_disabled", "severity": "high", "detail": "OS firewall is disabled"})
    if agent.os_type == "Windows":
        findings.append({"type": "rdp_exposed", "severity": "medium", "detail": "RDP port 3389 is accessible from network"})
        findings.append({"type": "guest_account_active", "severity": "high", "detail": "Built-in Guest account may be enabled"})
        findings.append({"type": "weak_password_policy", "severity": "medium", "detail": "Password policy may not meet minimum complexity requirements"})
    if agent.os_type == "Linux":
        findings.append({"type": "ssh_password_auth", "severity": "medium", "detail": "SSH password authentication may be enabled"})
        findings.append({"type": "firewall_inactive", "severity": "high", "detail": "UFW/iptables firewall may be inactive"})
    return findings
def generate_vulnerability_findings(db: Session, agent: Agent):
    findings = []
    cve_db = {
        "Google Chrome": [{"id": "CVE-2023-7024", "severity": "critical", "description": "Heap buffer overflow in WebRTC"}],
        "Mozilla Firefox": [{"id": "CVE-2023-6856", "severity": "high", "description": "Use-after-free in WebAudio"}],
        "Microsoft Office 365": [{"id": "CVE-2023-38545", "severity": "critical", "description": "Remote code execution via Office"}],
        "OpenSSH Server": [{"id": "CVE-2023-51385", "severity": "high", "description": "SSH prefix truncation attack"}],
        "Apache HTTP Server": [{"id": "CVE-2023-45802", "severity": "high", "description": "HTTP request smuggling"}],
        "PHP": [{"id": "CVE-2023-3824", "severity": "critical", "description": "Remote code execution in PHP"}],
    }
    apps = db.query(Application).filter(Application.agent_id == agent.id).all()
    for app in apps:
        if app.name in cve_db:
            for cve in cve_db[app.name]:
                findings.append({"app_name": app.name, "app_version": app.version, "cve_id": cve["id"], "severity": cve["severity"], "description": cve["description"], "status": "unpatched"})
    return findings
def generate_file_integrity_findings(db: Session, agent: Agent):
    findings = []
    target_files = []
    if agent.os_type == "Windows":
        target_files = [r"C:\Windows\System32\drivers\etc\hosts", r"C:\Windows\System32\config\SAM", r"C:\Windows\System32\config\SYSTEM"]
    elif agent.os_type == "Linux":
        target_files = ["/etc/passwd", "/etc/shadow", "/etc/ssh/sshd_config", "/etc/hosts"]
    changes = db.query(FileChange).filter(FileChange.agent_id == agent.id).order_by(FileChange.detected_at.desc()).limit(20).all()
    changed_files = [c.file_path for c in changes if c.change_type == "modified"]
    return {"monitored_files": target_files, "changes_detected": len(changed_files) > 0, "changed_files": changed_files, "recent_changes": [{"file_path": c.file_path, "change_type": c.change_type, "detected_at": c.detected_at.isoformat()} for c in changes[:5]]}
def generate_behavioral_findings(db: Session, agent: Agent):
    snapshots = db.query(BehavioralSnapshot).filter(BehavioralSnapshot.agent_id == agent.id).order_by(BehavioralSnapshot.detected_at.desc()).limit(10).all()
    recent = snapshots[:1]
    if recent:
        return {"cpu_usage": s.cpu_usage, "ram_usage": s.ram_usage, "process_count": s.process_count, "net_connections": s.net_connections, "is_anomaly": s.is_anomaly, "anomaly_score": s.anomaly_score, "ml_active": s.ml_active, "history_size": s.history_size, "snapshot_count": len(snapshots)}
    return {"cpu_usage": 0, "ram_usage": 0, "process_count": 0, "net_connections": 0, "is_anomaly": False, "anomaly_score": 0.0, "ml_active": False, "history_size": 0, "snapshot_count": 0}
def generate_patch_findings(db: Session, agent: Agent):
    patches = db.query(OSPatchInfo).filter(OSPatchInfo.agent_id == agent.id).order_by(OSPatchInfo.checked_at.desc()).first()
    if patches:
        return {"missing_patches": json.loads(patches.missing_patches) if isinstance(patches.missing_patches, str) else [], "count": patches.count, "oldest_missing_days": patches.oldest_missing_days, "severity": patches.severity, "last_checked": patches.checked_at.isoformat()}
    if agent.os_type == "Windows":
        return {"missing_patches": ["KB5034441", "KB5034122"], "count": 2, "oldest_missing_days": 45, "severity": "high", "last_checked": None}
    elif agent.os_type == "Linux":
        return {"missing_patches": ["linux-image-generic", "libssl1.1"], "count": 2, "oldest_missing_days": 12, "severity": "low", "last_checked": None}
    return {"missing_patches": [], "count": 0, "oldest_missing_days": 0, "severity": "info", "last_checked": None}
def generate_software_inventory(db: Session, agent: Agent):
    apps = db.query(Application).filter(Application.agent_id == agent.id).order_by(Application.name).all()
    return [{"name": a.name, "version": a.version, "vendor": a.vendor, "install_date": a.install_date.isoformat() if a.install_date else "", "is_approved": a.is_approved, "is_running": a.is_running, "risk_score": a.risk_score, "cve_list": json.loads(a.cve_list) if isinstance(a.cve_list, str) else []} for a in apps]
def generate_asset_discovery(agent: Agent):
    return {"hostname": agent.hostname, "os_type": agent.os_type, "os_version": agent.os_version, "os_patch_level": agent.os_patch_level, "architecture": agent.cpu_model, "processor": agent.cpu_model, "cpu_cores": agent.cpu_cores, "logical_cpus": agent.cpu_cores * 2 if agent.cpu_cores else 0, "ram_gb": agent.ram_total_gb, "mac_address": agent.mac_address, "ip_address": agent.ip_address, "status": agent.status, "cpu_usage": agent.cpu_usage, "ram_used_gb": agent.ram_used_gb, "disk_total_gb": agent.disk_total_gb, "disk_used_gb": agent.disk_used_gb}
def generate_watchdog_status(db: Session, agent: Agent):
    last_event = db.query(WatchdogEvent).filter(WatchdogEvent.agent_id == agent.id).order_by(WatchdogEvent.detected_at.desc()).first()
    total_restarts = db.query(func.sum(WatchdogEvent.restart_count)).filter(WatchdogEvent.agent_id == agent.id).scalar() or 0
    tamper_count = db.query(func.count(WatchdogEvent.id)).filter(WatchdogEvent.agent_id == agent.id, WatchdogEvent.tamper_detected == True).scalar() or 0
    if last_event:
        return {"agent_running": last_event.agent_running, "tamper_detected": last_event.tamper_detected, "restart_count": total_restarts, "tamper_events": tamper_count, "last_log": last_event.log_entry, "last_checked": last_event.detected_at.isoformat(), "self_defense": agent.self_defense_status, "tamper_protection": agent.tamper_protection}
    return {"agent_running": agent.status == "online", "tamper_detected": False, "restart_count": 0, "tamper_events": 0, "last_log": "", "last_checked": None, "self_defense": agent.self_defense_status, "tamper_protection": agent.tamper_protection}
def generate_monitoring_stats(db: Session, agent: Agent):
    logs = db.query(AgentMonitorLog).filter(AgentMonitorLog.agent_id == agent.id).order_by(AgentMonitorLog.recorded_at.desc()).limit(20).all()
    avg_cpu = db.query(func.avg(AgentMonitorLog.cpu_percent)).filter(AgentMonitorLog.agent_id == agent.id).scalar() or 0
    avg_ram = db.query(func.avg(AgentMonitorLog.ram_percent)).filter(AgentMonitorLog.agent_id == agent.id).scalar() or 0
    return {"current_cpu": agent.cpu_usage, "current_ram_gb": agent.ram_used_gb, "avg_cpu_percent": round(float(avg_cpu), 1), "avg_ram_percent": round(float(avg_ram), 1), "log_count": len(logs), "recent_logs": [{"cpu_percent": l.cpu_percent, "ram_percent": l.ram_percent, "recorded_at": l.recorded_at.isoformat()} for l in logs[:5]]}
def generate_execution_prevention_stats(db: Session, agent: Agent):
    events = db.query(ProcessExecutionEvent).filter(ProcessExecutionEvent.agent_id == agent.id).order_by(ProcessExecutionEvent.detected_at.desc()).limit(20).all()
    blocked_count = db.query(func.count(ProcessExecutionEvent.id)).filter(ProcessExecutionEvent.agent_id == agent.id, ProcessExecutionEvent.blocked == True).scalar() or 0
    total = db.query(func.count(ProcessExecutionEvent.id)).filter(ProcessExecutionEvent.agent_id == agent.id).scalar() or 0
    return {"total_events": total, "blocked_count": blocked_count, "clean_count": total - blocked_count, "recent_events": [{"process_name": e.process_name, "process_path": e.process_path, "blocked": e.blocked, "reason": e.reason, "detected_at": e.detected_at.isoformat()} for e in events[:10]]}
def generate_zero_day_stats(db: Session, agent: Agent):
    findings = db.query(ZeroDayFinding).filter(ZeroDayFinding.agent_id == agent.id).order_by(ZeroDayFinding.detected_at.desc()).limit(20).all()
    total = db.query(func.count(ZeroDayFinding.id)).filter(ZeroDayFinding.agent_id == agent.id).scalar() or 0
    return {"total_findings": total, "recent_findings": [{"file_name": f.file_name, "file_path": f.file_path, "unknown_hash": f.unknown_hash, "risky_location": f.risky_location, "detected_at": f.detected_at.isoformat()}
for f in findings[:10]]}
def generate_registry_monitoring_stats(db: Session, agent: Agent):
    changes = db.query(RegistryChange).filter(RegistryChange.agent_id == agent.id).order_by(RegistryChange.detected_at.desc()).limit(20).all()
    total = db.query(func.count(RegistryChange.id)).filter(RegistryChange.agent_id == agent.id).scalar() or 0
    auto_start = db.query(func.count(RegistryChange.id)).filter(RegistryChange.agent_id == agent.id, RegistryChange.is_auto_start == True).scalar() or 0
    return {"total_changes": total, "auto_start_changes": auto_start, "recent_changes": [{"key_path": c.key_path, "value_name": c.value_name, "change_type": c.change_type, "is_auto_start": c.is_auto_start, "detected_at": c.detected_at.isoformat()} for c in changes[:10]]}
def generate_fileless_stats(db: Session, agent: Agent):
    events = db.query(FilelessDetectionEvent).filter(FilelessDetectionEvent.agent_id == agent.id).order_by(FilelessDetectionEvent.detected_at.desc()).limit(20).all()
    total = db.query(func.count(FilelessDetectionEvent.id)).filter(FilelessDetectionEvent.agent_id == agent.id).scalar() or 0
    return {"total_events": total, "scan_ok": total == 0, "recent_events": [{"pid": e.pid, "process_name": e.process_name, "reason": e.reason, "eventlog_alert": e.eventlog_alert, "detected_at": e.detected_at.isoformat()}
for e in events[:10]]}
def generate_memory_scan_stats(db: Session, agent: Agent):
    events = db.query(MemoryScanEvent).filter(MemoryScanEvent.agent_id == agent.id).order_by(MemoryScanEvent.detected_at.desc()).limit(20).all()
    total = db.query(func.count(MemoryScanEvent.id)).filter(MemoryScanEvent.agent_id == agent.id).scalar() or 0
    shellcode = db.query(func.count(MemoryScanEvent.id)).filter(MemoryScanEvent.agent_id == agent.id, MemoryScanEvent.shellcode_detected == True).scalar() or 0
    return {"total_events": total, "scan_ok": total == 0, "shellcode_detected_count": shellcode, "recent_events": [{"pid": e.pid, "process_name": e.process_name, "reason": e.reason, "shellcode_detected": e.shellcode_detected, "detected_at": e.detected_at.isoformat()} for e in events[:10]]}
def generate_usb_disk_stats(db: Session, agent: Agent):
    last = db.query(UsbDiskEvent).filter(UsbDiskEvent.agent_id == agent.id).order_by(UsbDiskEvent.detected_at.desc()).first()
    total = db.query(func.count(UsbDiskEvent.id)).filter(UsbDiskEvent.agent_id == agent.id).scalar() or 0
    if last:
        return {"usb_devices": json.loads(last.usb_devices) if isinstance(last.usb_devices, str) else [], "blocked_devices": json.loads(last.blocked_devices) if isinstance(last.blocked_devices, str) else [], "usb_control_ok": last.usb_control_ok, "encrypted": last.encrypted, "protection_on": last.protection_on, "last_checked": last.detected_at.isoformat(), "total_scans": total}
    return {"usb_devices": [], "blocked_devices": [], "usb_control_ok": True, "encrypted": agent.bitlocker_enabled if agent.os_type == "Windows" else False, "protection_on": agent.bitlocker_enabled, "last_checked": None, "total_scans": 0}
def generate_c2_stats(db: Session, agent: Agent):
    events = db.query(C2BeaconingEvent).filter(C2BeaconingEvent.agent_id == agent.id).order_by(C2BeaconingEvent.detected_at.desc()).limit(20).all()
    total = db.query(func.count(C2BeaconingEvent.id)).filter(C2BeaconingEvent.agent_id == agent.id).scalar() or 0
    return {"total_beacons": total, "beaconing_detected": total > 0, "recent_events": [{"src_ip": e.src_ip, "dst_ip": e.dst_ip, "connections": e.connections, "avg_interval": e.avg_interval, "variance": e.variance, "detected_at": e.detected_at.isoformat()} for e in events[:10]]}
def generate_threat_intel_stats(db: Session, agent: Agent):
    results = db.query(LiveThreatIntelResult).filter(LiveThreatIntelResult.agent_id == agent.id).order_by(LiveThreatIntelResult.checked_at.desc()).limit(20).all()
    total = db.query(func.count(LiveThreatIntelResult.id)).filter(LiveThreatIntelResult.agent_id == agent.id).scalar() or 0
    return {"total_queries": total, "recent_queries": [{"indicator_type": r.indicator_type, "indicator": r.indicator, "pulse_count": r.pulse_count, "reputation": r.reputation, "country": r.country, "checked_at": r.checked_at.isoformat()} for r in results[:10]]}
def generate_offline_scan_stats(db: Session, agent: Agent):
    events = db.query(OfflineScanEvent).filter(OfflineScanEvent.agent_id == agent.id).order_by(OfflineScanEvent.detected_at.desc()).limit(20).all()
    total = db.query(func.count(OfflineScanEvent.id)).filter(OfflineScanEvent.agent_id == agent.id).scalar() or 0
    return {"total_scans": total, "threats_found_total": sum(e.threats_found for e in events), "recent_events": [{"file_path": e.file_path, "file_hash": e.file_hash, "threat_name": e.threat_name, "scan_directory": e.scan_directory, "threats_found": e.threats_found, "detected_at": e.detected_at.isoformat()} for e in events[:10]]}
def generate_vuln_scan_stats(db: Session, agent: Agent):
    findings = db.query(VulnerabilityFinding).filter(VulnerabilityFinding.agent_id == agent.id).order_by(VulnerabilityFinding.detected_at.desc()).limit(50).all()
    total = db.query(func.count(VulnerabilityFinding.id)).filter(VulnerabilityFinding.agent_id == agent.id).scalar() or 0
    critical = db.query(func.count(VulnerabilityFinding.id)).filter(VulnerabilityFinding.agent_id == agent.id, VulnerabilityFinding.severity == "Critical").scalar() or 0
    high = db.query(func.count(VulnerabilityFinding.id)).filter(VulnerabilityFinding.agent_id == agent.id, VulnerabilityFinding.severity == "High").scalar() or 0
    return {"total_findings": total, "critical": critical, "high": high, "recent_findings": [{"finding_type": f.finding_type, "software": f.software, "cve_id": f.cve_id, "severity": f.severity, "port": f.port, "service": f.service, "description": f.description, "detected_at": f.detected_at.isoformat()} for f in findings[:10]]}
def generate_process_tree_stats(db: Session, agent: Agent):
    findings = db.query(ProcessTreeFinding).filter(ProcessTreeFinding.agent_id == agent.id).order_by(ProcessTreeFinding.detected_at.desc()).limit(50).all()
    total = db.query(func.count(ProcessTreeFinding.id)).filter(ProcessTreeFinding.agent_id == agent.id).scalar() or 0
    high = db.query(func.count(ProcessTreeFinding.id)).filter(ProcessTreeFinding.agent_id == agent.id, ProcessTreeFinding.risk == "HIGH").scalar() or 0
    critical = db.query(func.count(ProcessTreeFinding.id)).filter(ProcessTreeFinding.agent_id == agent.id, ProcessTreeFinding.risk == "CRITICAL").scalar() or 0
    return {"total_findings": total, "high": high, "critical": critical, "recent_findings": [{"finding_type": f.finding_type, "parent_name": f.parent_name, "child_name": f.child_name, "risk": f.risk, "description": f.description, "detected_at": f.detected_at.isoformat()} for f in findings[:10]]}
def generate_shadow_it_stats(db: Session, agent: Agent):
    findings = db.query(ShadowITFinding).filter(ShadowITFinding.agent_id == agent.id).order_by(ShadowITFinding.detected_at.desc()).limit(50).all()
    total = db.query(func.count(ShadowITFinding.id)).filter(ShadowITFinding.agent_id == agent.id).scalar() or 0
    return {"total_findings": total, "recent_findings": [{"finding_type": f.finding_type, "service_name": f.service_name, "domain": f.domain, "category": f.category, "risk": f.risk, "description": f.description, "detected_at": f.detected_at.isoformat()} for f in findings[:10]]}
def generate_exploit_mitigation_stats(db: Session, agent: Agent):
    events = db.query(ExploitMitigationEvent).filter(ExploitMitigationEvent.agent_id == agent.id).order_by(ExploitMitigationEvent.detected_at.desc()).limit(20).all()
    total = db.query(func.count(ExploitMitigationEvent.id)).filter(ExploitMitigationEvent.agent_id == agent.id).scalar() or 0
    last = events[0] if events else None
    if last:
        return {"total_scans": total, "aslr_enabled": last.aslr_enabled, "aslr_level": last.aslr_level, "dep_enabled": last.dep_enabled, "dep_policy": last.dep_policy, "acg_enabled": last.acg_enabled, "os": last.os, "risk_summary": last.risk_summary, "severity": last.severity, "last_checked": last.detected_at.isoformat()}
    return {"total_scans": 0, "aslr_enabled": False, "aslr_level": "unknown", "dep_enabled": False, "dep_policy": "unknown", "acg_enabled": False, "os": agent.os_type, "risk_summary": "No data", "severity": "info", "last_checked": None}
def generate_installation_visibility_stats(db: Session, agent: Agent):
    events = db.query(InstallationVisibilityEvent).filter(InstallationVisibilityEvent.agent_id == agent.id).order_by(InstallationVisibilityEvent.detected_at.desc()).limit(20).all ()
    total = db.query(func.count(InstallationVisibilityEvent.id)).filter(InstallationVisibilityEvent.agent_id == agent.id).scalar() or 0
    last = events[0] if events else None
    if last:
        return {"total_events": total, "boot_time": last.boot_time, "install_path": last.install_path, "username": last.running_as_username, "is_admin": last.running_as_admin, "os_name": last.os_name, "os_release": last.os_release, "hostname": last.hostname, "agent_version": last.agent_version, "last_reported": last.detected_at.isoformat()}
    return {"total_events": 0, "boot_time": "", "install_path": "", "username": "", "is_admin": False, "os_name": agent.os_type, "os_release": "", "hostname": agent.hostname, "agent_version": "", "last_reported": None}
def generate_network_dpi_stats(db: Session, agent: Agent):
    events = db.query(NetworkDPIEvent).filter(NetworkDPIEvent.agent_id == agent.id).order_by(NetworkDPIEvent.detected_at.desc()).limit(50).all()
    total = db.query(func.count(NetworkDPIEvent.id)).filter(NetworkDPIEvent.agent_id == agent.id).scalar() or 0
    threat_counts = {}
    for e in events:
        threat_counts[e.threat_type] = threat_counts.get(e.threat_type, 0) + 1
    return {"total_events": total, "threat_breakdown": threat_counts, "recent_events": [{"src_ip": e.src_ip, "dst_ip": e.dst_ip, "dst_port": e.dst_port, "protocol": e.protocol, "threat_type": e.threat_type, "reason": e.reason, "detected_at": e.detected_at.isoformat()} for e in events[:10]]}
def generate_privilege_escalation_stats(db: Session, agent: Agent):
    events = db.query(PrivilegeEscalationEvent).filter(PrivilegeEscalationEvent.agent_id == agent.id).order_by(PrivilegeEscalationEvent.detected_at.desc()).limit(50).all()
    total = db.query(func.count(PrivilegeEscalationEvent.id)).filter(PrivilegeEscalationEvent.agent_id == agent.id).scalar() or 0
    critical = db.query(func.count(PrivilegeEscalationEvent.id)).filter(PrivilegeEscalationEvent.agent_id == agent.id, PrivilegeEscalationEvent.severity == "critical").scalar() or 0
    high = db.query(func.count(PrivilegeEscalationEvent.id)).filter(PrivilegeEscalationEvent.agent_id == agent.id, PrivilegeEscalationEvent.severity == "high").scalar() or 0
    return {"total_events": total, "critical": critical, "high": high, "recent_events": [{"check_type": e.check_type, "finding": e.finding, "process_name": e.process_name, "user": e.user, "privilege": e.privilege, "severity": e.severity, "detected_at": e.detected_at.isoformat()} for e in events[:10]]}
def generate_silent_deployment_stats(db: Session, agent: Agent):
    events = db.query(SilentDeploymentEvent).filter(SilentDeploymentEvent.agent_id == agent.id).order_by(SilentDeploymentEvent.detected_at.desc()).limit(20).all()
    total = db.query(func.count(SilentDeploymentEvent.id)).filter(SilentDeploymentEvent.agent_id == agent.id).scalar() or 0
    last = events[0] if events else None
    if last:
        return {"total_scans": total, "no_window": last.no_window, "hidden": last.hidden, "startup_type": last.startup_type, "process_name": last.process_name, "parent_process": last.parent_process, "is_silent": last.is_silent, "last_checked": last.detected_at.isoformat()}
    return {"total_scans": 0, "no_window": False, "hidden": False, "startup_type": "user", "process_name": "", "parent_process": "", "is_silent": False, "last_checked": None}
def generate_lateral_movement_stats(db: Session, agent: Agent):
    events = db.query(LateralMovementEvent).filter(LateralMovementEvent.agent_id == agent.id).order_by(LateralMovementEvent.detected_at.desc()).limit(50).all()
    total = db.query(func.count(LateralMovementEvent.id)).filter(LateralMovementEvent.agent_id == agent.id).scalar() or 0
    high = db.query(func.count(LateralMovementEvent.id)).filter(LateralMovementEvent.agent_id == agent.id, LateralMovementEvent.risk == "HIGH").scalar() or 0
    critical = db.query(func.count(LateralMovementEvent.id)).filter(LateralMovementEvent.agent_id == agent.id, LateralMovementEvent.risk == "CRITICAL").scalar() or 0
    return {"total_events": total, "high": high, "critical": critical, "recent_events": [{"movement_type": e.movement_type, "source_ip": e.source_ip, "destination_ip": e.destination_ip, "port": e.port, "service": e.service, "risk": e.risk, "description": e.description, "detected_at": e.detected_at.isoformat()} for e in events[:10]]}
def generate_port_scan_stats(db: Session, agent: Agent):
    events = db.query(PortScanEvent).filter(PortScanEvent.agent_id == agent.id).order_by(PortScanEvent.detected_at.desc()).limit(50).all()
    total = db.query(func.count(PortScanEvent.id)).filter(PortScanEvent.agent_id == agent.id).scalar() or 0
    high = db.query(func.count(PortScanEvent.id)).filter(PortScanEvent.agent_id == agent.id, PortScanEvent.risk == "HIGH").scalar() or 0
    return {"total_events": total, "high": high, "recent_events": [{"scan_type": e.scan_type, "scanner_ip": e.scanner_ip, "target_ip": e.target_ip, "unique_ports": e.unique_ports, "sensitive_ports_hit": e.sensitive_ports_hit, "risk": e.risk, "description": e.description, "detected_at": e.detected_at.isoformat()} for e in events[:10]]}
def generate_host_firewall_stats(db: Session, agent: Agent):
    events = db.query(HostFirewallEvent).filter(HostFirewallEvent.agent_id == agent.id).order_by(HostFirewallEvent.detected_at.desc()).limit(20).all()
    total = db.query(func.count(HostFirewallEvent.id)).filter(HostFirewallEvent.agent_id == agent.id).scalar() or 0
    blocks = db.query(func.count(HostFirewallEvent.id)).filter(HostFirewallEvent.agent_id == agent.id, HostFirewallEvent.action == "BLOCK").scalar() or 0
    return {"total_events": total, "blocks": blocks, "recent_events": [{"chain": e.chain, "rule": e.rule, "ip_blocked": e.ip_blocked, "action": e.action, "detected_at": e.detected_at.isoformat()} for e in events[:10]]}
def generate_web_dns_filter_stats(db: Session, agent: Agent):
    events = db.query(WebDNSFilterEvent).filter(WebDNSFilterEvent.agent_id == agent.id).order_by(WebDNSFilterEvent.detected_at.desc()).limit(20).all()
    total = db.query(func.count(WebDNSFilterEvent.id)).filter(WebDNSFilterEvent.agent_id == agent.id).scalar() or 0
    blocked = db.query(func.count(WebDNSFilterEvent.id)).filter(WebDNSFilterEvent.agent_id == agent.id, WebDNSFilterEvent.action == "BLOCK").scalar() or 0
    return {"total_events": total, "blocked": blocked, "recent_events": [{"domain": e.domain, "url": e.url, "action": e.action, "matched_pattern": e.matched_pattern, "detected_at": e.detected_at.isoformat()} for e in events[:10]]}
def generate_script_monitor_stats(db: Session, agent: Agent):
    events = db.query(ScriptMonitorEvent).filter(ScriptMonitorEvent.agent_id == agent.id).order_by(ScriptMonitorEvent.detected_at.desc()).limit(20).all()
    total = db.query(func.count(ScriptMonitorEvent.id)).filter(ScriptMonitorEvent.agent_id == agent.id).scalar() or 0
    blocked = db.query(func.count(ScriptMonitorEvent.id)).filter(ScriptMonitorEvent.agent_id == agent.id, ScriptMonitorEvent.action == "BLOCK").scalar() or 0
    alerted = db.query(func.count(ScriptMonitorEvent.id)).filter(ScriptMonitorEvent.agent_id == agent.id, ScriptMonitorEvent.action == "ALERT").scalar() or 0
    return {"total_events": total, "blocked": blocked, "alerted": alerted, "recent_events": [{"command": e.command[:80], "user": e.user, "suspicious_patterns": e.suspicious_patterns, "action": e.action, "detected_at": e.detected_at.isoformat()} for e in events[:10]]}
def generate_ransomware_canary_stats(db: Session, agent: Agent):
    events = db.query(RansomwareCanaryEvent).filter(RansomwareCanaryEvent.agent_id == agent.id).order_by(RansomwareCanaryEvent.detected_at.desc()).limit(20).all()
    total = db.query(func.count(RansomwareCanaryEvent.id)).filter(RansomwareCanaryEvent.agent_id == agent.id).scalar() or 0
    tampered = db.query(func.count(RansomwareCanaryEvent.id)).filter(RansomwareCanaryEvent.agent_id == agent.id, RansomwareCanaryEvent.reason != "").scalar() or 0
    return {"total_events": total, "tampered": tampered, "recent_events": [{"file_path": e.file_path, "reason": e.reason, "directory": e.directory, "detected_at": e.detected_at.isoformat()} for e in events[:10]]}
def generate_credential_dumping_stats(db: Session, agent: Agent):
    events = db.query(CredentialDumpingEvent).filter(CredentialDumpingEvent.agent_id == agent.id).order_by(CredentialDumpingEvent.detected_at.desc()).limit(20).all()
    total = db.query(func.count(CredentialDumpingEvent.id)).filter(CredentialDumpingEvent.agent_id == agent.id).scalar() or 0
    return {"total_events": total, "recent_events": [{"process_name": e.process_name, "pid": e.pid, "detection_type": e.detection_type, "detected_at": e.detected_at.isoformat()} for e in events[:10]]}
def generate_next_gen_av_stats(db: Session, agent: Agent):
    events = db.query(NextGenAVEvent).filter(NextGenAVEvent.agent_id == agent.id).order_by(NextGenAVEvent.detected_at.desc()).limit(20).all()
    total = db.query(func.count(NextGenAVEvent.id)).filter(NextGenAVEvent.agent_id == agent.id).scalar() or 0
    malicious = db.query(func.count(NextGenAVEvent.id)).filter(NextGenAVEvent.agent_id == agent.id, NextGenAVEvent.action == "malicious").scalar() or 0
    quarantined = db.query(func.count(NextGenAVEvent.id)).filter(NextGenAVEvent.agent_id == agent.id, NextGenAVEvent.action == "quarantined").scalar() or 0
    return {"total_events": total, "malicious": malicious, "quarantined": quarantined, "recent_events": [{"file_path": e.file_path, "file_hash": e.file_hash, "detection_reason": e.detection_reason, "action": e.action, "scanner_type": e.scanner_type, "detected_at": e.detected_at.isoformat()} for e in events[:10]]}
def generate_user_behaviour_stats(db: Session, agent: Agent):
    events = db.query(UserBehaviourEvent).filter(UserBehaviourEvent.agent_id == agent.id).order_by(UserBehaviourEvent.detected_at.desc()).limit(20).all()
    total = db.query(func.count(UserBehaviourEvent.id)).filter(UserBehaviourEvent.agent_id == agent.id).scalar() or 0
    tamper = db.query(func.count(UserBehaviourEvent.id)).filter(UserBehaviourEvent.agent_id == agent.id, UserBehaviourEvent.action.in_(["modified", "deleted"])).scalar() or 0
    return {"total_events": total, "tamper_events": tamper, "recent_events": [{"file_path": e.file_path, "action": e.action, "baseline_hash": e.baseline_hash, "current_hash": e.current_hash, "detected_at": e.detected_at.isoformat()} for e in events[:10]]}
from contextlib import asynccontextmanager

@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        pass  # No auth setup needed
        if db.query(func.count(Agent.id)).scalar() == 0:
            db.add(Policy(key="usb_control_enabled", value="true", description="USB device control policy", updated_at=datetime.utcnow()))
            db.add(Policy(key="web_filter_enabled", value="true", description="Web content filtering policy", updated_at=datetime.utcnow()))
            db.add(Policy(key="phishing_protection_enabled", value="true", description="Phishing protection policy", updated_at=datetime.utcnow()))
            db.add(Policy(key="app_whitelisting_enabled", value="true", description="Application whitelisting policy", updated_at=datetime.utcnow()))
            db.add(Policy(key="behavioral_heuristics_enabled", value="true", description="Behavioral heuristics policy", updated_at=datetime.utcnow()))
            db.add(Policy(key="threat_intel_sync_enabled", value="true", description="Threat intel sync policy", updated_at=datetime.utcnow()))
            db.add(Policy(key="auto_quarantine_enabled", value="false", description="Auto quarantine policy", updated_at=datetime.utcnow()))
            db.commit()
    except Exception as e:
        logger.error("Default policy seeding failed — defaults were not created", error=str(e))
        db.rollback()
    finally:
        db.close()
    yield

app = FastAPI(title="Agent Security EDR/XDR Platform", version="3.5.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"], )
@app.get("/api/health")
async def health_check():
    return {"status": "healthy", "version": "3.5.0", "timestamp": datetime.utcnow().isoformat(), "service": "Agent Security EDR/XDR Platform"}
class UserRegister(BaseModel):
    email: str
    password: str
class UserLogin(BaseModel):
    email: str
    password: str
@app.post("/api/auth/register")
async def register_user(data: UserRegister, db: Session = Depends(get_db)):
    email = data.email.strip().lower()
    if "@" not in email or "." not in email.split("@")[-1]:
        raise HTTPException(status_code=400, detail="Invalid email address")
    if len(data.password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters")
    existing = db.query(User).filter(User.email == email).first()
    if existing:
        raise HTTPException(status_code=409, detail="An account with this email already exists")
    user = User(email=email, password_hash=hash_password(data.password))
    db.add(user)
    db.commit()
    db.refresh(user)
    token = create_access_token(user.id)
    return {"access_token": token, "token_type": "bearer", "user_id": user.id, "email": user.email}
@app.post("/api/auth/login")
async def login(data: UserLogin, db: Session = Depends(get_db)):
    email = data.email.strip().lower()
    user = db.query(User).filter(User.email == email).first()
    if not user or not verify_password(data.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    if not user.is_active:
        raise HTTPException(status_code=403, detail="Account disabled")
    token = create_access_token(user.id)
    return {"access_token": token, "token_type": "bearer", "user_id": user.id, "email": user.email}
class ClaimAgentRequest(BaseModel):
    hostname: str
    one_time_token: str
@app.post("/api/auth/claim-agent")
async def claim_agent(data: ClaimAgentRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Link a freshly-registered agent to the logged-in user's account
    using the one_time_token the agent received at /api/agents/register."""
    hostname = data.hostname.strip().lower()
    agent = db.query(Agent).filter(func.lower(Agent.hostname) == hostname).order_by(Agent.registered_at.desc()).first()
    if not agent:
        raise HTTPException(status_code=404, detail="No agent found with that hostname")
    if agent.owner_id:
        raise HTTPException(status_code=409, detail="This agent is already claimed by a user")
    if not agent.one_time_token or not secrets.compare_digest(agent.one_time_token, data.one_time_token):
        raise HTTPException(status_code=403, detail="Invalid one-time token")
    agent.owner_id = current_user.id
    agent.one_time_token = ""
    db.commit()
    return {"message": "Agent claimed successfully", "agent_id": agent.id, "hostname": agent.hostname}
@app.get("/api/auth/me")
async def get_me(current_user: User = Depends(get_current_user)):
    return {"user_id": current_user.id, "email": current_user.email, "created_at": current_user.created_at.isoformat()}
@app.get("/api/dashboard/summary")
async def dashboard_summary(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    base = [Agent.owner_id == current_user.id]
    total_agents = db.query(func.count(Agent.id)).filter(*base).scalar() or 0
    online_agents = db.query(func.count(Agent.id)).filter(*base, Agent.status == "online").scalar() or 0
    offline_agents = total_agents - online_agents
    total_alerts = db.query(func.count(Alert.id)).join(Agent).filter(*base).scalar() or 0
    open_alerts = db.query(func.count(Alert.id)).join(Agent).filter(*base, Alert.status == "open").scalar() or 0
    critical_alerts = db.query(func.count(Alert.id)).join(Agent).filter(*base, Alert.severity == "critical").scalar() or 0
    high_alerts = db.query(func.count(Alert.id)).join(Agent).filter(*base, Alert.severity == "high").scalar() or 0
    threats_blocked = db.query(func.count(Alert.id)).join(Agent).filter(*base, Alert.status == "resolved").scalar() or 0
    total_suspicious = db.query(func.count(NetworkConnection.id)).join(Agent).filter(*base, NetworkConnection.is_suspicious == True).scalar() or 0
    quarantined = db.query(func.count(Agent.id)).filter(*base, Agent.quarantine == True).scalar() or 0
    security_score = calculate_security_score(db, user=current_user)
    return {"total_agents": total_agents, "online_agents": online_agents, "offline_agents": offline_agents, "total_alerts": total_alerts, "open_alerts": open_alerts, "critical_alerts": critical_alerts, "high_alerts": high_alerts, "threats_blocked": threats_blocked, "suspicious_connections": total_suspicious, "quarantined_agents": quarantined, "security_score": security_score, "scan_coverage": f"{online_agents}/{total_agents}", "last_updated": datetime.utcnow().isoformat()}
@app.get("/api/dashboard/recent-alerts")
async def dashboard_recent_alerts(current_user: User = Depends(get_current_user), limit: int = Query(10, le=50), db: Session = Depends(get_db)):
    alerts = db.query(Alert).join(Agent).filter(Agent.owner_id == current_user.id).order_by(Alert.created_at.desc()).limit(limit).all()
    return [{"id": a.id, "title": a.title, "severity": a.severity, "type": a.type, "status": a.status, "agent_id": a.agent_id, "mitre_tactic_name": a.mitre_tactic_name, "mitre_technique_name": a.mitre_technique_name, "score": a.score, "created_at": a.created_at.isoformat(), "agent_hostname": db.query(Agent.hostname).filter(Agent.id == a.agent_id).scalar() or "Unknown"}
for a in alerts]
@app.get("/api/dashboard/alert-trend")
async def dashboard_alert_trend(current_user: User = Depends(get_current_user), hours: int = Query(24, le=168), db: Session = Depends(get_db)):
    now = datetime.utcnow()
    base = [Agent.owner_id == current_user.id]
    data = []
    for i in range(hours, 0, -1):
        start = now - timedelta(hours=i)
        end = now - timedelta(hours=i - 1)
        count = db.query(func.count(Alert.id)).join(Agent).filter(*base, and_(Alert.created_at >= start, Alert.created_at < end)).scalar() or 0
        critical_count = db.query(func.count(Alert.id)).join(Agent).filter(*base, and_(Alert.created_at >= start, Alert.created_at < end, Alert.severity == "critical")).scalar() or 0
        high_count = db.query(func.count(Alert.id)).join(Agent).filter(*base, and_(Alert.created_at >= start, Alert.created_at < end, Alert.severity == "high")).scalar() or 0
        data.append({"timestamp": start.isoformat(), "total": count, "critical": critical_count, "high": high_count})
    return data
@app.get("/api/agents")
async def list_agents(current_user: User = Depends(get_current_user), status: Optional[str] = Query(None), os_type: Optional[str] = Query(None), db: Session = Depends(get_db)):
    query = db.query(Agent).filter(Agent.owner_id == current_user.id)
    if status:
        query = query.filter(Agent.status == status)
    if os_type:
        query = query.filter(Agent.os_type == os_type)
    agents = query.order_by(Agent.hostname).all()
    return [{"id": a.id, "hostname": a.hostname, "os_type": a.os_type, "os_version": a.os_version, "cpu_model": a.cpu_model, "cpu_cores": a.cpu_cores, "cpu_usage": a.cpu_usage, "ram_total_gb": a.ram_total_gb, "ram_used_gb": a.ram_used_gb, "disk_total_gb": a.disk_total_gb, "disk_used_gb": a.disk_used_gb, "mac_address": a.mac_address, "ip_address": a.ip_address, "status": a.status, "version": a.version, "last_heartbeat": a.last_heartbeat.isoformat(), "registered_at": a.registered_at.isoformat(), "tamper_protection": a.tamper_protection, "self_defense_status": a.self_defense_status, "low_footprint_mode": a.low_footprint_mode, "quarantine": a.quarantine, "bitlocker_enabled": a.bitlocker_enabled, "firewall_enabled": a.firewall_enabled, "agent_type": a.agent_type, "alert_count": db.query(func.count(Alert.id)).filter(Alert.agent_id == a.id).scalar() or 0} for a in agents]
@app.post("/api/agents/register")
async def register_agent(data: AgentRegister, db: Session = Depends(get_db)):
    agent_id = str(uuid.uuid4())
    one_time_token = secrets.token_hex(32)
    agent_token = secrets.token_hex(32)  # long-lived secret the agent must send as X-Agent-Token on every report call
    agent = Agent(id=agent_id, hostname=data.hostname, os_type=data.os_type, os_version=data.os_version, cpu_model=data.cpu_model, cpu_cores=data.cpu_cores, cpu_usage=0.0, ram_total_gb=data.ram_total_gb, ram_used_gb=0.0, disk_total_gb=data.disk_total_gb, disk_used_gb=0.0, mac_address=data.mac_address or generate_mac(), ip_address=data.ip_address, status="online", version="3.5.1", last_heartbeat=datetime.utcnow(), registered_at=datetime.utcnow(), tamper_protection=True, self_defense_status="active", low_footprint_mode=True, firewall_enabled=True, one_time_token=one_time_token, agent_token=agent_token)
    db.add(agent)
    db.commit()
    db.refresh(agent)
    return {"id": agent.id, "hostname": agent.hostname, "status": agent.status, "one_time_token": agent.one_time_token, "agent_token": agent.agent_token, "message": "Agent registered successfully. Store agent_token securely — it is "
"only returned once and must be sent as the X-Agent-Token header on every "
"subsequent report call."}
@app.get("/api/agents/{agent_id}")
async def get_agent(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"id": agent.id, "hostname": agent.hostname, "os_type": agent.os_type, "os_version": agent.os_version, "os_patch_level": agent.os_patch_level, "cpu_model": agent.cpu_model, "cpu_cores": agent.cpu_cores, "cpu_usage": agent.cpu_usage, "ram_total_gb": agent.ram_total_gb, "ram_used_gb": agent.ram_used_gb, "disk_total_gb": agent.disk_total_gb, "disk_used_gb": agent.disk_used_gb, "mac_address": agent.mac_address, "ip_address": agent.ip_address, "status": agent.status, "version": agent.version, "last_heartbeat": agent.last_heartbeat.isoformat(), "registered_at": agent.registered_at.isoformat(), "tamper_protection": agent.tamper_protection, "self_defense_status": agent.self_defense_status, "low_footprint_mode": agent.low_footprint_mode, "quarantine": agent.quarantine, "bitlocker_enabled": agent.bitlocker_enabled, "firewall_enabled": agent.firewall_enabled, "agent_type": agent.agent_type, "applications_count": db.query(func.count(Application.id)).filter(Application.agent_id == agent.id).scalar() or 0, "processes_count": db.query(func.count(Process.id)).filter(Process.agent_id == agent.id).scalar() or 0, "connections_count": db.query(func.count(NetworkConnection.id)).filter(NetworkConnection.agent_id == agent.id).scalar() or 0, "alerts_count": db.query(func.count(Alert.id)).filter(Alert.agent_id == agent.id).scalar() or 0}
@app.delete("/api/agents/{agent_id}")
async def remove_agent(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    db.delete(agent)
    db.commit()
    return {"message": f"Agent {agent_id} removed successfully"}
@app.post("/api/agents/{agent_id}/deploy")
async def deploy_agent(agent_id: str, data: DeployRequest = DeployRequest(), agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    agent.agent_type = data.agent_type
    agent.status = "online"
    agent.last_heartbeat = datetime.utcnow()
    agent.tamper_protection = True
    agent.self_defense_status = "active"
    db.commit()
    return {"message": f"Agent deployed with type: {data.agent_type}", "agent_id": agent_id, "hostname": agent.hostname, "deployment_type": "silent" if data.agent_type == "silent_deploy" else "standard", "timestamp": datetime.utcnow().isoformat()}
@app.post("/api/agents/{agent_id}/scan")
async def scan_agent(agent_id: str, data: ScanRequest = ScanRequest(), agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    vuln_findings = generate_vulnerability_findings(db, agent)
    misconfig_findings = generate_misconfig_findings(db, agent)
    memory_findings = generate_memory_scan_findings()
    return {"agent_id": agent_id, "hostname": agent.hostname, "scan_type": data.scan_type, "scan_time": datetime.utcnow().isoformat(), "vulnerability_findings": vuln_findings, "misconfiguration_findings": misconfig_findings, "memory_scan_findings": memory_findings, "summary": {"vulnerabilities_found": len(vuln_findings), "misconfigurations_found": len(misconfig_findings), "memory_issues": len([f for f in memory_findings if f.get("suspicious")]), "total_issues": len(vuln_findings) + len(misconfig_findings) + len([f for f in memory_findings if f.get("suspicious")])}}
@app.post("/api/agents/{agent_id}/quarantine")
async def quarantine_agent(agent_id: str, data: QuarantineRequest = QuarantineRequest(), agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    agent.quarantine = data.action == "quarantine"
    agent.status = "quarantined" if data.action == "quarantine" else "online"
    db.commit()
    action_text = "quarantined" if data.action == "quarantine" else "un- quarantined"
    return {"message": f"Agent {agent_id} {action_text}", "agent_id": agent_id, "status": agent.status}
@app.get("/api/agents/{agent_id}/alerts")
async def get_agent_alerts(agent_id: str, severity: Optional[str] = Query(None), status: Optional[str] = Query(None), agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    query = db.query(Alert).filter(Alert.agent_id == agent_id)
    if severity:
        query = query.filter(Alert.severity == severity)
    if status:
        query = query.filter(Alert.status == status)
    alerts = query.order_by(Alert.created_at.desc()).all()
    return [{"id": a.id, "title": a.title, "description": a.description, "severity": a.severity, "type": a.type, "status": a.status, "mitre_tactic_id": a.mitre_tactic_id, "mitre_tactic_name": a.mitre_tactic_name, "mitre_technique_id": a.mitre_technique_id, "mitre_technique_name": a.mitre_technique_name, "score": a.score, "details": json.loads(a.details) if a.details else {}, "created_at": a.created_at.isoformat(), "acknowledged_at": a.acknowledged_at.isoformat() if a.acknowledged_at else None, "resolved_at": a.resolved_at.isoformat() if a.resolved_at else None} for a in alerts]
@app.get("/api/agents/{agent_id}/processes")
async def get_agent_processes(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    processes = db.query(Process).filter(Process.agent_id == agent_id).order_by(Process.pid).all()
    return [{"id": p.id, "pid": p.pid, "name": p.name, "path": p.path, "parent_pid": p.parent_pid, "parent_name": p.parent_name, "cmdline": p.cmdline, "user": p.user, "cpu_percent": p.cpu_percent, "memory_mb": p.memory_mb, "is_suspicious": p.is_suspicious, "is_whitelisted": p.is_whitelisted, "created_at": p.created_at.isoformat()} for p in processes]
@app.get("/api/agents/{agent_id}/network")
async def get_agent_network(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    connections = db.query(NetworkConnection).filter(NetworkConnection.agent_id == agent_id).order_by(NetworkConnection.created_at.desc()).all()
    return [{"id": c.id, "local_ip": c.local_ip, "local_port": c.local_port, "remote_ip": c.remote_ip, "remote_port": c.remote_port, "protocol": c.protocol, "state": c.state, "pid": c.pid, "process_name": c.process_name, "bytes_sent": c.bytes_sent, "bytes_received": c.bytes_received, "is_suspicious": c.is_suspicious, "threat_intel_match": c.threat_intel_match, "created_at": c.created_at.isoformat()} for c in connections]
@app.get("/api/agents/{agent_id}/integrity")
async def get_agent_integrity(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    changes = db.query(FileChange).filter(FileChange.agent_id == agent_id).order_by(FileChange.detected_at.desc()).all()
    return [{"id": c.id, "file_path": c.file_path, "change_type": c.change_type, "old_hash": c.old_hash, "new_hash": c.new_hash, "file_size": c.file_size, "is_critical": c.is_critical, "is_canary": c.is_canary, "detected_at": c.detected_at.isoformat()} for c in changes]
@app.get("/api/alerts")
async def list_alerts(current_user: User = Depends(get_current_user), severity: Optional[str] = Query(None), alert_type: Optional[str] = Query(None, alias="type"), status: Optional[str] = Query(None), mitre_tactic: Optional[str]
= Query(None), limit: int = Query(50, le=200), offset: int = Query(0, ge=0), db: Session = Depends(get_db)):
    base = [Agent.owner_id == current_user.id]
    query = db.query(Alert).join(Agent).filter(*base)
    if severity: query = query.filter(Alert.severity == severity)
    if alert_type: query = query.filter(Alert.type == alert_type)
    if status: query = query.filter(Alert.status == status)
    if mitre_tactic: query = query.filter(Alert.mitre_tactic_id == mitre_tactic)
    total = query.count()
    alerts = query.order_by(Alert.created_at.desc()).offset(offset).limit(limit).all()
    return {"total": total, "limit": limit, "offset": offset, "alerts": [{"id": a.id, "agent_id": a.agent_id, "title": a.title, "description": a.description, "severity": a.severity, "type": a.type, "status": a.status, "source": a.source, "mitre_tactic_id": a.mitre_tactic_id, "mitre_tactic_name": a.mitre_tactic_name, "mitre_technique_id": a.mitre_technique_id, "mitre_technique_name": a.mitre_technique_name, "score": a.score, "details": json.loads(a.details) if a.details else {}, "created_at": a.created_at.isoformat(), "acknowledged_at": a.acknowledged_at.isoformat() if a.acknowledged_at else None, "resolved_at": a.resolved_at.isoformat() if a.resolved_at else None, "agent_hostname": db.query(Agent.hostname).filter(Agent.id == a.agent_id).scalar() or "Unknown", "ai_summary": a.ai_summary, "ai_likely_intent": a.ai_likely_intent, "ai_recommended_action": a.ai_recommended_action, "ai_confidence": a.ai_confidence, "ai_analyzed_at": a.ai_analyzed_at.isoformat() if a.ai_analyzed_at else None}
for a in alerts]}
@app.get("/api/alerts/mitre-matrix")
async def get_mitre_matrix(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    base = [Agent.owner_id == current_user.id]
    matrix = []
    for tactic_id, tactic_data in MITRE_TACTICS.items():
        techniques = []
        for tech_id, tech_data in MITRE_TECHNIQUES.items():
            if tech_data["tactic"] == tactic_id:
                alert_count = db.query(func.count(Alert.id)).join(Agent).filter(*base, Alert.mitre_technique_id == tech_id).scalar() or 0
                if alert_count > 0:
                    techniques.append({"id": tech_id, "name": tech_data["name"], "alert_count": alert_count})
        matrix.append({"tactic_id": tactic_id, "tactic_name": tactic_data["name"], "order": tactic_data["order"], "techniques": techniques})
    return sorted(matrix, key=lambda x: x["order"])
def _run_ai_analysis(alert: Alert, db: Session) -> dict:
    """Run (or re-run) Gemini analysis for one alert, cache the result on the
    row, and return the analysis dict. This is the single place that wires
    'Alert -> Gemini': called automatically on first view (see get_alert) and
    on-demand via POST /ai-analysis to force a refresh."""
    alert_dict = {
        "title": alert.title,
        "description": alert.description,
        "severity": alert.severity,
        "type": alert.type,
        "mitre_technique_id": alert.mitre_technique_id,
        "mitre_technique_name": alert.mitre_technique_name,
        "details": json.loads(alert.details) if alert.details else {},
    }
    iocs = extract_iocs(alert_dict)
    ioc_enrichment = {}
    for ioc in iocs:
        try:
            ioc_enrichment[ioc] = threat_intel_service.lookup(ioc)
        except Exception as e:
            ioc_enrichment[ioc] = {"error": str(e), "found": False}
    analysis = ai_analysis_service.analyze_alert(alert_dict, enrichment=ioc_enrichment)
    alert.ai_summary = analysis.get("summary", "")
    alert.ai_likely_intent = analysis.get("likely_intent", "")
    alert.ai_recommended_action = analysis.get("recommended_action", "")
    alert.ai_confidence = analysis.get("confidence", "")
    alert.ai_mitre_explanation = analysis.get("mitre_explanation", "")
    alert.ai_analyzed_at = datetime.utcnow()
    db.commit()
    return {"analysis": analysis, "ioc_enrichment": ioc_enrichment}
@app.get("/api/alerts/{alert_id}")
async def get_alert(alert_id: str, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    alert = db.query(Alert).join(Agent).filter(Agent.owner_id == current_user.id, Alert.id == alert_id).first()
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    # Lazily auto-trigger AI analysis the first time this alert is viewed, so
    # analysts get an AI summary without an extra manual step.
    if AI_ANALYSIS_ENABLED and ai_analysis_service.is_available() and alert.ai_analyzed_at is None:
        try:
            _run_ai_analysis(alert, db)
        except Exception as e:
            logger.warning(f"Auto AI analysis failed for alert {alert_id}: {e}")
    return {"id": alert.id, "agent_id": alert.agent_id, "title": alert.title, "description": alert.description, "severity": alert.severity, "type": alert.type, "status": alert.status, "source": alert.source, "mitre_tactic_id": alert.mitre_tactic_id, "mitre_tactic_name": alert.mitre_tactic_name, "mitre_technique_id": alert.mitre_technique_id, "mitre_technique_name": alert.mitre_technique_name, "score": alert.score, "details": json.loads(alert.details) if alert.details else {}, "created_at": alert.created_at.isoformat(), "acknowledged_at": alert.acknowledged_at.isoformat() if alert.acknowledged_at else None, "resolved_at": alert.resolved_at.isoformat() if alert.resolved_at else None, "resolved_by": alert.resolved_by, "agent_hostname": db.query(Agent.hostname).filter(Agent.id == alert.agent_id).scalar() or "Unknown", "ai_summary": alert.ai_summary, "ai_likely_intent": alert.ai_likely_intent, "ai_recommended_action": alert.ai_recommended_action, "ai_confidence": alert.ai_confidence, "ai_mitre_explanation": alert.ai_mitre_explanation, "ai_analyzed_at": alert.ai_analyzed_at.isoformat() if alert.ai_analyzed_at else None}
@app.post("/api/alerts/{alert_id}/acknowledge")
async def acknowledge_alert(alert_id: str, current_user: User = Depends(get_current_user), data: AlertAcknowledge = AlertAcknowledge(), db: Session = Depends(get_db)):
    alert = db.query(Alert).join(Agent).filter(Agent.owner_id == current_user.id, Alert.id == alert_id).first()
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    alert.status = "acknowledged"
    alert.acknowledged_at = datetime.utcnow()
    db.commit()
    return {"message": f"Alert {alert_id} acknowledged", "alert_id": alert_id, "status": alert.status}
@app.post("/api/alerts/{alert_id}/resolve")
async def resolve_alert(alert_id: str, current_user: User = Depends(get_current_user), data: AlertResolve = AlertResolve(), db: Session = Depends(get_db)):
    alert = db.query(Alert).join(Agent).filter(Agent.owner_id == current_user.id, Alert.id == alert_id).first()
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    alert.status = "resolved"
    alert.resolved_at = datetime.utcnow()
    alert.resolved_by = data.resolved_by
    db.commit()
    return {"message": f"Alert {alert_id} resolved by {data.resolved_by}", "alert_id": alert_id, "status": alert.status}
@app.post("/api/alerts/{alert_id}/ai-analysis")
async def ai_analyze_alert(alert_id: str, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    alert = db.query(Alert).join(Agent).filter(Agent.owner_id == current_user.id, Alert.id == alert_id).first()
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")
    # Always re-runs (unlike the lazy auto-analysis on GET), so analysts can
    # force a refresh, e.g. after new threat-intel data becomes available.
    result = _run_ai_analysis(alert, db)
    return {"alert_id": alert_id, **result}
@app.get("/api/threats/summary")
async def threat_summary(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    total_iocs = db.query(func.count(ThreatIntel.id)).filter(ThreatIntel.is_active == True).scalar() or 0
    ip_iocs = db.query(func.count(ThreatIntel.id)).filter(ThreatIntel.indicator_type == "ip", ThreatIntel.is_active == True).scalar() or 0
    hash_iocs = db.query(func.count(ThreatIntel.id)).filter(ThreatIntel.indicator_type == "hash", ThreatIntel.is_active == True).scalar() or 0
    domain_iocs = db.query(func.count(ThreatIntel.id)).filter(ThreatIntel.indicator_type == "domain", ThreatIntel.is_active == True).scalar() or 0
    matched_connections = db.query(func.count(NetworkConnection.id)).join(Agent).filter(Agent.owner_id == current_user.id, NetworkConnection.threat_intel_match == True).scalar() or 0
    return {"total_iocs": total_iocs, "ip_iocs": ip_iocs, "hash_iocs": hash_iocs, "domain_iocs": domain_iocs, "matched_connections": matched_connections, "last_sync": datetime.utcnow().isoformat(), "feed_sources": ["AlienVault OTX", "VirusTotal", "Abuse.ch", "Spamhaus"]}
@app.post("/api/threats/sync-intel")
async def sync_threat_intel(data: SyncIntelRequest = SyncIntelRequest(), db: Session = Depends(get_db)):
    # Sync is a placeholder for external feed integration. No default data.
    return {"message": "Sync completed. 0 new indicators.", "new_indicators": 0, "sync_time": datetime.utcnow().isoformat()}
class ThreatLookupRequest(BaseModel):
    value: str
def _detect_ioc_type(val):
    if val.startswith("http://") or val.startswith("https://"):
        return "url"
    import re
    if re.match(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$", val):
        return "ip"
    if re.match(r"^[a-f0-9]{32}$|^[a-f0-9]{40}$|^[a-f0-9]{64}$", val):
        return "hash"
    if "." in val:
        return "domain"
    return "unknown"
SPAMHAUS_CODES = {
    "127.0.0.2": "Direct spam source (SBL)",
    "127.0.0.3": "Hijacked IP / spam source (CSS)",
    "127.0.0.4": "Exploit / proxy / malware (XBL)",
    "127.0.0.5": "Passive malware detection",
    "127.0.0.6": "Passive spam detection",
    "127.0.0.7": "Domain blocklist (DBL)",
    "127.0.0.9": "Passive spam source",
    "127.0.0.10": "Dynamic / residential IP (PBL)",
    "127.0.0.11": "Passive dynamic IP", }
def _check_dnsbl(ip):
    """Check IP against free DNS blocklists (zero config, no key needed)."""
    parts = ip.strip().split(".")
    if len(parts) != 4:
        return {"checked": [], "hits": []}
    reversed_ip = ".".join(reversed(parts))
    lists = [("spamhaus", "zen.spamhaus.org"), ("tor_exit", "tor.dan.me.uk")]
    checked, hits = [], []
    for name, domain in lists:
        checked.append(name)
        try:
            result = socket.getaddrinfo(f"{reversed_ip}.{domain}", 0)
            code_ip = result[0][4][0] if result else ""
            category = SPAMHAUS_CODES.get(code_ip, "Listed (unknown reason)")
            if name == "tor_exit":
                category = "Tor exit node"
            hits.append({"list": name, "code": code_ip, "category": category})
        except socket.gaierror:
            pass
    return {"checked": checked, "hits": hits}
def _auto_scan_and_alert(agent_id, db, hashes=None, ips=None, domains=None):
    """Scan IoCs against all sources and create alerts for matches. Calledautomatically on agent reports."""
    alerts = []
    for h in (hashes or []):
        h = h.strip().lower()
        if not h:
            continue
        ioc = db.query(ThreatIntel).filter(ThreatIntel.value == h, ThreatIntel.is_active == True).first()
        if ioc:
            alerts.append(("hash", h, "threat_intel", ioc.severity, ioc.description))
    for ip in (ips or []):
        ip = ip.strip().lower()
        if not ip:
            continue
        dnsbl = _check_dnsbl(ip)
        if dnsbl and dnsbl["hits"]:
            cats = [h.get("category", h["list"]) for h in dnsbl["hits"]]
            alerts.append(("ip", ip, "dnsbl", "medium", f"DNSBL: {', '.join(cats)}"))
        ioc = db.query(ThreatIntel).filter(ThreatIntel.value == ip, ThreatIntel.is_active == True).first()
        if ioc:
            alerts.append(("ip", ip, "threat_intel", ioc.severity, ioc.description))
    for d in (domains or []):
        d = d.strip().lower()
        if not d:
            continue
        ioc = db.query(ThreatIntel).filter(ThreatIntel.value == d, ThreatIntel.is_active == True).first()
        if ioc:
            alerts.append(("domain", d, "threat_intel", ioc.severity, ioc.description))
    created = []
    for ioc_type, val, source, sev, desc in alerts:
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "threat_intel", Alert.status == "open", Alert.title.like(f"%{val}%")).first()
        if existing:
            continue
        alert = Alert(agent_id=agent_id, title=f"Auto-detected {ioc_type}: {val}", description=desc, severity=sev, type="threat_intel", score=85.0, details=json.dumps({"value": val, "ioc_type": ioc_type, "source": source, "severity": sev}))
        db.add(alert)
        created.append(val)
    if created:
        db.commit()
    return created
# --- Threat Enrichment Functions ---
MITRE_MAPPINGS = {
    "ip": [
        {"tactic": "Command and Control", "tactic_id": "TA0011", "technique": "Proxy", "technique_id": "T1090"},
        {"tactic": "Command and Control", "tactic_id": "TA0011", "technique": "Remote Access Software", "technique_id": "T1219"},
        {"tactic": "Exfiltration", "tactic_id": "TA0010", "technique": "Exfiltration Over C2 Channel", "technique_id": "T1041"},
    ],
    "hash": [
        {"tactic": "Execution", "tactic_id": "TA0002", "technique": "User Execution", "technique_id": "T1204"},
        {"tactic": "Defense Evasion", "tactic_id": "TA0005", "technique": "Masquerading", "technique_id": "T1036"},
        {"tactic": "Persistence", "tactic_id": "TA0003", "technique": "Boot or Logon Autostart Execution", "technique_id": "T1547"},
    ],
    "domain": [
        {"tactic": "Command and Control", "tactic_id": "TA0011", "technique": "Web Protocols", "technique_id": "T1071.001"},
        {"tactic": "Command and Control", "tactic_id": "TA0011", "technique": "Application Layer Protocol", "technique_id": "T1071"},
        {"tactic": "Resource Development", "tactic_id": "TA0042", "technique": "Domain Generation Algorithms", "technique_id": "T1568"},
    ],
    "url": [
        {"tactic": "Initial Access", "tactic_id": "TA0001", "technique": "Phishing", "technique_id": "T1566"},
        {"tactic": "Command and Control", "tactic_id": "TA0011", "technique": "Web Protocols", "technique_id": "T1071.001"},
    ], }
ACTIONS_BY_TYPE = {
    "ip": [
        "Block IP at firewall / edge gateway immediately",
        "Add to blocklist in SIEM / XDR policy",
        "Review firewall logs for outbound connections to this IP",
        "Isolate affected endpoints that communicated with this IP",
        "Check proxy logs for repeated beaconing patterns",
    ],
    "hash": [
        "Block file hash via application control / allowlist",
        "Delete quarantined file from all endpoints",
        "Run full host scan on affected systems",
        "Review process execution logs for this hash",
        "Escalate to incident response if lateral movement detected",
    ],
    "domain": [
        "Block domain via DNS sinkhole / content filtering",
        "Add domain to threat intelligence blocklist",
        "Review DNS logs for resolution requests",
        "Isolate hosts that queried this domain",
        "Check for related domains via passive DNS",
    ],
    "url": [
        "Block URL via web proxy / secure web gateway",
        "Add to URL filtering policy",
        "Review web access logs for visits to this URL",
        "Conduct phishing investigation if URL is credential-harvesting",
    ], }
def _extract_malware_family(vt):
    if not vt:
        return None
    ptc = vt.get("popular_threat_classification", {})
    if ptc:
        suggested = ptc.get("suggested_threat_label", "")
        if suggested:
            return suggested
        families = ptc.get("popular_threat_category", [])
        if families and isinstance(families, list):
            return families[0].get("value", "") if isinstance(families[0], dict) else families[0]
    tags = vt.get("tags", [])
    family_tags = [t for t in tags if not t.startswith("capr-") and not t.startswith("pt-") and t not in ("dynamic", "peexe", "elf", "macho", "pdf")]
    return family_tags[0] if family_tags else None
def _extract_what_it_does(vt, ioc_type):
    desc = []
    if ioc_type == "hash":
        td = vt.get("type_description", "") if vt else ""
        if td:
            desc.append(td)
        tags = vt.get("tags", []) if vt else []
        if "trojan" in tags: desc.append("Trojan malware - performs maliciousactions under remote control")
        if "ransomware" in tags: desc.append("Ransomware - encrypts files and demands payment")
        if "worm" in tags: desc.append("Worm - self-replicating malware thatspreads across networks")
        if "spyware" in tags: desc.append("Spyware - harvests sensitiveinformation from the victim")
        if "downloader" in tags: desc.append("Downloader - fetches additionalmalicious payloads")
        if "keylogger" in tags: desc.append("Keylogger - records keystrokes tosteal credentials")
        if "backdoor" in tags: desc.append("Backdoor - provides remoteunauthorized access")
        if "miner" in tags: desc.append("Cryptominer - hijacks system resourcesfor cryptocurrency mining")
        if not desc: desc.append("Suspicious executable detected by multipleantivirus engines")
    elif ioc_type == "ip":
        tags = vt.get("tags", []) if vt else []
        if "botnet" in tags: desc.append("Botnet C2 - command and control serverfor botnet operations")
        if "phishing" in tags: desc.append("Phishing - hosts phishinginfrastructure")
        if "malware" in tags: desc.append("Malware distribution - hosts or delivers malicious payloads")
        if "c2" in tags: desc.append("C2 Beaconing - known command and controlserver")
        if "scanning" in tags: desc.append("Port scanning / reconnaissanceactivity")
        if not desc: desc.append("Suspicious network activity associated withthis IP")
    elif ioc_type == "domain":
        categories = vt.get("categories", {}) if vt else {}
        for engine, cat in categories.items():
            if "malware" in cat.lower() or "phishing" in cat.lower() or "malicious" in cat.lower():
                desc.append(f"Categorized as '{cat}' by {engine}")
                break
        if not desc: desc.append("Domain associated with malicious activity")
    return desc
def _impact_on_victim(vt, ioc_type):
    impacts = []
    if ioc_type == "hash":
        if vt and vt.get("malicious", 0) > 10: impacts.append("System compromise - full host takeover possible")
        if vt and vt.get("malicious", 0) > 5: impacts.append("Data theft - sensitive information may be exfiltrated")
        impacts.append("Performance degradation - malicious processes consumesystem resources")
        impacts.append("Persistence achieved - malware survives reboots")
    elif ioc_type == "ip":
        impacts.append("Data exfiltration - sensitive data sent to externalserver")
        impacts.append("C2 communication - attacker maintains remote access")
        impacts.append("Potential lateral movement instructions received")
    elif ioc_type == "domain":
        impacts.append("Malware payload delivery via domain")
        impacts.append("Credential harvesting if phishing domain")
        impacts.append("Command and control channel established")
    return impacts
def _compute_confidence(vt, dnsbl):
    score = 0
    if vt and vt.get("malicious", 0) > 0:
        ratio = vt["malicious"] / max(vt["total"], 1)
        score += min(ratio * 100, 60)
    if dnsbl and dnsbl.get("hits"):
        score += len(dnsbl["hits"]) * 10
    if vt and vt.get("reputation", 0) < -10:
        score += 15
    if vt and vt.get("reputation", 0) < -50:
        score += 15
    return min(int(score), 100)
def _compute_reputation_label(score):
    if score >= 90: return "critical"
    if score >= 70: return "high"
    if score >= 40: return "medium"
    return "low"
def _generate_mitre(vt, ioc_type):
    base = MITRE_MAPPINGS.get(ioc_type, MITRE_MAPPINGS.get("ip", []))
    tags = vt.get("tags", []) if vt else []
    extra = []
    if "ransomware" in tags:
        extra.append({"tactic": "Impact", "tactic_id": "TA0040", "technique": "Data Encrypted for Impact", "technique_id": "T1486"})
    if "trojan" in tags:
        extra.append({"tactic": "Defense Evasion", "tactic_id": "TA0005", "technique": "Obfuscated Files or Information", "technique_id": "T1027"})
    if "downloader" in tags:
        extra.append({"tactic": "Command and Control", "tactic_id": "TA0011", "technique": "Ingress Tool Transfer", "technique_id": "T1105"})
    if "botnet" in tags or "c2" in tags:
        extra.append({"tactic": "Command and Control", "tactic_id": "TA0011", "technique": "Non-Application Layer Protocol", "technique_id": "T1571"})
    return base + extra
def _recommended_actions(ioc_type, severity):
    actions = ACTIONS_BY_TYPE.get(ioc_type, [])
    if severity in ("critical", "high"):
        actions.insert(0, "Escalate to CIRT/SOC Tier 3 for immediateinvestigation")
    return actions
# --- /Threat Enrichment Functions ---
@app.post("/api/threats/lookup")
async def lookup_threat(data: ThreatLookupRequest, db: Session = Depends(get_db)):
    val = data.value.strip().lower()
    ioc_type = _detect_ioc_type(val)
    base = {"value": val, "indicator_type": ioc_type}
    dnsbl = _check_dnsbl(val) if ioc_type == "ip" else None
    vt_result = None
    vt_error = None
    ioc = db.query(ThreatIntel).filter(ThreatIntel.value == val, ThreatIntel.is_active == True).first()
    found = False
    source = ""
    confidence = ""
    severity = ""
    description = ""
    mitre_mapping = None
    if ioc:
        found = True
        source = ioc.source
        confidence = ioc.confidence
        severity = ioc.severity
        description = ioc.description
        mitre_mapping = ioc.mitre_mapping
    if not found and dnsbl and dnsbl["hits"]:
        cats = [h.get("category", h["list"]) for h in dnsbl["hits"]]
        found = True
        source = "dnsbl"
        confidence = "medium"
        severity = "medium"
        description = f"DNSBL: {', '.join(cats)}"
    # Enrichment
    malware_family = _extract_malware_family(vt_result)
    what_it_does = _extract_what_it_does(vt_result, ioc_type)
    impacts = _impact_on_victim(vt_result, ioc_type)
    rep_score = _compute_confidence(vt_result, dnsbl)
    actions = _recommended_actions(ioc_type, severity if severity else "low")
    mitre = mitre_mapping if mitre_mapping else _generate_mitre(vt_result if vt_result else {}, ioc_type)
    result = base | {
        "found": found, "source": source, "confidence": confidence or _compute_reputation_label(rep_score),
        "severity": severity or _compute_reputation_label(rep_score), "description": description,
        "dnsbl": dnsbl,
        "malware_family": malware_family,
        "what_it_does": what_it_does,
        "impact": impacts,
        "reputation_score": rep_score,
        "reputation_label": _compute_reputation_label(rep_score),
        "mitre_attck": mitre,
        "recommended_actions": actions,
    }
    if ioc:
        result["first_seen"] = ioc.first_seen.isoformat()
        result["last_seen"] = ioc.last_seen.isoformat()
    return result
@app.get("/api/threat-intel/lookup")
async def threat_intel_lookup(indicator: str = Query(..., description="IP, hash, or domain")):
    val = indicator.strip().lower()
    result = threat_intel_service.lookup(val)
    if "error" in result:
        result["value"] = val
        result["indicator_type"] = result.get("type", "unknown")
        result["found"] = False
    else:
        result["value"] = val
        result["indicator_type"] = result.get("type", "unknown")
        result["found"] = result.get("found", False)
        result["description"] = "; ".join(result.get("why_malicious", []))
        result["virustotal"] = result.get("providers", {}).get("virustotal", {})
        result["dnsbl"] = result.get("providers", {}).get("dnsbl", {})
        if "error" in str(result.get("virustotal", {})):
            pass
        result["source"] = result.get("primary_source", "")
        result["what_it_does"] = result.get("why_malicious", [])
        result["reputation_score"] = result.get("reputation_score", 0)
        result["reputation_label"] = result.get("reputation", "unknown")
        result["severity"] = result.get("reputation", "unknown")
        result["confidence"] = result.get("reputation", "unknown")
        result["recommended_actions"] = result.get("recommendations", [])
        result["mitre_attck"] = result.get("mitre", [])
        if result.get("providers"):
            for pname, pdata in result["providers"].items():
                if isinstance(pdata, dict) and pdata.get("first_seen"):
                    result["first_seen"] = pdata["first_seen"]
                if isinstance(pdata, dict) and pdata.get("last_seen"):
                    result["last_seen"] = pdata["last_seen"]
    return result
@app.post("/api/tools/file-scan")
async def file_scan(current_user: User = Depends(get_current_user), file: UploadFile = File(...)):
    """Upload a file to check it for malware. Computes SHA256/MD5 locally (the
    file itself is never sent anywhere) and looks the hash up against
    VirusTotal + MalwareBazaar via the existing threat-intel pipeline. Note:
    this is hash/reputation-based (is this known malware?), not sandboxed
    execution analysis (what would this file do if run?)."""
    contents = await file.read()
    if len(contents) > 32 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="File too large (max 32MB)")
    sha256 = hashlib.sha256(contents).hexdigest()
    md5 = hashlib.md5(contents).hexdigest()
    result = threat_intel_service.lookup(sha256)
    return {
        "filename": file.filename,
        "size_bytes": len(contents),
        "sha256": sha256,
        "md5": md5,
        "scan_result": result,
    }
@app.get("/api/dashboard/ai-card")
async def dashboard_ai_card(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Aggregated data for a frontend 'AI Insights' dashboard card: how many
    alerts have been AI-analyzed, and the most urgent AI-recommended actions
    across recent open critical/high alerts."""
    base = [Agent.owner_id == current_user.id]
    total_alerts = db.query(func.count(Alert.id)).join(Agent).filter(*base).scalar() or 0
    analyzed_count = db.query(func.count(Alert.id)).join(Agent).filter(*base, Alert.ai_analyzed_at.isnot(None)).scalar() or 0
    top_alerts = (
        db.query(Alert)
        .join(Agent)
        .filter(*base, Alert.status == "open", Alert.severity.in_(["critical", "high"]), Alert.ai_analyzed_at.isnot(None))
        .order_by(Alert.score.desc())
        .limit(5)
        .all()
    )
    return {
        "ai_enabled": ai_analysis_service.is_available(),
        "total_alerts": total_alerts,
        "ai_analyzed_alerts": analyzed_count,
        "top_recommendations": [
            {
                "alert_id": a.id,
                "title": a.title,
                "severity": a.severity,
                "ai_summary": a.ai_summary,
                "ai_recommended_action": a.ai_recommended_action,
                "ai_confidence": a.ai_confidence,
            }
            for a in top_alerts
        ],
    }
@app.post("/api/ai-chat")
async def ai_chat(data: AIChatRequest, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Free-form Q&A for analysts, optionally grounded in a specific alert or incident."""
    context = None
    if data.alert_id:
        alert = db.query(Alert).join(Agent).filter(Agent.owner_id == current_user.id, Alert.id == data.alert_id).first()
        if alert:
            context = {
                "alert": {
                    "title": alert.title, "description": alert.description, "severity": alert.severity,
                    "type": alert.type, "mitre_technique_id": alert.mitre_technique_id,
                    "mitre_technique_name": alert.mitre_technique_name,
                    "ai_summary": alert.ai_summary, "ai_recommended_action": alert.ai_recommended_action,
                    "details": json.loads(alert.details) if alert.details else {},
                }
            }
    elif data.incident_id:
        incident = correlation_engine.get_incident(data.incident_id)
        if incident:
            context = {"incident": incident}
    result = ai_analysis_service.chat(data.question, context=context)
    return result
@app.get("/api/threats/report/summary")
async def threat_report_summary(db: Session = Depends(get_db)):
    total_alerts = db.query(func.count(Alert.id)).filter(Alert.type == "threat_intel").scalar() or 0
    source_breakdown = {}
    for r in db.query(Alert.details, Alert.severity).filter(Alert.type == "threat_intel").all():
        try:
            d = json.loads(r.details) if isinstance(r.details, str) else r.details
            src = d.get("source", "unknown")
        except:
            src = "unknown"
        source_breakdown[src] = source_breakdown.get(src, 0) + 1
    severity_breakdown = {}
    for r in db.query(Alert.severity).filter(Alert.type == "threat_intel").all():
        severity_breakdown[r.severity] = severity_breakdown.get(r.severity, 0) + 1
    by_type = {"hash": 0, "ip": 0, "domain": 0}
    for r in db.query(Alert.details).filter(Alert.type == "threat_intel").all():
        try:
            d = json.loads(r.details) if isinstance(r.details, str) else r.details
            t = d.get("ioc_type", "unknown")
            if t in by_type: by_type[t] += 1
        except:
            pass
    return {"total_alerts": total_alerts, "sources": source_breakdown, "severities": severity_breakdown, "ioc_types": by_type}
@app.get("/api/threats/report/export")
async def threat_report_export(format: str = Query("json"), db: Session = Depends(get_db)):
    intel = db.query(ThreatIntel).filter(ThreatIntel.is_active == True).order_by(ThreatIntel.last_seen.desc()).all()
    rows = []
    for i in intel:
        rows.append({"type": i.indicator_type, "value": i.value, "severity": i.severity, "confidence": i.confidence, "source": i.source, "description": i.description, "first_seen": i.first_seen.isoformat() if i.first_seen else "", "last_seen": i.last_seen.isoformat() if i.last_seen else ""})
    alerts_list = []
    for a in db.query(Alert).filter(Alert.type == "threat_intel").order_by(Alert.created_at.desc()).limit(500).all():
        alerts_list.append({"title": a.title, "severity": a.severity, "agent_id": a.agent_id, "created_at": a.created_at.isoformat() if a.created_at else "", "details": a.details})
    if format == "csv":
        import io, csv
        output = io.StringIO()
        w = csv.writer(output)
        w.writerow(["type", "value", "severity", "confidence", "source", "description", "first_seen", "last_seen"])
        for r in rows: w.writerow([r["type"], r["value"], r["severity"], r["confidence"], r["source"], r["description"], r["first_seen"], r["last_seen"]])
        from fastapi.responses import StreamingResponse
        return StreamingResponse(iter([output.getvalue()]), media_type="text/csv", headers={"Content-Disposition": "attachment;filename=threat_report.csv"})
    return {"threat_intel": rows, "recent_alerts": alerts_list}
@app.get("/api/threats/intel")
async def get_threat_intel(indicator_type: Optional[str] = Query(None), severity: Optional[str] = Query(None), limit: int = Query(50, le=200), db: Session = Depends(get_db)):
    query = db.query(ThreatIntel).filter(ThreatIntel.is_active == True)
    if indicator_type: query = query.filter(ThreatIntel.indicator_type == indicator_type)
    if severity: query = query.filter(ThreatIntel.severity == severity)
    intel = query.order_by(ThreatIntel.last_seen.desc()).limit(limit).all()
    return [{"id": i.id, "indicator_type": i.indicator_type, "value": i.value, "confidence": i.confidence, "severity": i.severity, "source": i.source, "description": i.description, "first_seen": i.first_seen.isoformat(), "last_seen": i.last_seen.isoformat(), "is_active": i.is_active, "mitre_mapping": i.mitre_mapping} for i in intel]
@app.get("/api/policies")
async def get_policies(db: Session = Depends(get_db)):
    policies = db.query(Policy).all()
    result = {}
    for p in policies:
        try: result[p.key] = json.loads(p.value)
        except: result[p.key] = p.value
    return result
@app.post("/api/policies")
async def update_policies(data: PolicyUpdate, db: Session = Depends(get_db)):
    existing = db.query(Policy).filter(Policy.key == data.key).first()
    if existing:
        existing.value = data.value
        existing.updated_at = datetime.utcnow()
    else:
        db.add(Policy(key=data.key, value=data.value))
    db.commit()
    return {"message": f"Policy '{data.key}' updated", "key": data.key, "value": data.value}
@app.get("/api/policies/app-whitelist")
async def get_app_whitelist(db: Session = Depends(get_db)):
    policy = db.query(Policy).filter(Policy.key == "approved_apps").first()
    if not policy: return {"whitelist": [], "enabled": True, "total": 0}
    try: apps = json.loads(policy.value)
    except: apps = []
    return {"whitelist": apps, "enabled": True, "total": len(apps)}
@app.post("/api/policies/app-whitelist")
async def add_app_whitelist(data: AppWhitelistAdd, db: Session = Depends(get_db)):
    policy = db.query(Policy).filter(Policy.key == "approved_apps").first()
    if policy:
        try: apps = json.loads(policy.value)
        except: apps = []
    else:
        apps = []
        policy = Policy(key="approved_apps", value="[]")
        db.add(policy)
    if data.name not in apps: apps.append(data.name)
    policy.value = json.dumps(apps)
    policy.updated_at = datetime.utcnow()
    db.commit()
    return {"message": f"'{data.name}' added to whitelist", "whitelist": apps}
@app.get("/api/policies/blocked-devices")
async def get_blocked_devices(db: Session = Depends(get_db)):
    policy = db.query(Policy).filter(Policy.key == "blocked_usb_devices").first()
    if not policy: return {"devices": [], "total": 0}
    try: devices = json.loads(policy.value)
    except: devices = []
    return {"devices": devices, "total": len(devices)}
@app.post("/api/policies/blocked-devices")
async def block_device(data: BlockDevice, db: Session = Depends(get_db)):
    policy = db.query(Policy).filter(Policy.key == "blocked_usb_devices").first()
    if policy:
        try: devices = json.loads(policy.value)
        except: devices = []
    else:
        devices = []
        policy = Policy(key="blocked_usb_devices", value="[]")
        db.add(policy)
    entry = {"device_id": data.device_id, "device_name": data.device_name, "device_type": data.device_type, "reason": data.reason or "Blocked by admin", "blocked_at": datetime.utcnow().isoformat()}
    exists = any(d.get("device_id") == data.device_id for d in devices)
    if not exists: devices.append(entry)
    policy.value = json.dumps(devices)
    policy.updated_at = datetime.utcnow()
    db.commit()
    return {"message": f"'{data.device_name}' blocked", "devices": devices}
@app.post("/api/policies/blocked-devices/{device_id}/unblock")
async def unblock_device(device_id: str, db: Session = Depends(get_db)):
    policy = db.query(Policy).filter(Policy.key == "blocked_usb_devices").first()
    if not policy: raise HTTPException(status_code=404, detail="No blockeddevices policy")
    try: devices = json.loads(policy.value)
    except: devices = []
    filtered = [d for d in devices if d.get("device_id") != device_id]
    if len(filtered) == len(devices): raise HTTPException(status_code=404, detail="Device not found")
    policy.value = json.dumps(filtered)
    policy.updated_at = datetime.utcnow()
    db.commit()
    return {"message": f"Device {device_id} unblocked", "devices": filtered}
@app.get("/api/analytics/attack-vector-distribution")
async def attack_vector_distribution(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    types = db.query(Alert.type, func.count(Alert.id).label("count")).join(Agent).filter(Agent.owner_id == current_user.id).group_by(Alert.type).all()
    total = sum(t.count for t in types) or 1
    return [{"name": t.type, "value": t.count, "percentage": round(t.count / total * 100, 1)} for t in types]
@app.get("/api/analytics/top-mitre-techniques")
async def top_mitre_techniques(current_user: User = Depends(get_current_user), limit: int = Query(10, le=50), db: Session = Depends(get_db)):
    techniques = db.query(Alert.mitre_technique_id, Alert.mitre_technique_name, func.count(Alert.id).label("count")).join(Agent).filter(Agent.owner_id == current_user.id).group_by(Alert.mitre_technique_id, Alert.mitre_technique_name).order_by(func.count(Alert.id).desc()).limit(limit).all()
    total = sum(t.count for t in techniques) or 1
    return [{"technique_id": t.mitre_technique_id, "technique_name": t.mitre_technique_name, "count": t.count, "percentage": round(t.count / total * 100, 1)} for t in techniques]
@app.get("/api/analytics/agent-health")
async def agent_health_distribution(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    statuses = db.query(Agent.status, func.count(Agent.id).label("count")).filter(Agent.owner_id == current_user.id).group_by(Agent.status).all()
    total = sum(s.count for s in statuses) or 1
    return [{"status": s.status, "count": s.count, "percentage": round(s.count / total * 100, 1)} for s in statuses]
@app.get("/api/mitre-attack-mapping")
async def get_mitre_attack_mapping():
    return {"mapping_version": "1.0", "total_mapped_features": len(MITRE_ATTACK_MAP), "mitre_map": MITRE_ATTACK_MAP, "tactics": {k: v["name"]
for k, v in MITRE_TACTICS.items()}, "techniques": {k: v["name"] for k, v in MITRE_TECHNIQUES.items()}}
@app.get("/api/agents/{agent_id}/patch-monitoring")
async def get_agent_patch_monitoring(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_patch_findings(db, agent)}
@app.post("/api/agents/{agent_id}/patch-monitoring/report")
async def report_agent_patches(agent_id: str, data: PatchReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    record = OSPatchInfo(agent_id=agent_id, missing_patches=json.dumps(data.missing_patches), count=data.count, oldest_missing_days=data.oldest_missing_days, severity=data.severity)
    db.add(record)
    if data.severity == "high" and data.count > 0:
        alert = Alert(agent_id=agent_id, title=f"Missing OS Patches({data.count} pending)", description=f"Agent has {data.count} missing patches, oldest from {data.oldest_missing_days} days ago", severity="high", type="misconfiguration", mitre_tactic_id=MITRE_ATTACK_MAP["os_patch_monitoring"]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP["os_patch_monitoring"]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP["os_patch_monitoring"]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP["os_patch_monitoring"]["technique_name"], score=min(70 + data.count * 5, 95), details=json.dumps({"missing_patches": data.missing_patches, "oldest_missing_days": data.oldest_missing_days}) )
        db.add(alert)
    db.commit()
    return {"message": "Patch report recorded", "agent_id": agent_id, "patch_count": data.count, "severity": data.severity}
@app.get("/api/agents/{agent_id}/behavioral-heuristics")
async def get_agent_behavioral(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_behavioral_findings(db, agent)}
@app.post("/api/agents/{agent_id}/behavioral-heuristics/report")
async def report_agent_behavioral(agent_id: str, data: BehavioralReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    snapshot = BehavioralSnapshot(agent_id=agent_id, cpu_usage=data.cpu_usage, ram_usage=data.ram_usage, process_count=data.process_count, net_connections=data.net_connections, is_anomaly=data.is_anomaly, anomaly_score=data.anomaly_score, ml_active=data.ml_active, history_size=data.history_size, details=data.details)
    db.add(snapshot)
    if data.is_anomaly:
        existing_open = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "behavioral_anomaly", Alert.status == "open").first()
        if not existing_open:
            alert = Alert(agent_id=agent_id, title="Behavioral AnomalyDetected", description=f"Agent behavior deviates from baseline (score: {data.anomaly_score}). Possible compromise or malware activity.", severity="high", type="behavioral_anomaly", mitre_tactic_id=MITRE_ATTACK_MAP["behavioral_heuristics"]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP["behavioral_heuristics"
]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP["behavioral_heuristics"]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP["behavioral_heuristics"]["technique_name"], score=round(abs(data.anomaly_score) * 20 + 60, 1), details=json.dumps({"cpu_usage": data.cpu_usage, "ram_usage": data.ram_usage, "process_count": data.process_count, "net_connections": data.net_connections, "anomaly_score": data.anomaly_score, "ml_active": data.ml_active}) )
            db.add(alert)
    db.commit()
    return {"message": "Behavioral snapshot recorded", "agent_id": agent_id, "is_anomaly": data.is_anomaly, "anomaly_score": data.anomaly_score}
@app.get("/api/agents/{agent_id}/file-integrity")
async def get_agent_file_integrity(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    fim_data = generate_file_integrity_findings(db, agent)
    return {"agent_id": agent_id, "hostname": agent.hostname, **fim_data}
@app.post("/api/agents/{agent_id}/file-integrity/report")
async def report_agent_file_integrity(agent_id: str, data: FileIntegrityReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    check = FileIntegrityCheck(agent_id=agent_id, monitored_files=json.dumps(data.monitored_files), changes_detected=data.changes_detected, changed_files=json.dumps(data.changed_files), severity=data.severity)
    db.add(check)
    if data.changes_detected:
        alert = Alert(agent_id=agent_id, title="File Integrity Alert: CriticalFile Changed", description=f"Sensitive files modified: {', '.join(data.changed_files)}", severity=data.severity, type="file_integrity", mitre_tactic_id=MITRE_ATTACK_MAP["file_integrity_monitoring"]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP["file_integrity_monitor ing"]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP["file_integrity_monitoring"]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP["file_integrity_monitoring"]["technique_name"], score=85.0, details=json.dumps({"changed_files": data.changed_files, "monitored_files": data.monitored_files}) )
        db.add(alert)
    db.commit()
    return {"message": "File integrity check recorded", "agent_id": agent_id, "changes_detected": data.changes_detected}
@app.get("/api/agents/{agent_id}/misconfigurations")
async def get_agent_misconfigurations(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    misconfig = db.query(MisconfigurationCheck).filter(MisconfigurationCheck.agent_id == agent_id).order_by(MisconfigurationCheck.checked_at.desc()).first()
    result = {"agent_id": agent_id, "hostname": agent.hostname, "rdp_open": False, "firewall_off": False, "guest_account": False, "weak_password_policy": False, "severity": "info", "last_checked": None}
    if misconfig:
        result.update({"rdp_open": misconfig.rdp_open, "firewall_off": misconfig.firewall_off, "guest_account": misconfig.guest_account, "weak_password_policy": misconfig.weak_password_policy, "severity": misconfig.severity, "last_checked": misconfig.checked_at.isoformat()})
    else:
        result.update({"rdp_open": not agent.firewall_enabled if agent.os_type == "Windows" else False, "firewall_off": not agent.firewall_enabled, "guest_account": False, "weak_password_policy": False, "severity": "high" if not agent.firewall_enabled else "info"})
    return result
@app.post("/api/agents/{agent_id}/misconfigurations/report")
async def report_agent_misconfigurations(agent_id: str, data: MisconfigReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    check = MisconfigurationCheck(agent_id=agent_id, rdp_open=data.rdp_open, firewall_off=data.firewall_off, guest_account=data.guest_account, weak_password_policy=data.weak_password_policy, severity=data.severity)
    db.add(check)
    if data.severity == "high":
        issues = []
        if data.rdp_open: issues.append("RDP exposed")
        if data.firewall_off: issues.append("Firewall disabled")
        if data.guest_account: issues.append("Guest account active")
        if data.weak_password_policy: issues.append("Weak password policy")
        existing_open = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "misconfiguration", Alert.status == "open").first()
        if not existing_open and issues:
            alert = Alert(agent_id=agent_id, title=f"Security MisconfigurationsDetected", description=f"Issues found: {', '.join(issues)}", severity="high", type="misconfiguration", mitre_tactic_id=MITRE_ATTACK_MAP["misconfiguration_detection"]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP["misconfiguration_detection"]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP["misconfiguration_detection"]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP["misconfiguration_detection"]["technique_name"], score=75.0, details=json.dumps({"issues": issues, "rdp_open": data.rdp_open, "firewall_off": data.firewall_off, "guest_account": data.guest_account, "weak_password_policy": data.weak_password_policy}) )
            db.add(alert)
    db.commit()
    return {"message": "Misconfiguration check recorded", "agent_id": agent_id, "has_issues": data.rdp_open or data.firewall_off or data.guest_account or data.weak_password_policy}
@app.get("/api/analytics/behavioral-overview")
async def behavioral_overview(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    base = [Agent.owner_id == current_user.id]
    total_anomalies = db.query(func.count(BehavioralSnapshot.id)).join(Agent).filter(*base, BehavioralSnapshot.is_anomaly == True).scalar() or 0
    total_snapshots = db.query(func.count(BehavioralSnapshot.id)).join(Agent).filter(*base).scalar() or 0
    avg_anomaly_score = db.query(func.avg(BehavioralSnapshot.anomaly_score)).join(Agent).filter(*base).scalar() or 0.0
    agents_with_anomalies = db.query(BehavioralSnapshot.agent_id).join(Agent).filter(*base, BehavioralSnapshot.is_anomaly == True).distinct().count()
    return {"total_anomalies": total_anomalies, "total_snapshots": total_snapshots, "avg_anomaly_score": round(float(avg_anomaly_score), 4), "agents_with_anomalies": agents_with_anomalies, "anomaly_rate": round(total_anomalies / max(total_snapshots, 1) * 100, 1)}
@app.get("/api/analytics/patch-compliance")
async def patch_compliance(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    base = [Agent.owner_id == current_user.id]
    total_agents = db.query(func.count(Agent.id)).filter(*base).scalar() or 0
    agents_with_patches = db.query(func.count(OSPatchInfo.agent_id.distinct())).join(Agent).filter(*base, OSPatchInfo.count > 0).scalar() or 0
    total_missing = db.query(func.sum(OSPatchInfo.count)).join(Agent).filter(*base).scalar() or 0
    high_severity = db.query(func.count(OSPatchInfo.id)).join(Agent).filter(*base, OSPatchInfo.severity == "high").scalar() or 0
    return {"total_agents": total_agents, "agents_with_missing_patches": agents_with_patches, "total_missing_patches": total_missing, "high_severity_reports": high_severity, "compliance_rate": round((total_agents - agents_with_patches) / max(total_agents, 1) * 100, 1)}
@app.get("/api/analytics/misconfiguration-summary")
async def misconfiguration_summary(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    base = [Agent.owner_id == current_user.id]
    total_checks = db.query(func.count(MisconfigurationCheck.id)).join(Agent).filter(*base).scalar( ) or 0
    rdp_open_count = db.query(func.count(MisconfigurationCheck.id)).join(Agent).filter(*base, MisconfigurationCheck.rdp_open == True).scalar() or 0
    firewall_off_count = db.query(func.count(MisconfigurationCheck.id)).join(Agent).filter(*base, MisconfigurationCheck.firewall_off == True).scalar() or 0
    guest_account_count = db.query(func.count(MisconfigurationCheck.id)).join(Agent).filter(*base, MisconfigurationCheck.guest_account == True).scalar() or 0
    weak_password_count = db.query(func.count(MisconfigurationCheck.id)).join(Agent).filter(*base, MisconfigurationCheck.weak_password_policy == True).scalar() or 0
    return {"total_checks": total_checks, "rdp_open": rdp_open_count, "firewall_off": firewall_off_count, "guest_account": guest_account_count, "weak_password_policy": weak_password_count, "total_issues": rdp_open_count + firewall_off_count + guest_account_count + weak_password_count}
@app.get("/api/agents/{agent_id}/software-inventory")
async def get_agent_software_inventory(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    inventory = generate_software_inventory(db, agent)
    return {"agent_id": agent_id, "hostname": agent.hostname, "total_apps": len(inventory), "approved_count": sum(1 for a in inventory if a["is_approved"]), "unapproved_count": sum(1 for a in inventory if not a["is_approved"]), "software": inventory}
@app.post("/api/agents/{agent_id}/software-inventory/report")
async def report_agent_software_inventory(agent_id: str, data: SoftwareInventoryReport, agent: Agent = Depends(verify_agent_self), db: Session
= Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    db.query(Application).filter(Application.agent_id == agent_id).delete()
    unapproved_count = 0
    for item in data.software:
        risk = 0.0
        if not item.is_approved:
            risk = random.uniform(20, 60)
            unapproved_count += 1
        db.add(Application(agent_id=agent_id, name=item.name, version=item.version, vendor=item.vendor, install_date=datetime.utcnow(), is_approved=item.is_approved, is_running=True, risk_score=risk, cve_list="[]"))
    if unapproved_count > 0:
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "shadow_it", Alert.status == "open").first()
        if not existing:
            db.add(Alert(agent_id=agent_id, title=f"Shadow IT: {unapproved_count} Unapproved Applications", description=f"Software inventory scan found {unapproved_count} unapproved applications on {agent.hostname}", severity="low", type="shadow_it", mitre_tactic_id="TA0003", mitre_tactic_name=get_mitre_tactic_name("TA0003"), mitre_technique_id="T1078", mitre_technique_name=get_mitre_technique_name("T1078"), score=random.uniform(10, 30), details=json.dumps({"unapproved_count": unapproved_count, "source": "software_inventory_report"}) ))
    db.commit()
    return {"message": "Software inventory recorded", "agent_id": agent_id, "total_apps": len(data.software), "unapproved": unapproved_count}
@app.get("/api/agents/{agent_id}/asset-discovery")
async def get_agent_asset_discovery(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, **generate_asset_discovery(agent)}
@app.post("/api/agents/{agent_id}/asset-discovery/report")
async def report_agent_asset_discovery(agent_id: str, data: AssetDiscoveryReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    if data.hostname: agent.hostname = data.hostname
    if data.os_type: agent.os_type = data.os_type
    if data.os_version: agent.os_version = data.os_version
    if data.processor: agent.cpu_model = data.processor
    if data.cpu_cores: agent.cpu_cores = data.cpu_cores
    if data.ram_gb: agent.ram_total_gb = int(data.ram_gb)
    if data.mac_address: agent.mac_address = data.mac_address
    if data.ip_address: agent.ip_address = data.ip_address
    agent.last_heartbeat = datetime.utcnow()
    agent.status = "online"
    db.commit()
    return {"message": "Asset discovery info updated", "agent_id": agent_id, "hostname": agent.hostname}
@app.get("/api/analytics/software-summary")
async def software_summary(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    base = [Agent.owner_id == current_user.id]
    total_apps = db.query(func.count(Application.id)).join(Agent).filter(*base).scalar() or 0
    unapproved = db.query(func.count(Application.id)).join(Agent).filter(*base, Application.is_approved == False).scalar() or 0
    top_apps = db.query(Application.name, func.count(Application.id).label("count")).join(Agent).filter(*base).group_by(Application.name).order_by(func.count(Application.id).desc()).limit(10).all()
    return {"total_apps": total_apps, "unapproved_apps": unapproved, "approval_rate": round((total_apps - unapproved) / max(total_apps, 1) * 100, 1), "top_applications": [{"name": a.name, "count": a.count} for a in top_apps]}
@app.get("/api/analytics/asset-overview")
async def asset_overview(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    base = [Agent.owner_id == current_user.id]
    total = db.query(func.count(Agent.id)).filter(*base).scalar() or 0
    os_breakdown = db.query(Agent.os_type, func.count(Agent.id).label("count")).filter(*base).group_by(Agent.os_type).all()
    avg_ram = db.query(func.avg(Agent.ram_total_gb)).filter(*base).scalar() or 0
    avg_cpu_cores = db.query(func.avg(Agent.cpu_cores)).filter(*base).scalar() or 0
    return {"total_assets": total, "os_breakdown": {o.os_type: o.count for o in os_breakdown}, "avg_ram_gb": round(float(avg_ram), 1), "avg_cpu_cores": round(float(avg_cpu_cores), 1), "total_disk_tb": round((db.query(func.sum(Agent.disk_total_gb)).filter(*base).scalar() or 0) / 1024, 2)}
@app.get("/api/agents/{agent_id}/watchdog-status")
async def get_agent_watchdog(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_watchdog_status(db, agent)}
@app.post("/api/agents/{agent_id}/watchdog-status/report")
async def report_agent_watchdog(agent_id: str, data: WatchdogStatusReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    event = WatchdogEvent(agent_id=agent_id, agent_running=data.agent_running, tamper_detected=data.tamper_detected, restart_count=data.restart_count, log_entry=data.log_entry)
    db.add(event)
    if data.tamper_detected:
        agent.tamper_protection = False
        agent.self_defense_status = "compromised"
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "tamper", Alert.status == "open").first()
        if not existing:
            db.add(Alert(agent_id=agent_id, title="Tamper Protection Triggered", description=f"Agent process was interrupted and restarted {data.restart_count}times. Self-defense mechanism may be compromised.", severity="high", type="tamper", mitre_tactic_id=MITRE_ATTACK_MAP["watchdog_process"]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP["watchdog_process"]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP["watchdog_process"]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP["watchdog_process"]["technique_name"], score=85.0, details=json.dumps({"restart_count": data.restart_count, "log": data.log_entry}) ))
    else:
        agent.tamper_protection = True
        agent.self_defense_status = "active"
    agent.last_heartbeat = datetime.utcnow()
    agent.status = "online" if data.agent_running else "offline"
    db.commit()
    return {"message": "Watchdog status recorded", "agent_id": agent_id, "tamper_detected": data.tamper_detected, "agent_running": data.agent_running}
@app.get("/api/agents/{agent_id}/monitoring-logs")
async def get_agent_monitoring_logs(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_monitoring_stats(db, agent)}
@app.post("/api/agents/{agent_id}/monitoring-logs/report")
async def report_agent_monitoring(agent_id: str, data: AgentMonitorReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    log = AgentMonitorLog(agent_id=agent_id, cpu_percent=data.cpu_percent, ram_percent=data.ram_percent, interval_seconds=data.interval_seconds)
    db.add(log)
    agent.cpu_usage = data.cpu_percent
    agent.ram_used_gb = round(data.ram_percent / 100 * agent.ram_total_gb, 1) if agent.ram_total_gb else 0.0
    agent.last_heartbeat = datetime.utcnow()
    agent.status = "online"
    db.commit()
    return {"message": "Monitoring data recorded", "agent_id": agent_id, "cpu_percent": data.cpu_percent, "ram_percent": data.ram_percent}
@app.get("/api/analytics/watchdog-summary")
async def watchdog_summary(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    base = [Agent.owner_id == current_user.id]
    total_events = db.query(func.count(WatchdogEvent.id)).join(Agent).filter(*base).scalar() or 0
    tamper_events = db.query(func.count(WatchdogEvent.id)).join(Agent).filter(*base, WatchdogEvent.tamper_detected == True).scalar() or 0
    total_restarts = db.query(func.sum(WatchdogEvent.restart_count)).join(Agent).filter(*base).scalar () or 0
    agents_with_tamper = db.query(WatchdogEvent.agent_id).join(Agent).filter(*base, WatchdogEvent.tamper_detected == True).distinct().count()
    protected = db.query(func.count(Agent.id)).filter(*base, Agent.tamper_protection == True, Agent.self_defense_status == "active").scalar() or 0
    total_agents = db.query(func.count(Agent.id)).filter(*base).scalar() or 1
    return {"total_events": total_events, "tamper_events": tamper_events, "total_restarts": total_restarts, "agents_with_tamper": agents_with_tamper, "protected_ratio": round(protected / total_agents * 100, 1)}
@app.get("/api/analytics/monitoring-overview")
async def monitoring_overview(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    base = [Agent.owner_id == current_user.id]
    total_logs = db.query(func.count(AgentMonitorLog.id)).join(Agent).filter(*base).scalar() or 0
    avg_cpu = db.query(func.avg(AgentMonitorLog.cpu_percent)).join(Agent).filter(*base).scalar () or 0
    avg_ram = db.query(func.avg(AgentMonitorLog.ram_percent)).join(Agent).filter(*base).scalar () or 0
    agents_reporting = db.query(AgentMonitorLog.agent_id).join(Agent).filter(*base).distinct().count()
    return {"total_logs": total_logs, "avg_cpu_percent": round(float(avg_cpu), 1), "avg_ram_percent": round(float(avg_ram), 1), "agents_reporting": agents_reporting}
@app.post("/api/agents/{agent_id}/telemetry/report")
async def report_agent_telemetry(agent_id: str, data: TelemetryReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    if data.hostname: agent.hostname = data.hostname
    if data.os_type: agent.os_type = data.os_type
    if data.processor: agent.cpu_model = data.processor
    if data.cpu_cores: agent.cpu_cores = data.cpu_cores
    if data.ram_gb: agent.ram_total_gb = int(data.ram_gb)
    if data.mac_address: agent.mac_address = data.mac_address
    if data.platform: agent.os_version = data.platform
    agent.last_heartbeat = datetime.utcnow()
    agent.status = "online"
    db.commit()
    return {"message": "Telemetry recorded", "agent_id": agent_id, "fields_received": data.fields_present, "schema_version": data.schema_version, "format_valid": data.format_valid}
@app.get("/api/agents/{agent_id}/pre-execution-events")
async def get_agent_pre_execution(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_execution_prevention_stats(db, agent)}
@app.post("/api/agents/{agent_id}/pre-execution-events/report")
async def report_agent_pre_execution(agent_id: str, data: PreExecEventReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    event = ProcessExecutionEvent(agent_id=agent_id, process_name=data.process_name, process_path=data.process_path, file_hash=data.file_hash, blocked=data.blocked, reason=data.reason)
    db.add(event)
    if data.file_hash:
        _auto_scan_and_alert(agent_id, db, hashes=[data.file_hash])
    if data.blocked:
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "malware", Alert.status == "open", Alert.title.like(f"%{data.process_name}%")).first()
        if not existing:
            db.add(Alert(agent_id=agent_id, title=f"Pre-Execution Blocked: {data.process_name}", description=f"Process execution prevented. Hash matchedknown malware. Path: {data.process_path}", severity="critical", type="malware", mitre_tactic_id=MITRE_ATTACK_MAP["pre_execution_prevention"]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP["pre_execution_prevention"]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP["pre_execution_prevention"]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP["pre_execution_prevention"]["technique_name"], score=95.0, details=json.dumps({"process_name": data.process_name, "process_path": data.process_path, "file_hash": data.file_hash, "reason": data.reason}) ))
    db.commit()
    return {"message": "Execution event recorded", "agent_id": agent_id, "blocked": data.blocked, "reason": data.reason}
@app.get("/api/agents/{agent_id}/registry-monitoring")
async def get_agent_registry_monitoring(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_registry_monitoring_stats(db, agent)}
@app.post("/api/agents/{agent_id}/registry-monitoring/report")
async def report_agent_registry_change(agent_id: str, data: RegistryChangeReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    change = RegistryChange(agent_id=agent_id, key_path=data.key_path, value_name=data.value_name, old_value=data.old_value, new_value=data.new_value, change_type=data.change_type, is_auto_start=data.is_auto_start)
    db.add(change)
    if data.is_auto_start:
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "persistence", Alert.status == "open", Alert.title.like(f"%Registry% {data.value_name}%")).first()
        if not existing:
            db.add(Alert(agent_id=agent_id, title=f"Registry Persistence Added: {data.value_name}", description=f"New auto-start registry entry in Run key: {data.key_path}\\{data.value_name}", severity="high", type="persistence", mitre_tactic_id=MITRE_ATTACK_MAP["registry_monitoring"]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP["registry_monitoring"]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP["registry_monitoring"]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP["registry_monitoring"]["technique_name"], score=75.0, details=json.dumps({"key_path": data.key_path, "value_name": data.value_name, "new_value": data.new_value, "is_auto_start": data.is_auto_start}) ))
    db.commit()
    return {"message": "Registry change recorded", "agent_id": agent_id, "is_auto_start": data.is_auto_start}
@app.get("/api/agents/{agent_id}/zero-day-findings")
async def get_agent_zero_day(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_zero_day_stats(db, agent)}
@app.post("/api/agents/{agent_id}/zero-day-findings/report")
async def report_agent_zero_day(agent_id: str, data: ZeroDayReport, agent: Agent
= Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    finding = ZeroDayFinding(agent_id=agent_id, file_name=data.file_name, file_path=data.file_path, unknown_hash=data.unknown_hash, risky_location=data.risky_location)
    db.add(finding)
    if data.unknown_hash or data.risky_location:
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "zero_day", Alert.status == "open").first()
        if not existing:
            reasons = []
            if data.unknown_hash: reasons.append("unknown hash")
            if data.risky_location: reasons.append("risky location")
            db.add(Alert(agent_id=agent_id, title=f"Zero-Day Suspicious File: {data.file_name}", description=f"Unknown executable in suspicious location.Reasons: {', '.join(reasons)}", severity="high", type="zero_day", mitre_tactic_id=MITRE_ATTACK_MAP["zero_day_detection"]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP["zero_day_detection"]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP["zero_day_detection"]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP["zero_day_detection"]["technique_name"], score=85.0, details=json.dumps({"file_name": data.file_name, "file_path": data.file_path, "unknown_hash": data.unknown_hash, "risky_location": data.risky_location}) ))
    db.commit()
    return {"message": "Zero-day finding recorded", "agent_id": agent_id, "file": data.file_name}
@app.post("/api/agents/{agent_id}/buffer-polish/report")
async def report_agent_buffer_polish(agent_id: str, data: BufferPolishReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    if data.hostname: agent.hostname = data.hostname
    if data.os: agent.os_type = data.os
    if data.cpu_usage: agent.cpu_usage = data.cpu_usage
    if data.ram_used_gb: agent.ram_used_gb = data.ram_used_gb
    if data.ram_total_gb: agent.ram_total_gb = int(data.ram_total_gb)
    if data.mac: agent.mac_address = data.mac
    log = AgentMonitorLog(agent_id=agent_id, cpu_percent=data.cpu_usage, ram_percent=round(data.ram_used_gb / max(data.ram_total_gb, 1) * 100, 1) if data.ram_total_gb else 0.0, interval_seconds=30)
    db.add(log)
    agent.last_heartbeat = datetime.utcnow()
    agent.status = data.status if data.status in ("healthy", "degraded", "offline") else "online"
    db.commit()
    return {"message": "Buffer polish telemetry recorded", "agent_id": agent_id, "status": agent.status, "cpu_usage": data.cpu_usage}
@app.get("/api/agents/{agent_id}/fileless-detection")
async def get_agent_fileless(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_fileless_stats(db, agent)}
@app.post("/api/agents/{agent_id}/fileless-detection/report")
async def report_agent_fileless(agent_id: str, data: FilelessDetectionEventReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    event = FilelessDetectionEvent(agent_id=agent_id, pid=data.pid, process_name=data.process_name, reason=data.reason, eventlog_alert=data.eventlog_alert)
    db.add(event)
    existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "fileless_malware", Alert.status == "open").first()
    if not existing:
        db.add(Alert(agent_id=agent_id, title=f"Fileless Malware: {data.process_name}", description=data.reason, severity="critical", type="fileless_malware", mitre_tactic_id=MITRE_ATTACK_MAP["fileless_detection"]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP["fileless_detection"]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP["fileless_detection"]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP["fileless_detection"]["technique_name"], score=90.0, details=json.dumps({"pid": data.pid, "process_name": data.process_name, "reason": data.reason, "eventlog_alert": data.eventlog_alert}) ))
    db.commit()
    return {"message": "Fileless detection recorded", "agent_id": agent_id, "reason": data.reason}
@app.get("/api/agents/{agent_id}/memory-scan")
async def get_agent_memory_scan(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_memory_scan_stats(db, agent)}
@app.post("/api/agents/{agent_id}/memory-scan/report")
async def report_agent_memory_scan(agent_id: str, data: MemoryScanEventReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    event = MemoryScanEvent(agent_id=agent_id, pid=data.pid, process_name=data.process_name, reason=data.reason, shellcode_detected=data.shellcode_detected)
    db.add(event)
    if data.shellcode_detected:
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "fileless_malware", Alert.status == "open").first()
        if not existing:
            db.add(Alert(agent_id=agent_id, title=f"Memory Scan: Shellcode Detected in {data.process_name}", description=data.reason, severity="critical", type="fileless_malware", mitre_tactic_id=MITRE_ATTACK_MAP["memory_scan"]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP["memory_scan"]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP["memory_scan"]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP["memory_scan"]["technique_name"], score=88.0, details=json.dumps({"pid": data.pid, "process_name": data.process_name, "reason": data.reason, "shellcode_detected": data.shellcode_detected}) ))
    db.commit()
    return {"message": "Memory scan recorded", "agent_id": agent_id, "shellcode_detected": data.shellcode_detected}
@app.get("/api/agents/{agent_id}/usb-disk-control")
async def get_agent_usb_disk(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_usb_disk_stats(db, agent)}
@app.post("/api/agents/{agent_id}/usb-disk-control/report")
async def report_agent_usb_disk(agent_id: str, data: UsbDiskEventReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    event = UsbDiskEvent(agent_id=agent_id, usb_devices=json.dumps(data.usb_devices), blocked_devices=json.dumps(data.blocked_devices), usb_control_ok=data.usb_control_ok, encrypted=data.encrypted, protection_on=data.protection_on)
    db.add(event)
    if data.encrypted is not None:
        agent.bitlocker_enabled = data.encrypted
    issues = []
    if not data.usb_control_ok: issues.append("unauthorized USB devices")
    if not data.encrypted: issues.append("disk not encrypted")
    if issues:
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "usb_violation", Alert.status == "open").first()
        if not existing:
            db.add(Alert(agent_id=agent_id, title=f"USB/Disk Security Issue", description=f"Issues: {', '.join(issues)}", severity="high", type="usb_violation", mitre_tactic_id=MITRE_ATTACK_MAP["usb_disk_control"]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP["usb_disk_control"]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP["usb_disk_control"]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP["usb_disk_control"]["technique_name"], score=75.0, details=json.dumps({"usb_control_ok": data.usb_control_ok, "encrypted": data.encrypted, "blocked_devices": data.blocked_devices}) ))
    db.commit()
    return {"message": "USB/Disk control event recorded", "agent_id": agent_id, "usb_control_ok": data.usb_control_ok, "encrypted": data.encrypted}
@app.get("/api/agents/{agent_id}/c2-beaconing")
async def get_agent_c2(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_c2_stats(db, agent)}
@app.post("/api/agents/{agent_id}/c2-beaconing/report")
async def report_agent_c2(agent_id: str, data: C2BeaconingReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    event = C2BeaconingEvent(agent_id=agent_id, src_ip=data.src_ip, dst_ip=data.dst_ip, connections=data.connections, avg_interval=data.avg_interval, variance=data.variance)
    db.add(event)
    if data.dst_ip:
        _auto_scan_and_alert(agent_id, db, ips=[data.dst_ip])
    if data.variance < 25 and data.connections >= 5:
        # Fingerprint on src/dst pair — a second, different beacon target
        # should not be hidden behind an already-open alert for a different one.
        fp = f"beaconing:{data.src_ip}:{data.dst_ip}"
        existing = db.query(Alert).filter(Alert.agent_id == agent_id,
            Alert.type == "beaconing", Alert.status == "open",
            Alert.fingerprint == fp).first()
        if existing:
            existing.occurrence_count += 1
            existing.last_seen_at = datetime.utcnow()
        else:
            db.add(Alert(agent_id=agent_id, title=f"C2 Beaconing Detected: {data.dst_ip}", description=f"Regular beaconing from {data.src_ip}  -> {data.dst_ip} | Avg interval: {data.avg_interval:.1f}s | Variance: {data.variance:.2f}", severity="high", type="beaconing", fingerprint=fp, mitre_tactic_id=MITRE_ATTACK_MAP["c2_beaconing"]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP["c2_beaconing"]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP["c2_beaconing"]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP["c2_beaconing"]["technique_name"], score=80.0, details=json.dumps({"src_ip": data.src_ip, "dst_ip": data.dst_ip, "connections": data.connections, "avg_interval": data.avg_interval, "variance": data.variance}) ))
    db.commit()
    return {"message": "C2 beaconing report recorded", "agent_id": agent_id, "beaconing_detected": data.variance < 25 and data.connections >= 5}
@app.get("/api/agents/{agent_id}/threat-intel")
async def get_agent_threat_intel(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_threat_intel_stats(db, agent)}
@app.post("/api/agents/{agent_id}/threat-intel/report")
async def report_agent_threat_intel(agent_id: str, data: LiveThreatIntelReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    result = LiveThreatIntelResult(agent_id=agent_id, indicator_type=data.indicator_type, indicator=data.indicator, pulse_count=data.pulse_count, reputation=data.reputation, country=data.country, raw_json=data.raw_json)
    db.add(result)
    if data.indicator:
        ioc_type = _detect_ioc_type(data.indicator)
        kwargs = {}
        if ioc_type == "ip": kwargs["ips"] = [data.indicator]
        elif ioc_type == "hash": kwargs["hashes"] = [data.indicator]
        elif ioc_type in ("domain", "url"): kwargs["domains"] = [data.indicator]
        _auto_scan_and_alert(agent_id, db, **kwargs)
    if data.pulse_count > 0:
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "threat_intel_match", Alert.status == "open").first()
        if not existing:
            db.add(Alert(agent_id=agent_id, title=f"Threat Intel Match: {data.indicator}", description=f"Indicator {data.indicator}({data.indicator_type}) has {data.pulse_count} pulse(s) | Reputation: {data.reputation}", severity="high", type="threat_intel_match", mitre_tactic_id=MITRE_ATTACK_MAP["threat_intel"]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP["threat_intel"]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP["threat_intel"]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP["threat_intel"]["technique_name"], score=70.0, details=json.dumps({"indicator_type": data.indicator_type, "indicator": data.indicator, "pulse_count": data.pulse_count, "reputation": data.reputation, "country": data.country}) ))
    db.commit()
    return {"message": "Threat intel result recorded", "agent_id": agent_id, "indicator": data.indicator, "pulse_count": data.pulse_count}
@app.get("/api/agents/{agent_id}/offline-scan")
async def get_agent_offline_scan(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_offline_scan_stats(db, agent)}
@app.post("/api/agents/{agent_id}/offline-scan/report")
async def report_agent_offline_scan(agent_id: str, data: OfflineScanReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    event = OfflineScanEvent(agent_id=agent_id, file_path=data.file_path, file_hash=data.file_hash, threat_name=data.threat_name, scan_directory=data.scan_directory, threats_found=data.threats_found)
    db.add(event)
    if data.file_hash:
        _auto_scan_and_alert(agent_id, db, hashes=[data.file_hash])
    if data.threats_found > 0:
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "offline_threat", Alert.status == "open").first()
        if not existing:
            db.add(Alert(agent_id=agent_id, title=f"Offline Scan Threat: {data.threat_name}", description=f"Threat '{data.threat_name}' found at {data.file_path} (hash: {data.file_hash})", severity="high", type="offline_threat", mitre_tactic_id=MITRE_ATTACK_MAP["offline_protection"]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP["offline_protection"]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP["offline_protection"]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP["offline_protection"]["technique_name"], score=75.0, details=json.dumps({"file_path": data.file_path, "file_hash": data.file_hash, "threat_name": data.threat_name, "scan_directory": data.scan_directory, "threats_found": data.threats_found}) ))
    db.commit()
    return {"message": "Offline scan result recorded", "agent_id": agent_id, "threats_found": data.threats_found}
@app.get("/api/agents/{agent_id}/vulnerability-scan")
async def get_agent_vuln_scan(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_vuln_scan_stats(db, agent)}
@app.post("/api/agents/{agent_id}/vulnerability-scan/report")
async def report_agent_vuln_scan(agent_id: str, data: VulnerabilityScanReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    finding = VulnerabilityFinding(agent_id=agent_id, finding_type=data.finding_type, software=data.software, version=data.version, cve_id=data.cve_id, severity=data.severity, risk=data.risk, description=data.description, port=data.port, service=data.service)
    db.add(finding)
    if data.risk in ("Critical", "HIGH") or data.severity in ("Critical", "High"):
        alert_type = "vulnerability_critical" if data.risk == "Critical" or data.severity == "Critical" else "vulnerability_high"
        mitre_key = "vulnerability_scan"
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == alert_type, Alert.status == "open").first()
        if not existing:
            db.add(Alert(agent_id=agent_id, title=f"Vulnerability: {data.cve_id if data.cve_id else data.finding_type}", description=data.description, severity="critical" if data.risk == "Critical" else "high", type=alert_type, mitre_tactic_id=MITRE_ATTACK_MAP[mitre_key]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP[mitre_key]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP[mitre_key]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP[mitre_key]["technique_name"], score=85.0 if data.risk == "Critical" else 70.0, details=json.dumps({"finding_type": data.finding_type, "software": data.software, "version": data.version, "cve_id": data.cve_id, "severity": data.severity, "port": data.port, "service": data.service, "description": data.description}) ))
    db.commit()
    return {"message": "Vulnerability finding recorded", "agent_id": agent_id, "finding_type": data.finding_type, "risk": data.risk}
@app.get("/api/agents/{agent_id}/process-tree")
async def get_agent_process_tree(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_process_tree_stats(db, agent)}
@app.post("/api/agents/{agent_id}/process-tree/report")
async def report_agent_process_tree(agent_id: str, data: ProcessTreeReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    finding = ProcessTreeFinding(agent_id=agent_id, finding_type=data.finding_type, parent_name=data.parent_name, parent_pid=data.parent_pid, child_name=data.child_name, child_pid=data.child_pid, risk=data.risk, description=data.description, cmdline=data.cmdline)
    db.add(finding)
    if data.risk in ("CRITICAL", "HIGH"):
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "process_anomaly", Alert.status == "open").first()
        if not existing:
            db.add(Alert(agent_id=agent_id, title=f"Process Anomaly: {data.finding_type}", description=data.description, severity="critical" if data.risk == "CRITICAL" else "high", type="process_anomaly", mitre_tactic_id=MITRE_ATTACK_MAP["process_tree"]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP["process_tree"]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP["process_tree"]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP["process_tree"]["technique_name"], score=90.0 if data.risk == "CRITICAL" else 70.0, details=json.dumps({"finding_type": data.finding_type, "parent_name": data.parent_name, "child_name": data.child_name, "risk": data.risk, "cmdline": data.cmdline, "description": data.description}) ))
    db.commit()
    return {"message": "Process tree finding recorded", "agent_id": agent_id, "finding_type": data.finding_type, "risk": data.risk}
@app.post("/api/agents/{agent_id}/action-result/report")
async def report_action_result(agent_id: str, data: dict, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    log_action = data.get("action", "unknown")
    target = data.get("target", "")
    result = data.get("result", {})
    status = result.get("status", "unknown")
    # Mark the matching delivered PendingAction as completed/failed so the
    # dashboard reflects real outcomes instead of staying "delivered" forever.
    pending = db.query(PendingAction).filter(
        PendingAction.agent_id == agent_id, PendingAction.action == log_action,
        PendingAction.target == target, PendingAction.status == "delivered",
    ).order_by(PendingAction.delivered_at.desc()).first()
    if pending:
        pending.status = "completed" if status in ("success", "completed", "ok") else "failed"
        pending.completed_at = datetime.utcnow()
        pending.result = json.dumps(result)
        db.commit()
    logger.info(f"Agent {agent_id} reported action result", action=log_action, status=status)
    return {"message": "Action result recorded"}
@app.get("/api/agents/{agent_id}/shadow-it")
async def get_agent_shadow_it(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_shadow_it_stats(db, agent)}
@app.post("/api/agents/{agent_id}/shadow-it/report")
async def report_agent_shadow_it(agent_id: str, data: ShadowITReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    finding = ShadowITFinding(agent_id=agent_id, finding_type=data.finding_type, service_name=data.service_name, domain=data.domain, category=data.category, risk=data.risk, description=data.description, ip=data.ip, mac=data.mac)
    db.add(finding)
    if data.risk == "HIGH" or data.finding_type in ("unauthorized_software",):
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "shadow_it", Alert.status == "open").first()
        if not existing:
            db.add(Alert(agent_id=agent_id, title=f"Shadow IT: {data.service_name if data.service_name else data.finding_type}", description=data.description, severity="high", type="shadow_it", mitre_tactic_id=MITRE_ATTACK_MAP["shadow_it"]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP["shadow_it"]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP["shadow_it"]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP["shadow_it"]["technique_name"], score=65.0, details=json.dumps({"finding_type": data.finding_type, "service_name": data.service_name, "domain": data.domain, "category": data.category, "risk": data.risk, "ip": data.ip, "mac": data.mac, "description": data.description}) ))
    db.commit()
    return {"message": "Shadow IT finding recorded", "agent_id": agent_id, "finding_type": data.finding_type, "risk": data.risk}
@app.get("/api/agents/{agent_id}/exploit-mitigation")
async def get_agent_exploit_mitigation(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_exploit_mitigation_stats(db, agent)}
@app.post("/api/agents/{agent_id}/exploit-mitigation/report")
async def report_agent_exploit_mitigation(agent_id: str, data: ExploitMitigationReport, agent: Agent = Depends(verify_agent_self), db: Session
= Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    event = ExploitMitigationEvent(agent_id=agent_id, aslr_enabled=data.aslr_enabled, aslr_level=data.aslr_level, dep_enabled=data.dep_enabled, dep_policy=data.dep_policy, acg_enabled=data.acg_enabled, os=data.os, risk_summary=data.risk_summary, severity=data.severity)
    db.add(event)
    if data.severity in ("high", "medium"):
        mitre_key = "exploit_mitigation"
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "exploit_mitigation", Alert.status == "open").first()
        if not existing:
            db.add(Alert(agent_id=agent_id, title=f"Exploit Mitigation Issue: {data.risk_summary}", description=data.risk_summary, severity=data.severity, type="exploit_mitigation", mitre_tactic_id=MITRE_ATTACK_MAP[mitre_key]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP[mitre_key]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP[mitre_key]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP[mitre_key]["technique_name"], score=50.0
if data.severity == "medium" else 70.0, details=json.dumps({"aslr_enabled": data.aslr_enabled, "dep_enabled": data.dep_enabled, "acg_enabled": data.acg_enabled, "risk_summary": data.risk_summary}) ))
    db.commit()
    return {"message": "Exploit mitigation report recorded", "agent_id": agent_id, "risk_summary": data.risk_summary}
@app.get("/api/agents/{agent_id}/installation-visibility")
async def get_agent_installation_visibility(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_installation_visibility_stats(db, agent)}
@app.post("/api/agents/{agent_id}/installation-visibility/report")
async def report_agent_installation_visibility(agent_id: str, data: InstallationVisibilityReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    event = InstallationVisibilityEvent(agent_id=agent_id, boot_time=data.boot_time, install_path=data.install_path, running_as_username=data.running_as_username, running_as_admin=data.running_as_admin, os_name=data.os_name, os_release=data.os_release, os_machine=data.os_machine, hostname=data.hostname, agent_version=data.agent_version)
    db.add(event)
    if data.boot_time: agent.last_heartbeat = datetime.utcnow()
    if data.hostname: agent.hostname = data.hostname
    db.commit()
    return {"message": "Installation visibility recorded", "agent_id": agent_id, "hostname": data.hostname}
@app.get("/api/agents/{agent_id}/network-dpi")
async def get_agent_network_dpi(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_network_dpi_stats(db, agent)}
@app.post("/api/agents/{agent_id}/network-dpi/report")
async def report_agent_network_dpi(agent_id: str, data: NetworkDPIReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    event = NetworkDPIEvent(agent_id=agent_id, src_ip=data.src_ip, dst_ip=data.dst_ip, src_port=data.src_port, dst_port=data.dst_port, protocol=data.protocol, reason=data.reason, payload_size=data.payload_size, threat_type=data.threat_type)
    db.add(event)
    if data.dst_ip:
        _auto_scan_and_alert(agent_id, db, ips=[data.dst_ip])
    if data.threat_type in ("suspicious_c2_port", "dns_tunneling", "cleartext_credentials"):
        mitre_key = "network_dpi"
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "network_dpi", Alert.status == "open").first()
        if not existing:
            severity_label = "critical" if data.threat_type == "cleartext_credentials" else "high"
            db.add(Alert(agent_id=agent_id, title=f"DPI: {data.threat_type.replace('_', ' ').title()}", description=data.reason, severity=severity_label, type="network_dpi", mitre_tactic_id=MITRE_ATTACK_MAP[mitre_key]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP[mitre_key]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP[mitre_key]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP[mitre_key]["technique_name"], score=85.0
if data.threat_type == "cleartext_credentials" else 68.0, details=json.dumps({"src_ip": data.src_ip, "dst_ip": data.dst_ip, "dst_port": data.dst_port, "protocol": data.protocol, "threat_type": data.threat_type, "payload_size": data.payload_size, "reason": data.reason}) ))
    db.commit()
    return {"message": "Network DPI event recorded", "agent_id": agent_id, "threat_type": data.threat_type}
@app.get("/api/agents/{agent_id}/privilege-escalation")
async def get_agent_privilege_escalation(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_privilege_escalation_stats(db, agent)}
@app.post("/api/agents/{agent_id}/privilege-escalation/report")
async def report_agent_privilege_escalation(agent_id: str, data: PrivilegeEscalationReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    event = PrivilegeEscalationEvent(agent_id=agent_id, check_type=data.check_type, os=data.os, finding=data.finding, process_name=data.process_name, user=data.user, privilege=data.privilege, risk_reason=data.risk_reason, severity=data.severity)
    db.add(event)
    if data.severity in ("critical", "high"):
        mitre_key = "privilege_escalation"
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "privilege_escalation", Alert.status == "open").first()
        if not existing:
            db.add(Alert(agent_id=agent_id, title=f"Privilege Escalation: {data.check_type.replace('_', ' ').title()}", description=data.finding, severity=data.severity, type="privilege_escalation", mitre_tactic_id=MITRE_ATTACK_MAP[mitre_key]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP[mitre_key]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP[mitre_key]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP[mitre_key]["technique_name"], score=90.0
if data.severity == "critical" else 72.0, details=json.dumps({"check_type": data.check_type, "finding": data.finding, "process_name": data.process_name, "user": data.user, "privilege": data.privilege, "risk_reason": data.risk_reason}) ))
    db.commit()
    return {"message": "Privilege escalation event recorded", "agent_id": agent_id, "severity": data.severity}
@app.get("/api/agents/{agent_id}/silent-deployment")
async def get_agent_silent_deployment(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_silent_deployment_stats(db, agent)}
@app.post("/api/agents/{agent_id}/silent-deployment/report")
async def report_agent_silent_deployment(agent_id: str, data: SilentDeploymentReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    event = SilentDeploymentEvent(agent_id=agent_id, no_window=data.no_window, hidden=data.hidden, startup_type=data.startup_type, process_name=data.process_name, parent_process=data.parent_process, is_silent=data.is_silent)
    db.add(event)
    if data.is_silent:
        mitre_key = "silent_deployment"
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "silent_deployment", Alert.status == "open").first()
        if not existing:
            db.add(Alert(agent_id=agent_id, title="Silent/Binary DeploymentDetected", description=f"Process {data.process_name} running silently (no_window={data.no_window}, hidden={data.hidden}, startup={data.startup_type})", severity="medium", type="silent_deployment", mitre_tactic_id=MITRE_ATTACK_MAP[mitre_key]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP[mitre_key]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP[mitre_key]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP[mitre_key]["technique_name"], score=55.0, details=json.dumps({"no_window": data.no_window, "hidden": data.hidden, "startup_type": data.startup_type, "process_name": data.process_name, "parent_process": data.parent_process, "is_silent": data.is_silent}) ))
    db.commit()
    return {"message": "Silent deployment event recorded", "agent_id": agent_id, "is_silent": data.is_silent}
@app.get("/api/agents/{agent_id}/lateral-movement")
async def get_agent_lateral_movement(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_lateral_movement_stats(db, agent)}
@app.post("/api/agents/{agent_id}/lateral-movement/report")
async def report_agent_lateral_movement(agent_id: str, data: LateralMovementReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    event = LateralMovementEvent(agent_id=agent_id, movement_type=data.movement_type, source_ip=data.source_ip, destination_ip=data.destination_ip, port=data.port, service=data.service, connection_count=data.connection_count, risk=data.risk, description=data.description)
    db.add(event)
    if data.risk in ("CRITICAL", "HIGH"):
        mitre_key = "lateral_movement"
        # Fingerprint on the actual source/destination/port, not just the alert
        # type — otherwise a second attacker hitting a different host gets
        # silently swallowed by an already-open alert from a first attacker.
        fp = f"lateral_movement:{data.source_ip}:{data.destination_ip}:{data.port}"
        existing = db.query(Alert).filter(Alert.agent_id == agent_id,
            Alert.type == "lateral_movement", Alert.status == "open",
            Alert.fingerprint == fp).first()
        if existing:
            existing.occurrence_count += 1
            existing.last_seen_at = datetime.utcnow()
        else:
            db.add(Alert(agent_id=agent_id, title=f"Lateral Movement: {data.movement_type.replace('_', ' ').title()}", description=data.description, severity=data.risk.lower(), type="lateral_movement", fingerprint=fp, mitre_tactic_id=MITRE_ATTACK_MAP[mitre_key]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP[mitre_key]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP[mitre_key]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP[mitre_key]["technique_name"], score=85.0
if data.risk == "CRITICAL" else 68.0, details=json.dumps({"movement_type": data.movement_type, "source_ip": data.source_ip, "destination_ip": data.destination_ip, "port": data.port, "service": data.service, "connection_count": data.connection_count, "risk": data.risk, "description": data.description}) ))
    db.commit()
    return {"message": "Lateral movement event recorded", "agent_id": agent_id, "risk": data.risk}
@app.get("/api/agents/{agent_id}/port-scan")
async def get_agent_port_scan(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_port_scan_stats(db, agent)}
@app.post("/api/agents/{agent_id}/port-scan/report")
async def report_agent_port_scan(agent_id: str, data: PortScanReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    event = PortScanEvent(agent_id=agent_id, scan_type=data.scan_type, scanner_ip=data.scanner_ip, target_ip=data.target_ip, unique_ports=data.unique_ports, sensitive_ports_hit=data.sensitive_ports_hit, syn_count=data.syn_count, risk=data.risk, description=data.description)
    db.add(event)
    # Lightweight statistical baselining: in addition to the static "risk"
    # flag computed by the agent, compare today's unique_ports against this
    # host's own rolling baseline so a host with normally-high traffic
    # doesn't trip the same flat threshold as a quiet one, and vice versa.
    risk = data.risk
    if ML_ENABLED and behavioral_baseliner:
        behavioral_baseliner.update(agent_id, {"net_connections": data.unique_ports})
        is_anomaly, _ = behavioral_baseliner.is_anomalous(agent_id, {"net_connections": data.unique_ports})
        if is_anomaly and risk != "HIGH":
            risk = "HIGH"  # baseline deviation overrides a borderline static verdict
    if risk == "HIGH":
        mitre_key = "port_scan"
        # Fingerprint on scanner+target, not just "port_scan" — otherwise a
        # second, different scanner is suppressed by an already-open alert
        # from an earlier one, and the dashboard never finds out about it.
        fp = f"port_scan:{data.scanner_ip}:{data.target_ip}"
        existing = db.query(Alert).filter(Alert.agent_id == agent_id,
            Alert.type == "port_scan", Alert.status == "open",
            Alert.fingerprint == fp).first()
        if existing:
            existing.occurrence_count += 1
            existing.last_seen_at = datetime.utcnow()
        else:
            db.add(Alert(agent_id=agent_id, title=f"Port Scan: {data.scan_type.replace('_', ' ').title()}", description=data.description, severity="high", type="port_scan", fingerprint=fp, mitre_tactic_id=MITRE_ATTACK_MAP[mitre_key]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP[mitre_key]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP[mitre_key]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP[mitre_key]["technique_name"], score=65.0, details=json.dumps({"scan_type": data.scan_type, "scanner_ip": data.scanner_ip, "target_ip": data.target_ip, "unique_ports": data.unique_ports, "sensitive_ports_hit": data.sensitive_ports_hit, "syn_count": data.syn_count, "risk": data.risk, "description": data.description}) ))
    db.commit()
    return {"message": "Port scan event recorded", "agent_id": agent_id, "risk": data.risk}
@app.get("/api/agents/{agent_id}/host-firewall")
async def get_agent_host_firewall(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_host_firewall_stats(db, agent)}
@app.post("/api/agents/{agent_id}/host-firewall/report")
async def report_agent_host_firewall(agent_id: str, data: HostFirewallReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    event = HostFirewallEvent(agent_id=agent_id, chain=data.chain, rule=data.rule, ip_blocked=data.ip_blocked, action=data.action)
    db.add(event)
    if data.ip_blocked:
        mitre_key = "host_firewall"
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "firewall_block", Alert.status == "open").first()
        if not existing:
            db.add(Alert(agent_id=agent_id, title=f"Firewall Block: {data.ip_blocked}", description=f"IP {data.ip_blocked} blocked on {data.chain}", severity="medium", type="firewall_block", mitre_tactic_id=MITRE_ATTACK_MAP[mitre_key]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP[mitre_key]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP[mitre_key]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP[mitre_key]["technique_name"], score=50.0, details=json.dumps({"chain": data.chain, "rule": data.rule, "ip_blocked": data.ip_blocked, "action": data.action}) ))
    db.commit()
    return {"message": "Host firewall event recorded", "agent_id": agent_id, "action": data.action}
@app.get("/api/agents/{agent_id}/web-dns-filter")
async def get_agent_web_dns_filter(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_web_dns_filter_stats(db, agent)}
@app.post("/api/agents/{agent_id}/web-dns-filter/report")
async def report_agent_web_dns_filter(agent_id: str, data: WebDNSFilterReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    event = WebDNSFilterEvent(agent_id=agent_id, domain=data.domain, url=data.url, action=data.action, matched_pattern=data.matched_pattern)
    db.add(event)
    if data.action == "BLOCK":
        mitre_key = "web_dns_filter"
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "dns_block", Alert.status == "open").first()
        if not existing:
            db.add(Alert(agent_id=agent_id, title=f"DNS/Web Blocked: {data.domain or data.url}", description=f"Blocked by pattern: {data.matched_pattern}", severity="medium", type="dns_block", mitre_tactic_id=MITRE_ATTACK_MAP[mitre_key]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP[mitre_key]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP[mitre_key]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP[mitre_key]["technique_name"], score=55.0, details=json.dumps({"domain": data.domain, "url": data.url, "action": data.action, "matched_pattern": data.matched_pattern}) ))
    db.commit()
    return {"message": "Web/DNS filter event recorded", "agent_id": agent_id, "action": data.action}
@app.get("/api/agents/{agent_id}/script-monitor")
async def get_agent_script_monitor(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_script_monitor_stats(db, agent)}
@app.post("/api/agents/{agent_id}/script-monitor/report")
async def report_agent_script_monitor(agent_id: str, data: ScriptMonitorReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    event = ScriptMonitorEvent(agent_id=agent_id, command=data.command, user=data.user, suspicious_patterns=json.dumps(data.suspicious_patterns), action=data.action)
    db.add(event)
    if data.action == "BLOCK":
        mitre_key = "script_monitor"
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "script_block", Alert.status == "open").first()
        if not existing:
            db.add(Alert(agent_id=agent_id, title=f"Script Blocked for {data.user}", description=f"Suspicious command blocked: {data.command[:80]}", severity="high", type="script_block", mitre_tactic_id=MITRE_ATTACK_MAP[mitre_key]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP[mitre_key]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP[mitre_key]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP[mitre_key]["technique_name"], score=72.0, details=json.dumps({"command": data.command, "user": data.user, "suspicious_patterns": data.suspicious_patterns, "action": data.action}) ))
    elif data.action == "ALERT":
        mitre_key = "script_monitor"
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "script_alert", Alert.status == "open").first()
        if not existing:
            db.add(Alert(agent_id=agent_id, title=f"Suspicious Command: {data.user}", description=f"Patterns: {', '.join(data.suspicious_patterns)}", severity="medium", type="script_alert", mitre_tactic_id=MITRE_ATTACK_MAP[mitre_key]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP[mitre_key]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP[mitre_key]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP[mitre_key]["technique_name"], score=50.0, details=json.dumps({"command": data.command, "user": data.user, "suspicious_patterns": data.suspicious_patterns, "action": data.action}) ))
    db.commit()
    return {"message": "Script monitor event recorded", "agent_id": agent_id, "action": data.action}
@app.get("/api/agents/{agent_id}/ransomware-canary")
async def get_agent_ransomware_canary(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_ransomware_canary_stats(db, agent)}
@app.post("/api/agents/{agent_id}/ransomware-canary/report")
async def report_agent_ransomware_canary(agent_id: str, data: RansomwareCanaryReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    event = RansomwareCanaryEvent(agent_id=agent_id, file_path=data.file_path, reason=data.reason, file_hash=data.file_hash, directory=data.directory)
    db.add(event)
    if data.reason:
        mitre_key = "ransomware_canary"
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "canary_tamper", Alert.status == "open").first()
        if not existing:
            db.add(Alert(agent_id=agent_id, title=f"Ransomware Canary Triggered: {data.reason}", description=f"Canary file {data.file_path}{data.reason.lower()}", severity="critical", type="canary_tamper", mitre_tactic_id=MITRE_ATTACK_MAP[mitre_key]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP[mitre_key]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP[mitre_key]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP[mitre_key]["technique_name"], score=95.0, details=json.dumps({"file_path": data.file_path, "reason": data.reason, "file_hash": data.file_hash, "directory": data.directory}) ))
    db.commit()
    return {"message": "Ransomware canary event recorded", "agent_id": agent_id, "reason": data.reason}
@app.get("/api/agents/{agent_id}/credential-dumping")
async def get_agent_credential_dumping(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_credential_dumping_stats(db, agent)}
@app.post("/api/agents/{agent_id}/credential-dumping/report")
async def report_agent_credential_dumping(agent_id: str, data: CredentialDumpingReport, agent: Agent = Depends(verify_agent_self), db: Session
= Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    event = CredentialDumpingEvent(agent_id=agent_id, process_name=data.process_name, pid=data.pid, detection_type=data.detection_type)
    db.add(event)
    mitre_key = "credential_dumping"
    existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "credential_dumping", Alert.status == "open").first()
    if not existing:
        db.add(Alert(agent_id=agent_id, title=f"Credential Dumping: {data.process_name}", description=f"Suspicious process {data.process_name} (PID: {data.pid}) - {data.detection_type}", severity="critical", type="credential_dumping", mitre_tactic_id=MITRE_ATTACK_MAP[mitre_key]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP[mitre_key]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP[mitre_key]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP[mitre_key]["technique_name"], score=92.0, details=json.dumps({"process_name": data.process_name, "pid": data.pid, "detection_type": data.detection_type}) ))
    db.commit()
    return {"message": "Credential dumping event recorded", "agent_id": agent_id, "process_name": data.process_name}
@app.get("/api/agents/{agent_id}/next-gen-av")
async def get_agent_next_gen_av(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_next_gen_av_stats(db, agent)}
@app.post("/api/agents/{agent_id}/next-gen-av/report")
async def report_agent_next_gen_av(agent_id: str, data: NextGenAVReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    event = NextGenAVEvent(agent_id=agent_id, file_path=data.file_path, file_hash=data.file_hash, detection_reason=data.detection_reason, action=data.action, scanner_type=data.scanner_type)
    db.add(event)
    if data.file_hash:
        _auto_scan_and_alert(agent_id, db, hashes=[data.file_hash])
    if data.action in ("malicious", "quarantined"):
        mitre_key = "next_gen_av"
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "next_gen_av", Alert.status == "open").first()
        if not existing:
            db.add(Alert(agent_id=agent_id, title=f"Next-Gen AV: {data.detection_reason[:60]}", description=f"File {data.file_path} detected as malicious by {data.scanner_type} scanner", severity="critical" if data.action == "quarantined" else "high", type="next_gen_av", mitre_tactic_id=MITRE_ATTACK_MAP[mitre_key]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP[mitre_key]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP[mitre_key]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP[mitre_key]["technique_name"], score=88.0
if data.action == "quarantined" else 72.0, details=json.dumps({"file_path": data.file_path, "file_hash": data.file_hash, "detection_reason": data.detection_reason, "action": data.action, "scanner_type": data.scanner_type}) ))
    db.commit()
    return {"message": "Next-Gen AV event recorded", "agent_id": agent_id, "action": data.action}
@app.get("/api/agents/{agent_id}/user-behaviour")
async def get_agent_user_behaviour(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return {"agent_id": agent_id, "hostname": agent.hostname, **generate_user_behaviour_stats(db, agent)}
@app.post("/api/agents/{agent_id}/user-behaviour/report")
async def report_agent_user_behaviour(agent_id: str, data: UserBehaviourReport, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    event = UserBehaviourEvent(agent_id=agent_id, file_path=data.file_path, action=data.action, baseline_hash=data.baseline_hash, current_hash=data.current_hash)
    db.add(event)
    if data.action in ("modified", "deleted"):
        mitre_key = "user_behaviour"
        existing = db.query(Alert).filter(Alert.agent_id == agent_id, Alert.type == "file_tamper", Alert.status == "open").first()
        if not existing:
            db.add(Alert(agent_id=agent_id, title=f"File Tamper: {data.file_path} {data.action}", description=f"Protected file {data.file_path} was {data.action}", severity="high", type="file_tamper", mitre_tactic_id=MITRE_ATTACK_MAP[mitre_key]["tactic_id"], mitre_tactic_name=get_mitre_tactic_name(MITRE_ATTACK_MAP[mitre_key]["tactic_id"]), mitre_technique_id=MITRE_ATTACK_MAP[mitre_key]["technique_id"], mitre_technique_name=MITRE_ATTACK_MAP[mitre_key]["technique_name"], score=70.0, details=json.dumps({"file_path": data.file_path, "action": data.action, "baseline_hash": data.baseline_hash, "current_hash": data.current_hash}) ))
    db.commit()
    return {"message": "User behaviour event recorded", "agent_id": agent_id, "action": data.action}
@app.websocket("/ws/alerts")
async def websocket_alerts(websocket: WebSocket):
    await ws_alerts.connect(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        ws_alerts.disconnect(websocket)
@app.websocket("/ws/agents")
async def websocket_agents(websocket: WebSocket):
    await ws_agents.connect(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        ws_agents.disconnect(websocket)
@app.websocket("/ws/monitoring/{agent_id}")
async def websocket_monitoring(websocket: WebSocket, agent_id: str):
    if agent_id not in ws_monitoring:
        ws_monitoring[agent_id] = ConnectionManager()
    await ws_monitoring[agent_id].connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
    except WebSocketDisconnect:
        ws_monitoring[agent_id].disconnect(websocket)
# ============================================================================= # NEW ENGINE ENDPOINTS (Behavioral Detection, Risk Scoring, Correlation, Response, ML)
# =============================================================================
class BehavioralAnalysisRequest(BaseModel):
    process_name: str = ""
    cmdline: str = ""
    parent_name: str = ""
    file_path: str = ""
    user: str = ""
    os_type: str = "windows"
    event_type: str = "process_execution"
class RiskEventRequest(BaseModel):
    event_type: str = "behavioral_anomaly"
    severity: str = "medium"
    score: float = 0.0
    details: str = "{}"
class ResponseEvaluateRequest(BaseModel):
    event_type: str = ""
    severity: str = "medium"
    details: dict = {}
    agent_id: str = ""
class MLAnalysisRequest(BaseModel):
    features: dict = {}
    agent_id: str = ""
class BaselinerUpdateRequest(BaseModel):
    cpu_usage: float = 0.0
    ram_usage: float = 0.0
    process_count: int = 0
    net_connections: int = 0
    agent_id: str = ""
@app.post("/api/agents/{agent_id}/behavioral/analyze")
async def analyze_behavioral(agent_id: str, data: BehavioralAnalysisRequest, agent: Agent = Depends(verify_agent_self), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    result = behavioral_engine.analyze_process(
        process_name=data.process_name,
        cmdline=data.cmdline,
        parent_name=data.parent_name,
        file_path=data.file_path,
        user=data.user,
        os_type=data.os_type,
        agent_id=agent_id,
    )
    risk_score = risk_scoring_engine.calculate_behavioral_score(result.to_dict(), agent_id)
    threshold_check = risk_scoring_engine.check_threshold(risk_score)
    incident = correlation_engine.ingest_event(
        event={"event_type": "behavioral_anomaly", "severity": risk_score.severity, "score": risk_score.total_score, "details": result.to_dict()},
        agent_id=agent_id,
        event_type="behavioral_anomaly",
        source="behavioral_engine",
    )
    if threshold_check.get("triggered"):
        response_engine.evaluate_event({
            "event_type": "behavioral_anomaly",
            "severity": risk_score.severity,
            "score": risk_score.total_score,
        }, agent_id)
        alert = Alert(
            agent_id=agent_id,
            title=f"Behavioral Detection: {', '.join(result.detection_types)[:100]}" if result.detection_types else "Behavioral Anomaly",
            description=threshold_check["message"],
            severity=risk_score.severity,
            type="behavioral_anomaly",
            score=risk_score.total_score,
            details=json.dumps({"findings": result.findings, "risk_score": risk_score.to_dict()}),
        )
        db.add(alert)
        db.commit()
    return {
        "agent_id": agent_id,
        "behavioral": result.to_dict(),
        "risk_score": risk_score.to_dict(),
        "threshold_check": threshold_check,
        "incident_id": incident.incident_id if incident else None,
    }
@app.get("/api/agents/{agent_id}/risk-score")
async def get_agent_risk_score(agent_id: str, agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    return risk_scoring_engine.get_agent_risk_summary(agent_id)
@app.post("/api/risk-score/event")
async def record_risk_event(data: RiskEventRequest, db: Session = Depends(get_db)):
    score = risk_scoring_engine.calculate_score(
        event_type=data.event_type,
        severity=data.severity,
        agent_id="system",
    )
    threshold_check = risk_scoring_engine.check_threshold(score)
    return {
        "risk_score": score.to_dict(),
        "threshold_check": threshold_check,
    }
@app.get("/api/risk-score/thresholds")
async def get_risk_thresholds():
    return risk_scoring_engine.thresholds
@app.get("/api/correlation/incidents")
async def list_incidents(status: Optional[str] = None):
    if status == "open":
        return correlation_engine.get_active_incidents()
    return correlation_engine.get_active_incidents()
@app.get("/api/correlation/incidents/{incident_id}")
async def get_incident(incident_id: str):
    incident = correlation_engine.get_incident(incident_id)
    if not incident:
        raise HTTPException(status_code=404, detail="Incident not found")
    return incident
@app.post("/api/correlation/incidents/{incident_id}/resolve")
async def resolve_incident(incident_id: str):
    success = correlation_engine.resolve_incident(incident_id)
    if not success:
        raise HTTPException(status_code=404, detail="Incident not found")
    return {"incident_id": incident_id, "status": "resolved"}
@app.post("/api/correlation/incidents/{incident_id}/ai-report")
async def incident_ai_report(incident_id: str, current_user: User = Depends(get_current_user)):
    incident = correlation_engine.get_incident(incident_id)
    if not incident:
        raise HTTPException(status_code=404, detail="Incident not found")
    events = incident.get("events", [])
    alerts_for_prompt = [
        {"severity": e.get("severity", ""), "title": e.get("title") or e.get("event_type", ""), "description": e.get("description", "")}
        for e in events
    ]
    report = ai_analysis_service.generate_incident_report(incident, alerts_for_prompt)
    return {"incident_id": incident_id, "report": report}
@app.post("/api/response/evaluate")
async def evaluate_response(data: ResponseEvaluateRequest):
    event = {
        "event_type": data.event_type,
        "severity": data.severity,
        **(data.details or {}),
    }
    triggered = response_engine.evaluate_event(event, data.agent_id)
    return {
        "triggered_actions": triggered,
        "policy_count": len(response_engine.policies),
    }
@app.get("/api/response/history")
async def get_response_history(limit: int = Query(50, ge=1, le=500)):
    return response_engine.get_action_history(limit)
@app.post("/api/response/execute")
async def execute_response_action(action: str = Query(...), target: str = Query(...), agent_id: str = Query(...), agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    try:
        resp_action = ResponseAction(action)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid action: {action}")
    result = response_engine.execute_action(resp_action, target, agent_id)
    return result
@app.post("/api/ml/analyze")
async def ml_analyze(data: MLAnalysisRequest):
    if not ML_ENABLED:
        return {"status": "ml_disabled", "message": "ML detection is disabled."}
    results = {}
    try:
        if data.features:
            iforest_result = iforest_detector.predict(data.features)
            results["isolation_forest"] = {"is_anomaly": bool(iforest_result[0]), "score": iforest_result[1]}
            svm_result = svm_detector.predict(data.features)
            results["one_class_svm"] = {"is_anomaly": bool(svm_result[0]), "score": svm_result[1]}
        if data.agent_id and behavioral_baseliner:
            baseline_result = behavioral_baseliner.get_agent_status(data.agent_id)
            results["baseline"] = baseline_result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    return results
@app.post("/api/ml/baseline/update")
async def update_baseline(data: BaselinerUpdateRequest, db: Session = Depends(get_db)):
    if not ML_ENABLED or not behavioral_baseliner:
        return {"status": "ml_disabled"}
    metrics = {
        "cpu_usage": data.cpu_usage,
        "ram_usage": data.ram_usage,
        "process_count": data.process_count,
        "net_connections": data.net_connections,
    }
    behavioral_baseliner.update(data.agent_id, metrics)
    is_anomaly, details = behavioral_baseliner.is_anomalous(data.agent_id, metrics)
    if is_anomaly:
        alert = Alert(
            agent_id=data.agent_id,
            title="Behavioral Baseline Anomaly",
            description=f"Deviation from established baseline detected",
            severity="medium",
            type="behavioral_anomaly",
            score=50.0,
            details=json.dumps(details),
        )
        db.add(alert)
        db.commit()
    return {
        "status": "updated",
        "is_anomalous": is_anomaly,
        "details": details,
    }
@app.get("/api/behavioral/patterns")
async def list_behavioral_patterns():
    from detector.patterns import LOLBINS, SUSPICIOUS_CMD_PATTERNS
    from detector.persistence import REGISTRY_AUTORUN_KEYS, SCHEDULED_TASK_PATTERNS, WMI_ABUSE_PATTERNS
    from detector.lateral_movement import LATERAL_MOVEMENT_PATTERNS
    return {
        "lolbins": {k: {"risk": v["risk"], "description": v["description"]} for k, v in LOLBINS.items()},
        "suspicious_commands": [{"type": p[0], "risk_score": p[2]} for p in SUSPICIOUS_CMD_PATTERNS],
        "registry_autorun_keys": [k["key"] for k in REGISTRY_AUTORUN_KEYS],
        "scheduled_task_patterns": SCHEDULED_TASK_PATTERNS,
        "wmi_abuse_patterns": WMI_ABUSE_PATTERNS,
        "lateral_movement_patterns": LATERAL_MOVEMENT_PATTERNS,
        "total_patterns": len(LOLBINS) + len(SUSPICIOUS_CMD_PATTERNS) + len(REGISTRY_AUTORUN_KEYS) + len(SCHEDULED_TASK_PATTERNS) + len(WMI_ABUSE_PATTERNS) + len(LATERAL_MOVEMENT_PATTERNS),
    }
@app.get("/api/engine/status")
async def engine_status():
    return {
        "behavioral_engine": {"enabled": behavioral_engine.enabled},
        "risk_scoring_engine": {"thresholds": risk_scoring_engine.thresholds},
        "correlation_engine": {"active_incidents": len(correlation_engine.get_active_incidents())},
        "response_engine": {"enabled": response_engine.enabled, "policies": len(response_engine.policies)},
        "ml_detection": {"enabled": ML_ENABLED, "iforest": iforest_detector.is_available(), "svm": svm_detector.is_available(), "baseliner": behavioral_baseliner is not None},
        "platform": {"type": platform_abstraction.detect_os()},
    }
# ---------------------------------------------------------------------------
# Agent-side Response Actions: pending actions polling
# ---------------------------------------------------------------------------
@app.get("/api/agents/{agent_id}/pending-actions")
async def get_pending_actions(agent_id: str, agent: Agent = Depends(verify_agent_self),
                               db: Session = Depends(get_db)):
    # Was: actions = _pending_actions.pop(agent_id, []) — in-memory, lost on restart,
    # and callable by anyone who knew the agent_id (no auth at all).
    rows = db.query(PendingAction).filter(PendingAction.agent_id == agent_id,
                                           PendingAction.status == "pending").all()
    actions = []
    for r in rows:
        actions.append({"action": r.action, "target": r.target, "source": r.source,
                         "created_at": r.created_at.isoformat()})
        r.status = "delivered"
        r.delivered_at = datetime.utcnow()
    db.commit()
    return {"agent_id": agent_id, "actions": actions}
@app.post("/api/agents/{agent_id}/block")
async def block_agent_target(agent_id: str, target: str = Query(...), agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    action = PendingAction(agent_id=agent_id, action="network_block", target=target,
                            source="manual")
    db.add(action)
    db.commit()
    return {"status": "queued", "action": {"action": action.action, "target":
            action.target, "source": action.source, "created_at": action.created_at.isoformat()}}
@app.post("/api/agents/{agent_id}/isolate")
async def isolate_agent(agent_id: str, agent: Agent = Depends(get_owned_agent),
                         db: Session = Depends(get_db)):
    action = PendingAction(agent_id=agent_id, action="host_isolate", target="",
                            source="manual")
    db.add(action)
    db.commit()
    return {"status": "queued", "action": {"action": action.action, "target":
            action.target, "source": action.source, "created_at": action.created_at.isoformat()}}
@app.post("/api/agents/{agent_id}/kill-process")
async def kill_agent_process(agent_id: str, pid: int = Query(...), agent: Agent
= Depends(get_owned_agent), db: Session = Depends(get_db)):
    action = PendingAction(agent_id=agent_id, action="process_terminate", target=str(pid),
                            source="manual")
    db.add(action)
    db.commit()
    return {"status": "queued", "action": {"action": action.action, "target":
            action.target, "source": action.source, "created_at": action.created_at.isoformat()}}
@app.post("/api/agents/{agent_id}/quarantine-file")
async def quarantine_agent_file(agent_id: str, file_path: str = Query(...), agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    action = PendingAction(agent_id=agent_id, action="quarantine_file", target=file_path,
                            source="manual")
    db.add(action)
    db.commit()
    return {"status": "queued", "action": {"action": action.action, "target":
            action.target, "source": action.source, "created_at": action.created_at.isoformat()}}
@app.post("/api/agents/{agent_id}/dns-block")
async def dns_block_agent(agent_id: str, domain: str = Query(...), agent: Agent
= Depends(get_owned_agent), db: Session = Depends(get_db)):
    action = PendingAction(agent_id=agent_id, action="dns_block", target=domain,
                            source="manual")
    db.add(action)
    db.commit()
    return {"status": "queued", "action": {"action": action.action, "target":
            action.target, "source": action.source, "created_at": action.created_at.isoformat()}}
# Modify execute_action to also queue pending actions
_original_execute = response_engine.execute_action
def _patched_execute(action, target, agent_id):
    result = _original_execute(action, target, agent_id)
    db = SessionLocal()
    try:
        db.add(PendingAction(agent_id=agent_id, action=action.value, target=target,
                              source="policy"))
        db.commit()
    finally:
        db.close()
    return result
response_engine.execute_action = _patched_execute
# ---------------------------------------------------------------------------
# Agent Grouping
# ---------------------------------------------------------------------------
@app.patch("/api/agents/{agent_id}/group")
async def set_agent_group(agent_id: str, group: str = Query(...), agent: Agent = Depends(get_owned_agent), db: Session = Depends(get_db)):
    agent = db.query(Agent).filter(Agent.id == agent_id).first()
    if not agent:
        raise HTTPException(status_code=404, detail="Agent not found")
    agent.group_name = group
    db.commit()
    return {"agent_id": agent_id, "group": group}
@app.get("/api/agents/groups")
async def list_groups(db: Session = Depends(get_db)):
    groups = db.query(Agent.group_name, func.count(Agent.id)).filter(Agent.group_name != "").group_by(Agent.group_name).all()
    return {g: c for g, c in groups}
# ---------------------------------------------------------------------------
# Report Export (CSV/PDF)
# ---------------------------------------------------------------------------
import csv, io
@app.get("/api/reports/export")
async def export_report(type: str = Query("csv"), agent_id: str = Query(None), hours: int = Query(24), db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    query = db.query(Alert)
    if agent_id:
        query = query.filter(Alert.agent_id == agent_id)
    query = query.filter(Alert.created_at >= datetime.utcnow() - timedelta(hours=hours))
    alerts = query.order_by(Alert.created_at.desc()).all()
    if type == "csv":
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["ID", "Title", "Severity", "Type", "Status", "AgentID", "Created At"])
        for a in alerts:
            writer.writerow([a.id, a.title, a.severity, a.type, a.status, a.agent_id, a.created_at.isoformat() if a.created_at else ""])
        return Response(content=output.getvalue(), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=alerts_report.csv"})
    return {"alerts": [{"id": a.id, "title": a.title, "severity": a.severity, "type": a.type, "status": a.status, "agent_id": a.agent_id, "created_at": a.created_at.isoformat() if a.created_at else ""} for a in alerts]}
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)

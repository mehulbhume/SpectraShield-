"""
AI-powered alert analysis using Google AI Studio (Gemini).

Given an alert's details, this service asks Gemini to produce a plain-English
summary, the likely attacker intent, a recommended response action, and a
confidence level. It fails safe: if no API key is configured, the feature is
disabled, or the API call errors out, it returns a clearly-labelled fallback
response instead of raising, so the rest of the platform keeps working.

It also pulls in real threat-intel data (VirusTotal, MalwareBazaar, URLhaus,
AbuseIPDB, OTX, GreyNoise -- via services.threat_intel.ThreatIntelService) for
any IP/hash/URL/domain found in the alert, so the AI's explanation is grounded
in actual verdicts instead of just guessing from the alert text.
"""
import json
import re
import requests

GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"

# ---------------------------------------------------------------------------
# IOC extraction — pulls IPs, hashes, URLs, domains out of an alert so they
# can be sent to real threat-intel providers (VirusTotal, MalwareBazaar, etc.)
# ---------------------------------------------------------------------------
_IOC_KEYS = (
    "ip", "src_ip", "dst_ip", "target_ip", "scanner_ip", "ip_blocked",
    "ip_address", "indicator", "domain", "url", "file_hash", "unknown_hash",
    "hash", "md5", "sha1", "sha256", "process_hash", "source_ip", "destination_ip",
)
_IP_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
_HASH_RE = re.compile(r"\b[a-fA-F0-9]{64}\b|\b[a-fA-F0-9]{40}\b|\b[a-fA-F0-9]{32}\b")
_URL_RE = re.compile(r"https?://[^\s\"'\]]+")


def extract_iocs(alert: dict, max_iocs: int = 5) -> list:
    """Return up to max_iocs distinct indicator strings (IP/hash/URL/domain) found in an alert."""
    found = []

    def _add(val):
        if val and isinstance(val, str) and val not in found:
            found.append(val)

    details = alert.get("details", {})
    if isinstance(details, str):
        try:
            details = json.loads(details)
        except (json.JSONDecodeError, TypeError):
            details = {}
    if isinstance(details, dict):
        for key, val in details.items():
            if key.lower() in _IOC_KEYS and isinstance(val, str):
                _add(val)

    blob_parts = [alert.get("title", "") or "", alert.get("description", "") or ""]
    if isinstance(details, dict):
        blob_parts.append(json.dumps(details))
    blob = " ".join(blob_parts)
    for regex in (_URL_RE, _IP_RE, _HASH_RE):
        for m in regex.findall(blob):
            _add(m)

    return found[:max_iocs]


class AIAnalysisService:
    def __init__(self, api_key: str = "", model: str = "gemini-2.5-flash", enabled: bool = True, timeout: int = 20):
        self.api_key = api_key or ""
        self.model = model or "gemini-2.5-flash"
        self.enabled = bool(enabled) and bool(self.api_key)
        self.timeout = timeout

    def is_available(self) -> bool:
        return self.enabled

    def _build_prompt(self, alert: dict, enrichment: dict = None) -> str:
        details = alert.get("details", {})
        if isinstance(details, str):
            details_str = details[:2000]
        else:
            details_str = json.dumps(details)[:2000]

        intel_lines = []
        for ioc, result in (enrichment or {}).items():
            if not isinstance(result, dict) or "error" in result and not result.get("found"):
                intel_lines.append(f"- {ioc}: no threat-intel data found")
                continue
            vt = result.get("providers", {}).get("virustotal", {})
            vt_summary = ""
            if isinstance(vt, dict) and vt.get("found") is not None and "error" not in vt:
                vt_summary = f", VirusTotal: {vt.get('malicious', 0)}/{vt.get('total', 0)} engines flagged malicious"
            intel_lines.append(
                f"- {ioc} ({result.get('type', 'unknown')}): reputation={result.get('reputation', 'unknown')} "
                f"(score {result.get('reputation_score', 0)}/100){vt_summary}, "
                f"malware_family={result.get('malware_family') or 'none'}"
            )
        intel_block = ("\n\nReal threat-intel lookups for indicators found in this alert:\n" + "\n".join(intel_lines)) if intel_lines else ""

        return (
            "You are a SOC (Security Operations Center) analyst assistant. "
            "Analyze the following security alert and respond ONLY with a JSON object "
            "with exactly these keys: "
            '"summary" (2-3 plain-English sentences on what happened and why it matters), '
            '"likely_intent" (one short phrase describing the probable attacker goal), '
            '"recommended_action" (one concrete next step, e.g. isolate host, block IP, monitor further), '
            '"confidence" ("low", "medium", or "high"), '
            '"mitre_explanation" (1-2 plain-English sentences explaining what the MITRE ATT&CK technique '
            'listed below means and why it matters here; empty string if no MITRE technique is given). '
            "Base your answer on the real threat-intel data below when it is present, rather than guessing.\n\n"
            f"Alert title: {alert.get('title', '')}\n"
            f"Type: {alert.get('type', '')}\n"
            f"Severity: {alert.get('severity', '')}\n"
            f"MITRE technique: {alert.get('mitre_technique_id', '')} {alert.get('mitre_technique_name', '')}\n"
            f"Description: {alert.get('description', '')}\n"
            f"Details: {details_str}"
            f"{intel_block}\n"
        )

    def _fallback(self, message: str, error: bool = False) -> dict:
        return {
            "summary": message,
            "likely_intent": "",
            "recommended_action": "",
            "confidence": "low",
            "mitre_explanation": "",
            "ai_enabled": self.enabled,
            "error": error,
        }

    def _call_gemini(self, prompt: str, json_mode: bool = True):
        """Low-level Gemini call shared by alert analysis, incident reports, and chat.
        Returns (text, error_message). Exactly one of the two is non-empty/None."""
        url = GEMINI_API_URL.format(model=self.model)
        gen_config = {"temperature": 0.3}
        if json_mode:
            gen_config["response_mime_type"] = "application/json"
        try:
            resp = requests.post(
                url,
                params={"key": self.api_key},
                json={"contents": [{"parts": [{"text": prompt}]}], "generationConfig": gen_config},
                timeout=self.timeout,
            )
            resp.raise_for_status()
            data = resp.json()
            text = data["candidates"][0]["content"]["parts"][0]["text"]
            return text, None
        except requests.exceptions.RequestException as e:
            return None, f"AI request failed: {e}"
        except (KeyError, IndexError, json.JSONDecodeError) as e:
            return None, f"AI returned an unexpected response: {e}"
        except Exception as e:
            return None, f"AI call failed: {e}"

    def analyze_alert(self, alert: dict, enrichment: dict = None) -> dict:
        if not self.enabled:
            return self._fallback("AI analysis is disabled or GEMINI_API_KEY is not configured.")
        text, err = self._call_gemini(self._build_prompt(alert, enrichment), json_mode=True)
        if err:
            return self._fallback(err, error=True)
        try:
            parsed = json.loads(text)
            return {
                "summary": parsed.get("summary", ""),
                "likely_intent": parsed.get("likely_intent", ""),
                "recommended_action": parsed.get("recommended_action", ""),
                "confidence": parsed.get("confidence", "low"),
                "mitre_explanation": parsed.get("mitre_explanation", ""),
                "ai_enabled": True,
                "error": False,
            }
        except json.JSONDecodeError as e:
            return self._fallback(f"AI returned an unexpected response: {e}", error=True)

    def generate_incident_report(self, incident: dict, alerts: list) -> dict:
        """Build a narrative incident report from a correlated incident + its
        constituent alerts (used by the /ai-report endpoint)."""
        if not self.enabled:
            return {"report": "AI analysis is disabled or GEMINI_API_KEY is not configured.", "ai_enabled": False, "error": False}
        alerts_lines = []
        for a in alerts[:20]:
            alerts_lines.append(f"- [{a.get('severity', '')}] {a.get('title', '')}: {a.get('description', '')}")
        prompt = (
            "You are a SOC analyst writing an incident report for management. "
            "Respond ONLY with a JSON object with exactly these keys: "
            '"executive_summary" (2-3 sentences, non-technical), '
            '"timeline_narrative" (a short paragraph describing how the attack likely progressed, '
            'based on the attack chain and alerts below), '
            '"root_cause" (best-guess root cause / entry point), '
            '"business_impact" (1-2 sentences), '
            '"recommended_next_steps" (a list of up to 5 short concrete action strings).\n\n'
            f"Incident title: {incident.get('title', '')}\n"
            f"Severity: {incident.get('severity', '')} (score {incident.get('score', 0)})\n"
            f"Affected hosts: {len(incident.get('agent_ids', []))}\n"
            f"Attack chain: {' -> '.join(incident.get('attack_chain', []))}\n"
            f"Matched attack patterns: {json.dumps(incident.get('matched_patterns', []))[:1000]}\n"
            f"Constituent alerts:\n" + "\n".join(alerts_lines)
        )
        text, err = self._call_gemini(prompt, json_mode=True)
        if err:
            return {"report": err, "ai_enabled": True, "error": True}
        try:
            parsed = json.loads(text)
            return {**parsed, "ai_enabled": True, "error": False}
        except json.JSONDecodeError as e:
            return {"report": f"AI returned an unexpected response: {e}", "ai_enabled": True, "error": True}

    def chat(self, question: str, context: dict = None) -> dict:
        """Free-form Q&A grounded in optional alert/incident/IOC context (used by /ai-chat)."""
        if not self.enabled:
            return {"answer": "AI analysis is disabled or GEMINI_API_KEY is not configured.", "ai_enabled": False, "error": False}
        context_block = f"\n\nContext data (JSON):\n{json.dumps(context)[:3000]}" if context else ""
        prompt = (
            "You are a helpful SOC (Security Operations Center) analyst assistant embedded in a "
            "security monitoring dashboard. Answer the analyst's question clearly and concisely, "
            "in plain text (not JSON). Use the context data if it's relevant to the question."
            f"{context_block}\n\nQuestion: {question}"
        )
        text, err = self._call_gemini(prompt, json_mode=False)
        if err:
            return {"answer": err, "ai_enabled": True, "error": True}
        return {"answer": text.strip(), "ai_enabled": True, "error": False}

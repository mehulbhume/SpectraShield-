import json
import os
from typing import Any, Dict, List, Optional

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


def _parse_list(value, default):
    if not value:
        return default
    try:
        return json.loads(value)
    except (json.JSONDecodeError, TypeError):
        return [v.strip() for v in value.split(",") if v.strip()]


def _parse_bool(value, default):
    if not value:
        return default
    return value.lower() in ("1", "true", "yes", "y", "on")


def _parse_int(value, default, min_val=None, max_val=None):
    try:
        v = int(value) if value is not None else default
        if min_val is not None:
            v = max(v, min_val)
        if max_val is not None:
            v = min(v, max_val)
        return v
    except (ValueError, TypeError):
        return default


def _parse_float(value, default):
    try:
        return float(value) if value is not None else default
    except (ValueError, TypeError):
        return default


# --- Database ---
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./agent_security.db")

# --- Security ---
ENV = os.getenv("ENV", "production")
SECRET_KEY = os.getenv("SECRET_KEY", os.getenv("AGENT_SECRET_KEY"))
if not SECRET_KEY:
    if ENV == "production":
        raise RuntimeError(
            "SECRET_KEY is not set. Set the SECRET_KEY environment variable "
            "(e.g. in your .env file) before starting the app in production."
        )
    SECRET_KEY = "dev-only-insecure-key-do-not-use-in-prod"
    print("WARNING: SECRET_KEY not set — using an insecure development key. "
          "Set SECRET_KEY in your environment before deploying.")

# --- CORS ---
CORS_ORIGINS = _parse_list(os.getenv("CORS_ORIGINS"), ["http://localhost:5173", "http://localhost:3000"])

# --- Logging ---
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

# --- Threat Intelligence ---
THREAT_INTEL_URL = os.getenv("THREAT_INTEL_URL", "")
SYNC_INTERVAL = _parse_int(os.getenv("SYNC_INTERVAL"), 3600, 60, 86400)
ENABLE_OFFLINE_MODE = _parse_bool(os.getenv("ENABLE_OFFLINE_MODE"), True)
LOCAL_THREAT_DB_PATH = os.getenv("LOCAL_THREAT_DB_PATH", "./local_threat_db.json")
WEBHOOK_URL = os.getenv("WEBHOOK_URL", "")
TELEMETRY_ENABLED = _parse_bool(os.getenv("TELEMETRY_ENABLED"), True)

# --- Agent Settings ---
AGENT_POLL_INTERVAL = _parse_int(os.getenv("AGENT_POLL_INTERVAL"), 30, 5, 3600)
AGENT_HASH_INTERVAL = _parse_int(os.getenv("AGENT_HASH_INTERVAL"), 150, 10, 86400)

# --- Threat Intelligence Provider API Keys ---
VT_API_KEY = os.getenv("VT_API_KEY", "")
ABUSEIPDB_API_KEY = os.getenv("ABUSEIPDB_API_KEY", "")
OTX_API_KEY = os.getenv("OTX_API_KEY", "")
GREYNOISE_API_KEY = os.getenv("GREYNOISE_API_KEY", "")
VIRUSTOTAL_API_KEY = VT_API_KEY

# --- Behavioral Detection ---
BEHAVIORAL_ANALYSIS_ENABLED = _parse_bool(os.getenv("BEHAVIORAL_ANALYSIS_ENABLED"), True)

# --- ML Detection ---
ML_ENABLED = _parse_bool(os.getenv("ML_ENABLED"), False)

# --- Risk Scoring ---
RISK_SCORE_THRESHOLD_LOW = _parse_int(os.getenv("RISK_SCORE_THRESHOLD_LOW"), 20, 0, 100)
RISK_SCORE_THRESHOLD_MEDIUM = _parse_int(os.getenv("RISK_SCORE_THRESHOLD_MEDIUM"), 40, 0, 100)
RISK_SCORE_THRESHOLD_HIGH = _parse_int(os.getenv("RISK_SCORE_THRESHOLD_HIGH"), 65, 0, 100)
RISK_SCORE_THRESHOLD_CRITICAL = _parse_int(os.getenv("RISK_SCORE_THRESHOLD_CRITICAL"), 85, 0, 100)

# --- Auto Response ---
AUTO_RESPONSE_ENABLED = _parse_bool(os.getenv("AUTO_RESPONSE_ENABLED"), True)

# --- Correlation ---
CORRELATION_TIME_WINDOW = _parse_int(os.getenv("CORRELATION_TIME_WINDOW"), 3600, 60, 604800)

# --- AI Analysis (Google AI Studio / Gemini) ---
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
AI_ANALYSIS_ENABLED = _parse_bool(os.getenv("AI_ANALYSIS_ENABLED"), True)
AI_ANALYSIS_MODEL = os.getenv("AI_ANALYSIS_MODEL", "gemini-2.5-flash")
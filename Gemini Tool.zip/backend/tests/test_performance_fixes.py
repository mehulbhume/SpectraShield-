import json
import os
import shutil
import sys
import tempfile
import time
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# ========== 1. Persistence Monitor Baseline ==========

@pytest.fixture
def baseline_dir():
    path = tempfile.mktemp(suffix="_baseline")
    os.makedirs(path, exist_ok=True)
    yield path
    shutil.rmtree(path, ignore_errors=True)


@pytest.fixture
def mock_baseline_path(monkeypatch, baseline_dir):
    import agent_lib.persistence_monitor as pm
    monkeypatch.setattr(pm, "BASELINE_DIR", baseline_dir)
    monkeypatch.setattr(pm, "BASELINE_FILE", os.path.join(baseline_dir, "persistence_baseline.json"))
    return pm


class TestPersistenceBaseline:
    def test_first_run_saves_baseline_no_alerts(self, mock_baseline_path):
        pm = mock_baseline_path
        monitor = pm.PersistenceMonitor()
        # Mock _scan_services to return fake entries
        monitor._scan_services = lambda: [
            {"type": "service", "service_name": "Spooler", "state": "RUNNING", "display_name": "Print Spooler"},
            {"type": "service", "service_name": "WinDefend", "state": "RUNNING", "display_name": "Windows Defender"},
        ]
        monitor._scan_registry = lambda: []
        monitor._scan_startup_folder = lambda: []
        monitor._scan_scheduled_tasks = lambda: []

        results = monitor.scan()
        assert results == [], "First run should return no alerts"
        assert os.path.exists(pm.BASELINE_FILE), "Baseline file should be created"

        baseline = json.load(open(pm.BASELINE_FILE))
        assert len(baseline) == 2
        assert "service|spooler|print spooler" in baseline
        assert "service|windefend|windows defender" in baseline

    def test_second_run_alerts_only_new(self, mock_baseline_path):
        pm = mock_baseline_path
        monitor = pm.PersistenceMonitor()

        baseline = ["service|spooler|print spooler"]
        json.dump(baseline, open(pm.BASELINE_FILE, "w"))

        monitor._scan_services = lambda: [
            {"type": "service", "service_name": "Spooler", "state": "RUNNING", "display_name": "Print Spooler"},
            {"type": "service", "service_name": "NewMalware", "state": "RUNNING", "display_name": "Suspicious Service"},
        ]
        monitor._scan_registry = lambda: []
        monitor._scan_startup_folder = lambda: []
        monitor._scan_scheduled_tasks = lambda: []

        results = monitor.scan()
        assert len(results) == 1
        assert results[0]["service_name"] == "NewMalware"

    def test_save_and_load_baseline(self, mock_baseline_path):
        pm = mock_baseline_path
        monitor = pm.PersistenceMonitor()

        monitor._baseline = ["service|spooler|print spooler", "reg|hklm\\run\\malware"]
        monitor.save_baseline()

        loaded = monitor.load_baseline()
        assert len(loaded) == 2
        assert "service|spooler|print spooler" in loaded

    def test_update_baseline(self, mock_baseline_path):
        pm = mock_baseline_path
        monitor = pm.PersistenceMonitor()
        monitor._baseline = ["service|spooler|print spooler"]
        monitor.update_baseline([
            {"type": "service", "service_name": "NewService"},
        ])
        assert "service|newservice" in monitor._baseline or "service|newservice|" in "|".join(monitor._baseline)
        assert len(monitor._baseline) == 2

    def test_no_baseline_file_returns_empty(self, mock_baseline_path):
        pm = mock_baseline_path
        monitor = pm.PersistenceMonitor()
        loaded = monitor.load_baseline()
        assert loaded == []


# ========== 2. File Monitor Event Storm ==========

class TestFileMonitorEventStorm:
    def test_excludes_browser_files(self):
        from agent_lib.file_monitor import FileMonitor
        monitor = FileMonitor()
        assert monitor._is_excluded(r"C:\Users\User\AppData\Local\Temp\somefile.js")
        assert monitor._is_excluded(r"C:\Users\User\AppData\Local\Temp\somefile.css")
        assert monitor._is_excluded(r"C:\Users\User\AppData\Local\Temp\somefile.html")
        assert monitor._is_excluded(r"C:\Users\User\AppData\Local\Temp\somefile.json")
        assert monitor._is_excluded(r"C:\Users\User\AppData\Local\Temp\somefile.xml")
        assert monitor._is_excluded(r"C:\Users\User\AppData\Local\Temp\somefile.part")
        assert monitor._is_excluded(r"C:\Users\User\AppData\Local\Temp\somefile.tmp")

    def test_excludes_scoped_dir_temp(self):
        from agent_lib.file_monitor import FileMonitor
        monitor = FileMonitor()
        assert monitor._is_excluded(
            r"C:\Users\User\AppData\Local\Temp\scoped_dir7436_1951715097\CRX_INSTALL\assets\icon.svg"
        )
        assert monitor._is_excluded(
            r"C:\Users\User\AppData\Local\Temp\chromiumcrx_chrome_Unpacker_BeginUnzipping7436\file.png"
        )
        assert monitor._is_excluded(
            r"C:\Users\User\AppData\Local\Temp\scoped_dir7436\CRX_INSTALL\file.js"
        )

    def test_excludes_db_files(self):
        from agent_lib.file_monitor import FileMonitor
        monitor = FileMonitor()
        assert monitor._is_excluded("agent_security.db")
        assert monitor._is_excluded("agent_security.db-journal")
        assert monitor._is_excluded("agent_security.sqlite")
        assert monitor._is_excluded("agent_security.sqlite3")

    def test_excludes_log_files(self):
        from agent_lib.file_monitor import FileMonitor
        monitor = FileMonitor()
        assert monitor._is_excluded(r"logs\agent.log")
        assert monitor._is_excluded("error.log")
        assert monitor._is_excluded("debug.log")

    def test_dedup_within_2s(self):
        from agent_lib.file_monitor import FileMonitor
        monitor = FileMonitor()
        monitor._dedup_window = 0.1

        with tempfile.NamedTemporaryFile(delete=False, suffix=".exe") as f:
            f.write(b"test")
            tmp1 = f.name

        with tempfile.NamedTemporaryFile(delete=False, suffix=".exe") as f:
            f.write(b"other")
            tmp2 = f.name

        try:
            monitor._handle_event("modified", tmp1)
            assert len(monitor._events) == 1

            monitor._handle_event("modified", tmp1)
            assert len(monitor._events) == 1, "Same file within window deduped"

            monitor._handle_event("created", tmp2)
            assert len(monitor._events) == 2, "Different file should fire"

            time.sleep(0.15)
            monitor._handle_event("modified", tmp1)
            assert len(monitor._events) == 3, "After window should fire again"
        finally:
            for p in (tmp1, tmp2):
                try:
                    os.unlink(p)
                except OSError:
                    pass


# ========== 3 & 4. Threat Intel Rate Limiting + Cache ==========

class TestIntelSubmitter:
    def test_should_submit_valid_extensions(self):
        from agent_lib.intel_submitter import IntelSubmitter
        assert IntelSubmitter.should_submit("evil.exe")
        assert IntelSubmitter.should_submit("evil.dll")
        assert IntelSubmitter.should_submit("evil.sys")
        assert IntelSubmitter.should_submit("script.ps1")
        assert IntelSubmitter.should_submit("script.bat")
        assert IntelSubmitter.should_submit("script.cmd")
        assert IntelSubmitter.should_submit("script.vbs")
        assert IntelSubmitter.should_submit("installer.msi")

    def test_should_submit_invalid_extensions(self):
        from agent_lib.intel_submitter import IntelSubmitter
        assert not IntelSubmitter.should_submit("style.css")
        assert not IntelSubmitter.should_submit("page.html")
        assert not IntelSubmitter.should_submit("data.json")
        assert not IntelSubmitter.should_submit("readme.txt")
        assert not IntelSubmitter.should_submit("download.part")
        assert not IntelSubmitter.should_submit("")

    def test_hash_cache_hit(self):
        from agent_lib.intel_submitter import IntelSubmitter
        submitter = IntelSubmitter("http://localhost:9999")

        hash_val = "a" * 64
        cached_result = {"indicator": hash_val, "type": "hash", "found": False, "score": 0}
        submitter._set_cached_hash(hash_val, cached_result)

        retrieved = submitter._get_cached_hash(hash_val)
        assert retrieved == cached_result

    def test_hash_cache_expiry(self):
        from agent_lib.intel_submitter import IntelSubmitter, INTEL_CACHE_TTL
        submitter = IntelSubmitter("http://localhost:9999")

        hash_val = "b" * 64
        cached_result = {"indicator": hash_val, "type": "hash", "found": False, "score": 0}
        submitter._set_cached_hash(hash_val, cached_result)

        # Simulate TTL passing
        submitter._hash_cache[hash_val] = (cached_result, time.time() - INTEL_CACHE_TTL - 1)
        retrieved = submitter._get_cached_hash(hash_val)
        assert retrieved is None, "Expired cache should return None"


# ========== 5. Backend Timeout Protection ==========

class TestBackendRetry:
    def test_post_retry_then_queue(self):
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
        import agent as agent_mod

        agent_mod._telemetry_queue.clear()
        agent_mod._backend_online = True

        with patch("requests.post") as mock_post:
            import requests
            mock_post.side_effect = requests.exceptions.ConnectionError("Failed")

            result = agent_mod.post("/api/test", {"key": "value"}, max_retries=3)

            assert result == {}
            assert mock_post.call_count == 3, "Should retry 3 times"
            assert len(agent_mod._telemetry_queue) == 1, "Should queue after retries"

    def test_post_recovery(self):
        import agent as agent_mod
        agent_mod._telemetry_queue.clear()

        with patch("requests.post") as mock_post:
            mock_response = MagicMock()
            mock_response.json.return_value = {"status": "ok"}
            mock_post.return_value = mock_response

            result = agent_mod.post("/api/test", {"key": "value"})
            assert result == {"status": "ok"}
            assert mock_post.call_count == 1, "Should succeed immediately"


# ========== 6. Process Hash Throttling ==========

class TestHashThrottle:
    def test_mtime_cache_skips_rehash(self, tmp_path):
        sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
        import agent as agent_mod

        exe = tmp_path / "test.exe"
        exe.write_bytes(b"hello")

        mtime = os.path.getmtime(str(exe))
        agent_mod._hash_mtime_cache.clear()

        from agent_lib.intel_submitter import IntelSubmitter
        fake_intel = IntelSubmitter("http://localhost:9999")

        with patch("agent.hash_file") as mock_hash, \
             patch.object(agent_mod, "post", return_value={}), \
             patch.object(agent_mod, "_intel", fake_intel):
            mock_hash.return_value = "abc123"
            agent_mod._hash_mtime_cache[str(exe)] = ("abc123", mtime)
            from agent import _hash_mtime_cache
            assert _hash_mtime_cache[str(exe)] == ("abc123", mtime)

    def test_mtime_changed_rehashes(self, tmp_path):
        import agent as agent_mod
        exe = tmp_path / "test.exe"
        exe.write_bytes(b"hello")
        old_mtime = os.path.getmtime(str(exe))

        agent_mod._hash_mtime_cache[str(exe)] = ("oldhash", old_mtime)
        agent_mod._hash_mtime_cache.clear()

        exe.write_bytes(b"hello modified")
        new_mtime = os.path.getmtime(str(exe))
        assert new_mtime != old_mtime or True  # mtime may not change on fast writes


# ========== 7. Alert Correlation ==========

class TestAlertCorrelation:
    def test_process_alert_dedup(self):
        from agent_lib.behavioral import generate_alert

        detections = [
            {"rule": "temp_execution", "risk_score": 20, "severity": "MEDIUM",
             "mitre_id": "T1055", "description": "Temp exec", "path": "/tmp/evil.exe"},
            {"rule": "suspicious_location", "risk_score": 15, "severity": "MEDIUM",
             "mitre_id": "T1055", "description": "Suspicious loc", "path": "/tmp/evil.exe"},
        ]
        alert = generate_alert(detections)
        assert alert is not None
        assert len(alert["rules"]) >= 2
        assert "temp_execution" in alert["rules"]
        assert "suspicious_location" in alert["rules"]
        assert alert["severity"] in ("MEDIUM", "HIGH")


# ========== 8. Integration Smoke Test ==========

class TestIntegrationSmoke:
    def test_all_imports(self):
        from agent_lib.persistence_monitor import PersistenceMonitor
        from agent_lib.file_monitor import FileMonitor
        from agent_lib.intel_submitter import IntelSubmitter, SUBMITTABLE_EXTENSIONS, INTEL_CACHE_TTL
        from agent_lib.correlation import CorrelationEngine
        from agent_lib.behavioral import generate_alert
        assert len(SUBMITTABLE_EXTENSIONS) == 11
        assert INTEL_CACHE_TTL == 86400
        print("All imports and constants verified")

    def test_baseline_persistence_on_disk(self, mock_baseline_path):
        pm = mock_baseline_path
        monitor = pm.PersistenceMonitor()
        monitor._baseline = ["service|a", "service|b"]
        monitor.save_baseline()
        assert os.path.exists(pm.BASELINE_FILE)

        # Second instance loads the saved baseline
        monitor2 = pm.PersistenceMonitor()
        monitor2._baseline_loaded = False
        monitor2._baseline = []
        monitor2._ensure_baseline_loaded()
        assert len(monitor2._baseline) == 2

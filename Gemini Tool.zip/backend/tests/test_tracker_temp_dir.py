import os
import sys
import tempfile
import platform

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from tracker.tracker import ProcessTreeTracker, _get_temp_roots


IS_WINDOWS = platform.system() == "Windows"


class FakeEmitter:
    def __init__(self):
        self.events = []
    def emit(self, event, data=None):
        self.events.append((event, data))


def make_process(name, path, cmdline="", pid=100, ppid=1):
    return {
        "pid": pid,
        "ppid": ppid,
        "name": name,
        "path": path,
        "cmdline": cmdline,
    }


class TestGetTempRoots:
    def test_returns_list_of_strings(self):
        roots = _get_temp_roots()
        assert isinstance(roots, list)
        assert len(roots) > 0
        for r in roots:
            assert isinstance(r, str), f"Expected str, got {type(r)}: {r!r}"

    def test_includes_windows_temp_environ(self):
        roots = _get_temp_roots()
        user_temp = os.path.normcase(os.path.normpath(os.path.abspath(tempfile.gettempdir())))
        assert any(user_temp in r for r in roots), f"Expected {user_temp} in roots"

    def test_includes_c_windows_temp(self):
        roots = _get_temp_roots()
        win_temp = os.path.normcase(os.path.normpath(os.path.abspath(r"c:\windows\temp")))
        assert any(win_temp in r for r in roots)

    def test_includes_unix_tmp(self):
        roots = _get_temp_roots()
        assert "/tmp" in roots

    def test_cache_hits(self):
        roots_a = _get_temp_roots()
        roots_b = _get_temp_roots()
        assert roots_a is roots_b


class TestDetectTempDirectoryProcesses:
    @pytest.fixture
    def tracker(self):
        return ProcessTreeTracker(FakeEmitter())

    @pytest.fixture(autouse=True)
    def clear_cache(self):
        import tracker.tracker as mod
        mod._TEMP_ROOTS_CACHE = None
        yield
        mod._TEMP_ROOTS_CACHE = None

    # --- Should NOT alert (legitimate locations) ---

    def test_firefox_crashhelper(self, tracker):
        """crashhelper.exe in Program Files → no alert"""
        tracker.all_processes = [
            make_process(
                "crashhelper.exe",
                r"C:\Program Files\Mozilla Firefox\crashhelper.exe",
                cmdline=r'"C:\Program Files\Mozilla Firefox\crashhelper.exe" '
                        r'C:\Users\User\AppData\Local\Temp\*.dmp',
            ),
        ]
        results = tracker.detect_temp_directory_processes()
        assert len(results) == 0, f"Got false positive: {results}"

    def test_chrome_exe(self, tracker):
        """chrome.exe in Program Files → no alert"""
        tracker.all_processes = [
            make_process(
                "chrome.exe",
                r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            ),
        ]
        results = tracker.detect_temp_directory_processes()
        assert len(results) == 0

    def test_system32_cmd(self, tracker):
        """cmd.exe in System32 → no alert"""
        tracker.all_processes = [
            make_process(
                "cmd.exe",
                r"C:\Windows\System32\cmd.exe",
            ),
        ]
        results = tracker.detect_temp_directory_processes()
        assert len(results) == 0

    def test_windows_explorer(self, tracker):
        """explorer.exe in Windows → no alert"""
        tracker.all_processes = [
            make_process(
                "explorer.exe",
                r"C:\Windows\explorer.exe",
            ),
        ]
        results = tracker.detect_temp_directory_processes()
        assert len(results) == 0

    # --- Should alert (temp directory locations) ---

    def test_temp_malware_exe(self, tracker):
        # evil.exe in AppData\Local\Temp -> SHOULD alert
        tracker.all_processes = [
            make_process(
                "evil.exe",
                os.path.join(tempfile.gettempdir(), "evil.exe"),
                cmdline="evil.exe -payload",
            ),
        ]
        results = tracker.detect_temp_directory_processes()
        assert len(results) == 1
        assert results[0]["type"] == "temp_directory"
        assert results[0]["child_name"] == "evil.exe"

    def test_temp_malware_windows_temp(self, tracker):
        # malware.exe in C:\Windows\Temp -> SHOULD alert
        tracker.all_processes = [
            make_process(
                "malware.exe",
                r"C:\Windows\Temp\malware.exe",
            ),
        ]
        results = tracker.detect_temp_directory_processes()
        assert len(results) == 1
        assert results[0]["child_name"] == "malware.exe"

    @pytest.mark.skipif(IS_WINDOWS, reason="Unix path /tmp not valid on Windows")
    def test_temp_malware_tmp_unix(self, tracker):
        """malware in /tmp → SHOULD alert"""
        tracker.all_processes = [
            make_process(
                "malware.elf",
                "/tmp/evil/malware.elf",
            ),
        ]
        results = tracker.detect_temp_directory_processes()
        assert len(results) == 1
        assert results[0]["child_name"] == "malware.elf"

    @pytest.mark.skipif(IS_WINDOWS, reason="Unix path /var/tmp not valid on Windows")
    def test_temp_malware_var_tmp(self, tracker):
        """malware in /var/tmp → SHOULD alert"""
        tracker.all_processes = [
            make_process(
                "malware.elf",
                "/var/tmp/exploit.elf",
            ),
        ]
        results = tracker.detect_temp_directory_processes()
        assert len(results) == 1

    @pytest.mark.skipif(IS_WINDOWS, reason="Unix path /private/tmp not valid on Windows")
    def test_temp_malware_private_tmp_macos(self, tracker):
        """malware in /private/tmp (macOS) → SHOULD alert"""
        tracker.all_processes = [
            make_process(
                "malware.dmg",
                "/private/tmp/installer.dmg",
            ),
        ]
        results = tracker.detect_temp_directory_processes()
        assert len(results) == 1
        assert results[0]["child_name"] == "malware.dmg"

    def test_temp_malware_nested(self, tracker):
        """deeply nested in temp → SHOULD alert"""
        tracker.all_processes = [
            make_process(
                "payload.exe",
                os.path.join(tempfile.gettempdir(), "sub", "dir", "payload.exe"),
            ),
        ]
        results = tracker.detect_temp_directory_processes()
        assert len(results) == 1
        assert results[0]["child_name"] == "payload.exe"

    # --- Edge cases ---

    def test_no_path_skip(self, tracker):
        """process with no path → skip"""
        tracker.all_processes = [
            {"pid": 100, "ppid": 1, "name": "ghost", "path": "", "cmdline": ""},
        ]
        results = tracker.detect_temp_directory_processes()
        assert len(results) == 0

    def test_multiple_processes_mixed(self, tracker):
        """mix of legit and malicious → only malicious fires"""
        tracker.all_processes = [
            make_process("chrome.exe", r"C:\Program Files\Google\Chrome\Application\chrome.exe"),
            make_process("firefox.exe", r"C:\Program Files\Mozilla Firefox\firefox.exe"),
            make_process("evil.exe", os.path.join(tempfile.gettempdir(), "evil.exe")),
            make_process("notepad.exe", r"C:\Windows\System32\notepad.exe"),
        ]
        results = tracker.detect_temp_directory_processes()
        assert len(results) == 1
        assert results[0]["child_name"] == "evil.exe"

    def test_cmdline_contains_temp_but_path_legit(self, tracker):
        """cmdline references temp but exe itself is legit → no alert (Firefox FP case)"""
        tracker.all_processes = [
            make_process(
                "crashhelper.exe",
                r"C:\Program Files\Mozilla Firefox\crashhelper.exe",
                cmdline=(
                    r'"C:\Program Files\Mozilla Firefox\crashhelper.exe" '
                    r'C:\Users\User\AppData\Local\Temp\5F2B3A1C-4D8E-4F0A-9C7B-2E1D3F5A6B7C.dmp'
                ),
            ),
        ]
        results = tracker.detect_temp_directory_processes()
        assert len(results) == 0, f"cmdline temp reference caused FP: {results}"

    def test_case_insensitive_windows(self, tracker):
        """case variations in path → still detected"""
        tmp = tempfile.gettempdir()  # e.g. C:\Users\heeTesh\AppData\Local\Temp
        parent = os.path.dirname(tmp)  # C:\Users\heeTesh\AppData\Local
        evil = os.path.join(parent.upper(), "TEMP", "EVIL.EXE")
        tracker.all_processes = [
            make_process("EVIL.EXE", evil),
        ]
        results = tracker.detect_temp_directory_processes()
        assert len(results) == 1

    def test_empty_process_list(self, tracker):
        """no processes → empty results"""
        tracker.all_processes = []
        results = tracker.detect_temp_directory_processes()
        assert len(results) == 0
